-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: dbmangchaa
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `catID` int(11) NOT NULL,
  `category` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (0,'Milk Tea'),(1,'Chocolate'),(2,'Yakult Milk Tea'),(3,'Iced Tea'),(4,'Taro'),(5,'Rocksalt & Cheese'),(6,'Coffee'),(7,'Hot Milk Tea'),(8,'MINTerrific'),(9,'Matcha Mucho'),(10,'Frappe'),(11,'SODA'),(12,'ADD-ONS');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount`
--

DROP TABLE IF EXISTS `discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DiscountCode` varchar(10) DEFAULT NULL,
  `DiscountType` varchar(20) DEFAULT NULL,
  `DiscountValue` double DEFAULT NULL,
  `stat` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount`
--

LOCK TABLES `discount` WRITE;
/*!40000 ALTER TABLE `discount` DISABLE KEYS */;
INSERT INTO `discount` VALUES (1,'SC','Senior Citizen',0.2,1),(2,'PWD','PWD',0.2,1);
/*!40000 ALTER TABLE `discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `contactno` varchar(11) NOT NULL,
  `position` varchar(20) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pword` varchar(20) NOT NULL,
  `userlevel` int(11) NOT NULL DEFAULT '0',
  `empstatus` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100005 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (100001,'Doe','John','09876543210','Owner','john','test123',2,1),(100002,'Administrator','System','N/A','System Administrator','admin','admin',1,1),(100003,'Doe','Jane','09876543210','Staff','jane','janedoe',3,1),(100004,'staff','sample','09171234567','Staff','staff','staff1',3,1);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_category`
--

DROP TABLE IF EXISTS `inventory_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_category` (
  `catID` int(11) NOT NULL AUTO_INCREMENT,
  `catName` varchar(30) NOT NULL,
  PRIMARY KEY (`catID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_category`
--

LOCK TABLES `inventory_category` WRITE;
/*!40000 ALTER TABLE `inventory_category` DISABLE KEYS */;
INSERT INTO `inventory_category` VALUES (1,'Supplies'),(2,'Consumables');
/*!40000 ALTER TABLE `inventory_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_items` (
  `itemID` int(11) NOT NULL AUTO_INCREMENT,
  `itemName` varchar(50) NOT NULL,
  `itemCategory` int(11) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) NOT NULL,
  `itemStatus` int(11) NOT NULL,
  PRIMARY KEY (`itemID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
INSERT INTO `inventory_items` VALUES (1,'Pearl',1,'2019-11-07 18:04:31',100003,1),(2,'Tissue',2,'2019-11-07 18:05:59',100003,1),(3,'Milk Tea',1,'2019-11-11 10:15:32',100003,1),(4,'Iced Tea',1,'2019-11-11 10:15:43',100003,1);
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ProdID` int(11) NOT NULL DEFAULT '0',
  `ProdName` varchar(50) NOT NULL,
  `CatType` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (3,1001,'Pearl Milk Tea',0,60),(4,1002,'Coffee Jelly Milk Tea',0,60),(5,1003,'Grass Jelly Milk Tea',0,60),(6,1004,'Banana Milk Tea',0,60),(7,1005,'Okinawa w/ Pearl',0,65),(8,2001,'Chocolate Milk Tea w/ Pearl',1,65),(9,2002,'Choco-Banana Milk Tea',1,65),(10,4001,'Green Apple',3,40),(11,4002,'Passion Fruit',3,40),(12,5001,'Taro Milk Tea w/ Pearl',4,60),(13,6001,'Wintermelon',5,75),(14,7001,'Iced Coffee',6,55),(15,8001,'Hot Milk Tea',7,55),(16,9001,'Dynamint Milk Tea',8,65),(17,10001,'Mat-choco Milk',9,65),(18,11001,'Matcha',10,85),(19,12001,'Honey-Lemon',11,75),(20,13001,'Pearl',12,10),(21,13002,'Grass Jelly',12,15);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_cashier`
--

DROP TABLE IF EXISTS `reading_cashier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reading_cashier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CashierID` int(11) NOT NULL,
  `ReadingStatus` varchar(10) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `ChangeFund` double NOT NULL,
  `TotalSalesAmt` double NOT NULL,
  `TotalVat` double NOT NULL,
  `TotalVatable` double NOT NULL,
  `TotalDiscount` double NOT NULL,
  `TotalTransactions` int(11) NOT NULL,
  `TotalSoldItems` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_cashier`
--

LOCK TABLES `reading_cashier` WRITE;
/*!40000 ALTER TABLE `reading_cashier` DISABLE KEYS */;
INSERT INTO `reading_cashier` VALUES (1,100003,'Open','2019-11-04 01:38:54',1000,0,0,0,0,0,0),(2,100003,'Close','2019-11-05 15:15:29',1000,210,22.5,187.5,0,2,5),(3,100003,'Close','2019-11-06 03:44:03',1000,0,0,0,0,0,0),(4,100004,'Close','2019-11-06 03:44:17',1000,140,15,125,0,1,2),(5,100004,'Close','2019-11-06 16:54:56',1000,310,33.21,276.79,0,1,6),(6,100003,'Close','2019-11-06 18:04:25',0,0,0,0,0,0,0),(7,100003,'Open','2019-11-10 19:06:42',1000,0,0,0,0,0,0),(8,100003,'Open','2019-11-11 00:30:30',1000,0,0,0,0,0,0),(9,100003,'Open','2019-11-12 19:02:02',1000,0,0,0,0,0,0),(10,100003,'Close','2019-11-13 00:25:10',10000,615,65.9,549.0999999999999,0,3,11),(11,100003,'Close','2019-11-14 13:41:26',1000,460,49.29,410.71,0,2,8),(12,100004,'Close','2019-11-14 13:43:00',1000,320,34.29,285.71000000000004,0,2,6),(13,100003,'Close','2019-11-15 12:25:42',1000,516,55.27,460.73,129,7,8);
/*!40000 ALTER TABLE `reading_cashier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_eod`
--

DROP TABLE IF EXISTS `reading_eod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reading_eod` (
  `eodID` int(11) NOT NULL AUTO_INCREMENT,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) NOT NULL,
  PRIMARY KEY (`eodID`)
) ENGINE=InnoDB AUTO_INCREMENT=1000003 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_eod`
--

LOCK TABLES `reading_eod` WRITE;
/*!40000 ALTER TABLE `reading_eod` DISABLE KEYS */;
INSERT INTO `reading_eod` VALUES (1000001,'2019-11-13 23:59:42',100003),(1000002,'2019-11-14 23:43:36',100003);
/*!40000 ALTER TABLE `reading_eod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_register`
--

DROP TABLE IF EXISTS `reading_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reading_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CashierID` int(11) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `TransactionStart` int(11) DEFAULT NULL,
  `TransactionEnd` int(11) DEFAULT NULL,
  `TotalSalesAmt` double DEFAULT NULL,
  `TotalVat` double DEFAULT NULL,
  `TotalVatable` double DEFAULT NULL,
  `TotalDiscount` double NOT NULL,
  `TotalTransactions` int(11) DEFAULT NULL,
  `TotalSoldItems` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_register`
--

LOCK TABLES `reading_register` WRITE;
/*!40000 ALTER TABLE `reading_register` DISABLE KEYS */;
INSERT INTO `reading_register` VALUES (1,100003,'2019-11-06 23:48:36',10000004,10000005,450,48.21,401.79,0,2,8),(2,100003,'2019-11-13 23:59:26',10000018,10000020,615,65.9,549.1,0,3,11),(3,100003,'2019-11-14 23:43:18',10000021,10000024,780,83.58,696.42,0,4,14),(4,100003,'2019-11-15 16:04:36',10000025,10000031,516,55.27,460.73,129,7,8);
/*!40000 ALTER TABLE `reading_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockinventory`
--

DROP TABLE IF EXISTS `stockinventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stockinventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `ActionType` varchar(10) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `Quantity` int(11) NOT NULL,
  `Remarks` varchar(200) DEFAULT NULL,
  `CreatedBy` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockinventory`
--

LOCK TABLES `stockinventory` WRITE;
/*!40000 ALTER TABLE `stockinventory` DISABLE KEYS */;
INSERT INTO `stockinventory` VALUES (1,1,'1','2019-11-07 18:30:34',50,'sample stock',100003),(2,1,'2','2019-11-07 19:16:18',10,'sample use of stock',100003),(3,2,'1','2019-11-11 10:08:33',50,'sample stock',100003),(4,4,'1','2019-11-11 10:15:56',50,'',100003),(5,3,'1','2019-11-11 10:17:31',10,'',100003),(6,3,'1','2019-11-11 10:20:49',5,'',100003),(7,3,'1','2019-11-11 10:29:59',5,'',100003),(8,3,'2','2019-11-11 10:31:27',5,'',100003),(9,3,'1','2019-11-14 11:32:10',16,'',100003),(10,3,'2','2019-11-14 11:32:39',16,'',100003),(11,1,'2','2019-11-14 13:04:58',10,'',100003),(12,4,'2','2019-11-14 13:38:40',10,'',100003),(13,1,'2','2019-11-14 13:39:01',7,'',100003);
/*!40000 ALTER TABLE `stockinventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluserlevel`
--

DROP TABLE IF EXISTS `tbluserlevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbluserlevel` (
  `UserLevel` int(11) DEFAULT NULL,
  `UserDesc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluserlevel`
--

LOCK TABLES `tbluserlevel` WRITE;
/*!40000 ALTER TABLE `tbluserlevel` DISABLE KEYS */;
INSERT INTO `tbluserlevel` VALUES (1,'admin'),(2,'owner'),(3,'staff');
/*!40000 ALTER TABLE `tbluserlevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactiondetails`
--

DROP TABLE IF EXISTS `transactiondetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactiondetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `TransID` int(11) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `ProdID` int(11) NOT NULL,
  `ProdName` varchar(50) NOT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `TotalPrice` double DEFAULT NULL,
  `DiscCode` varchar(10) DEFAULT NULL,
  `DiscountValue` double NOT NULL,
  `CReadingID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactiondetails`
--

LOCK TABLES `transactiondetails` WRITE;
/*!40000 ALTER TABLE `transactiondetails` DISABLE KEYS */;
INSERT INTO `transactiondetails` VALUES (1,1,'2019-10-04 17:27:50',1001,'Pearl Milk Tea',1,60,60,NULL,0,1),(2,1,'2019-10-04 17:27:50',1002,'Coffee Jelly Milk Tea',1,60,60,NULL,0,1),(3,1,'2019-10-04 17:27:50',13002,'Grass Jelly',1,15,15,NULL,0,1),(4,2,'2019-11-05 15:16:03',1001,'Pearl Milk Tea',1,60,60,NULL,0,2),(5,2,'2019-11-05 15:16:03',1002,'Coffee Jelly Milk Tea',1,60,60,NULL,0,2),(6,2,'2019-11-05 15:16:03',13002,'Grass Jelly',2,15,30,NULL,0,2),(7,10000003,'2019-11-05 15:18:12',1001,'Pearl Milk Tea',1,60,60,NULL,0,2),(8,10000004,'2019-11-06 03:55:26',1001,'Pearl Milk Tea (R)',1,60,60,NULL,0,4),(9,10000004,'2019-11-06 03:55:26',1002,'Coffee Jelly Milk Tea (L)',1,60,80,NULL,0,4),(10,10000005,'2019-11-06 16:55:23',1001,'Pearl Milk Tea (R)',1,60,60,NULL,0,5),(11,10000005,'2019-11-06 16:55:23',1002,'Coffee Jelly Milk Tea (R)',1,60,60,NULL,0,5),(12,10000005,'2019-11-06 16:55:23',1001,'Pearl Milk Tea (L)',1,60,80,NULL,0,5),(13,10000005,'2019-11-06 16:55:23',1002,'Coffee Jelly Milk Tea (L)',1,60,80,NULL,0,5),(14,10000005,'2019-11-06 16:55:23',13002,'Grass Jelly',2,15,30,NULL,0,5),(15,10000006,'2019-11-10 19:50:06',1001,'Pearl Milk Tea(R)',1,60,60,NULL,0,7),(16,10000006,'2019-11-10 19:50:06',1003,'Grass Jelly Milk Tea(L)',1,60,80,NULL,0,7),(17,10000007,'2019-11-11 09:16:15',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,8),(18,10000007,'2019-11-11 09:16:15',2001,'Chocolate Milk Tea w/ Pearl(R)',1,85,85,NULL,0,8),(19,10000007,'2019-11-11 09:16:15',2002,'Choco-Banana Milk Tea(L)',1,105,105,NULL,0,8),(20,10000007,'2019-11-11 09:16:15',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,8),(21,10000007,'2019-11-11 09:16:15',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,8),(22,10000008,'2019-11-11 09:17:47',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,8),(23,10000008,'2019-11-11 09:17:47',2001,'Chocolate Milk Tea w/ Pearl(R)',1,85,85,NULL,0,8),(24,10000008,'2019-11-11 09:17:47',2002,'Choco-Banana Milk Tea(L)',1,105,105,NULL,0,8),(25,10000008,'2019-11-11 09:17:47',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,8),(26,10000008,'2019-11-11 09:17:47',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,8),(27,10000009,'2019-11-11 09:18:45',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,8),(28,10000009,'2019-11-11 09:18:45',2001,'Chocolate Milk Tea w/ Pearl(R)',1,85,85,NULL,0,8),(29,10000009,'2019-11-11 09:18:45',2002,'Choco-Banana Milk Tea(L)',1,105,105,NULL,0,8),(30,10000009,'2019-11-11 09:18:45',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,8),(31,10000009,'2019-11-11 09:18:45',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,8),(32,10000010,'2019-11-11 09:21:55',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,8),(33,10000010,'2019-11-11 09:21:55',2001,'Chocolate Milk Tea w/ Pearl(R)',1,85,85,NULL,0,8),(34,10000010,'2019-11-11 09:21:55',2002,'Choco-Banana Milk Tea(L)',1,105,105,NULL,0,8),(35,10000010,'2019-11-11 09:21:55',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,8),(36,10000010,'2019-11-11 09:21:55',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,8),(37,10000011,'2019-11-11 09:23:34',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,8),(38,10000011,'2019-11-11 09:23:34',2001,'Chocolate Milk Tea w/ Pearl(R)',1,85,85,NULL,0,8),(39,10000011,'2019-11-11 09:23:34',2002,'Choco-Banana Milk Tea(L)',1,105,105,NULL,0,8),(40,10000011,'2019-11-11 09:23:34',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,8),(41,10000011,'2019-11-11 09:23:34',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,8),(42,10000012,'2019-11-11 09:25:15',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,8),(43,10000012,'2019-11-11 09:25:15',2001,'Chocolate Milk Tea w/ Pearl(R)',1,85,85,NULL,0,8),(44,10000012,'2019-11-11 09:25:15',2002,'Choco-Banana Milk Tea(L)',1,105,105,NULL,0,8),(45,10000012,'2019-11-11 09:25:15',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,8),(46,10000012,'2019-11-11 09:25:15',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,8),(47,10000013,'2019-11-11 09:26:25',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,8),(48,10000013,'2019-11-11 09:26:25',2001,'Chocolate Milk Tea w/ Pearl(R)',1,85,85,NULL,0,8),(49,10000013,'2019-11-11 09:26:25',2002,'Choco-Banana Milk Tea(L)',1,105,105,NULL,0,8),(50,10000013,'2019-11-11 09:26:25',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,8),(51,10000013,'2019-11-11 09:26:25',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,8),(52,10000014,'2019-11-11 09:28:37',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,8),(53,10000014,'2019-11-11 09:28:37',2002,'Choco-Banana Milk Tea(L)',1,105,105,NULL,0,8),(54,10000015,'2019-11-11 09:52:25',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,8),(55,10000015,'2019-11-11 09:52:25',2001,'Chocolate Milk Tea w/ Pearl(R)',1,85,85,NULL,0,8),(56,10000015,'2019-11-11 09:52:25',2002,'Choco-Banana Milk Tea(L)',1,105,105,NULL,0,8),(57,10000015,'2019-11-11 09:52:25',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,8),(58,10000015,'2019-11-11 09:52:25',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,8),(59,10000016,'2019-11-12 19:38:03',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,9),(60,10000016,'2019-11-12 19:38:03',1003,'Grass Jelly Milk Tea(R)',1,80,80,NULL,0,9),(61,10000016,'2019-11-12 19:38:03',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,9),(62,10000016,'2019-11-12 19:38:04',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,9),(63,10000017,'2019-11-12 19:39:26',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,9),(64,10000017,'2019-11-12 19:39:26',2002,'Choco-Banana Milk Tea(R)',1,85,85,NULL,0,9),(65,10000018,'2019-11-13 00:25:22',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,10),(66,10000019,'2019-11-13 23:58:09',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,10),(67,10000019,'2019-11-13 23:58:09',1003,'Grass Jelly Milk Tea(R)',1,80,80,NULL,0,10),(68,10000019,'2019-11-13 23:58:09',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,10),(69,10000019,'2019-11-13 23:58:09',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,10),(70,10000020,'2019-11-13 23:58:43',6001,'Wintermelon(L)',1,115,115,NULL,0,10),(71,10000020,'2019-11-13 23:58:43',10001,'Mat-choco Milk(L)',1,105,105,NULL,0,10),(72,10000020,'2019-11-13 23:58:43',12001,'Honey-Lemon(S)',2,75,150,NULL,0,10),(73,10000020,'2019-11-13 23:58:43',13001,'Pearl(ADD-ON)',2,10,20,NULL,0,10),(74,10000021,'2019-11-14 13:41:44',1002,'Coffee Jelly Milk Tea(S)',1,60,60,NULL,0,11),(75,10000021,'2019-11-14 13:41:44',1001,'Pearl Milk Tea(R)',1,80,80,NULL,0,11),(76,10000021,'2019-11-14 13:41:44',1003,'Grass Jelly Milk Tea(S)',1,60,60,NULL,0,11),(77,10000021,'2019-11-14 13:41:44',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,11),(78,10000021,'2019-11-14 13:41:44',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,11),(79,10000022,'2019-11-14 13:42:08',2001,'Chocolate Milk Tea w/ Pearl(S)',1,65,65,NULL,0,11),(80,10000022,'2019-11-14 13:42:08',2002,'Choco-Banana Milk Tea(R)',2,85,170,NULL,0,11),(81,10000023,'2019-11-14 13:43:06',1005,'Okinawa w/ Pearl(S)',1,65,65,NULL,0,12),(82,10000023,'2019-11-14 13:43:06',1004,'Banana Milk Tea(R)',1,80,80,NULL,0,12),(83,10000024,'2019-11-14 13:43:18',7001,'Iced Coffee(R)',2,75,150,NULL,0,12),(84,10000024,'2019-11-14 13:43:18',13001,'Pearl(ADD-ON)',1,10,10,NULL,0,12),(85,10000024,'2019-11-14 13:43:18',13002,'Grass Jelly(ADD-ON)',1,15,15,NULL,0,12),(86,10000025,'2019-11-15 14:41:12',1002,'Coffee Jelly Milk Tea(S)',1,60,48,'SC',12,13),(87,10000026,'2019-11-15 14:51:45',1002,'Coffee Jelly Milk Tea(S)',1,60,48,'SC',12,13),(88,10000027,'2019-11-15 14:57:05',1003,'Grass Jelly Milk Tea(L)',1,100,80,'PWD',20,13),(89,10000028,'2019-11-15 14:59:42',1004,'Banana Milk Tea(L)',1,100,80,'PWD',20,13),(90,10000029,'2019-11-15 15:00:50',1002,'Coffee Jelly Milk Tea(L)',1,100,80,'SC',20,13),(91,10000030,'2019-11-15 15:03:24',1002,'Coffee Jelly Milk Tea(S)',1,60,48,'SC',12,13),(92,10000030,'2019-11-15 15:03:24',1005,'Okinawa w/ Pearl(L)',1,105,84,'SC',21,13),(93,10000031,'2019-11-15 15:23:17',1002,'Coffee Jelly Milk Tea(S)',1,60,48,'SC',12,13);
/*!40000 ALTER TABLE `transactiondetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactionheader`
--

DROP TABLE IF EXISTS `transactionheader`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactionheader` (
  `TransID` int(11) NOT NULL AUTO_INCREMENT,
  `IsVoided` tinyint(1) DEFAULT '1',
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `TotalItems` int(11) NOT NULL,
  `TotalPrice` double NOT NULL,
  `Vatable` double NOT NULL,
  `VAT` double NOT NULL,
  `Discount` double unsigned NOT NULL,
  `SoldTo` varchar(20) NOT NULL DEFAULT '',
  `AmountPaid` double NOT NULL,
  `ChangeAmt` double unsigned NOT NULL,
  `UserID` int(11) NOT NULL,
  `CReadingID` int(11) NOT NULL,
  PRIMARY KEY (`TransID`)
) ENGINE=InnoDB AUTO_INCREMENT=10000032 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactionheader`
--

LOCK TABLES `transactionheader` WRITE;
/*!40000 ALTER TABLE `transactionheader` DISABLE KEYS */;
INSERT INTO `transactionheader` VALUES (1,0,'2019-10-04 17:27:50',3,135,120.54,14.46,0,'',0,0,100003,1),(2,0,'2019-11-05 15:16:03',4,150,133.93,16.07,0,'',0,0,100003,2),(10000003,0,'2019-11-05 15:18:12',1,60,53.57,6.43,0,'',0,0,100003,2),(10000004,0,'2019-11-06 03:55:26',2,140,125,15,0,'',0,0,100004,4),(10000005,0,'2019-11-06 16:55:23',6,310,276.79,33.21,0,'',0,0,100004,5),(10000006,0,'2019-11-10 19:50:06',2,140,125,15,0,'',0,0,100003,7),(10000007,0,'2019-11-11 09:16:15',5,275,245.54,29.46,0,'',0,0,100003,8),(10000008,0,'2019-11-11 09:17:47',5,275,245.54,29.46,0,'',0,0,100003,8),(10000009,0,'2019-11-11 09:18:45',5,275,245.54,29.46,0,'',0,0,100003,8),(10000010,0,'2019-11-11 09:21:55',5,275,245.54,29.46,0,'',0,0,100003,8),(10000011,0,'2019-11-11 09:23:34',5,275,245.54,29.46,0,'',0,0,100003,8),(10000012,0,'2019-11-11 09:25:15',5,275,245.54,29.46,0,'',0,0,100003,8),(10000013,0,'2019-11-11 09:26:25',5,275,245.54,29.46,0,'',0,0,100003,8),(10000014,0,'2019-11-11 09:28:37',2,165,147.32,17.68,0,'',0,0,100003,8),(10000015,0,'2019-11-11 09:52:25',5,275,245.54,29.46,0,'',0,0,100003,8),(10000016,0,'2019-11-12 19:38:03',4,165,147.32,17.68,0,'',165,0,100003,9),(10000017,0,'2019-11-12 19:39:26',2,145,129.46,15.54,0,'Mark',200,55,100003,9),(10000018,0,'2019-11-13 00:25:22',1,60,53.57,6.43,0,'',60,0,100003,10),(10000019,0,'2019-11-13 23:58:09',4,165,147.32,17.68,0,'',165,0,100003,10),(10000020,0,'2019-11-13 23:58:43',6,390,348.21,41.79,0,'',400,10,100003,10),(10000021,0,'2019-11-14 13:41:44',5,225,200.89,24.11,0,'Earl',250,25,100003,11),(10000022,0,'2019-11-14 13:42:08',3,235,209.82,25.18,0,'',235,0,100003,11),(10000023,0,'2019-11-14 13:43:06',2,145,129.46,15.54,0,'',150,5,100004,12),(10000024,0,'2019-11-14 13:43:18',4,175,156.25,18.75,0,'',200,25,100004,12),(10000025,0,'2019-11-15 14:41:12',1,48,42.86,5.14,12,'',48,0,100003,13),(10000026,0,'2019-11-15 14:51:45',1,48,42.86,5.14,12,'',50,2,100003,13),(10000027,0,'2019-11-15 14:57:05',1,80,71.43,8.57,20,'',80,0,100003,13),(10000028,0,'2019-11-15 14:59:42',1,80,71.43,8.57,20,'',80,0,100003,13),(10000029,0,'2019-11-15 15:00:50',1,80,71.43,8.57,20,'',100,20,100003,13),(10000030,0,'2019-11-15 15:03:24',2,132,117.86,14.14,33,'',150,18,100003,13),(10000031,0,'2019-11-15 15:23:17',1,48,42.86,5.14,12,'Terry',50,2,100003,13);
/*!40000 ALTER TABLE `transactionheader` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-15 16:23:17
