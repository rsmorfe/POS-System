-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: dbmangchaa
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `catID` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(25) NOT NULL,
  PRIMARY KEY (`catID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Milk Tea'),(2,'Chocolate'),(3,'Yakult Milk Tea'),(4,'Iced Tea'),(5,'Taro'),(6,'Rocksalt & Cheese'),(7,'Coffee'),(8,'Hot Milk Tea'),(9,'MINTerrific'),(10,'Matcha Mucho'),(11,'Frappe'),(12,'SODA'),(13,'ADD-ONS');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount`
--

DROP TABLE IF EXISTS `discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DiscountCode` varchar(20) DEFAULT NULL,
  `DiscountType` varchar(20) DEFAULT NULL,
  `DiscountValue` double DEFAULT NULL,
  `stat` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount`
--

LOCK TABLES `discount` WRITE;
/*!40000 ALTER TABLE `discount` DISABLE KEYS */;
INSERT INTO `discount` VALUES (1,'SC','Senior Citizen',0.2,0),(2,'PWD','PWD',0.2,1);
/*!40000 ALTER TABLE `discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `contactno` varchar(11) NOT NULL,
  `position` varchar(20) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pword` varchar(20) NOT NULL,
  `userlevel` int(11) NOT NULL DEFAULT '0',
  `empstatus` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100006 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (100001,'Doe','John','09876543210','Owner','john','johndoe',2,1),(100002,'Administrator','System','N/A','System Administrator','admin','admin',1,1),(100003,'Doe','Jane','09876543210','Staff','jane','janedoe',3,1),(100004,'staff','sample','09171234567','Staff','staff','staff1',3,1);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_category`
--

DROP TABLE IF EXISTS `inventory_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_category` (
  `catID` int(11) NOT NULL AUTO_INCREMENT,
  `catName` varchar(30) NOT NULL,
  PRIMARY KEY (`catID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_category`
--

LOCK TABLES `inventory_category` WRITE;
/*!40000 ALTER TABLE `inventory_category` DISABLE KEYS */;
INSERT INTO `inventory_category` VALUES (1,'Supplies'),(2,'Consumables');
/*!40000 ALTER TABLE `inventory_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_items` (
  `itemID` int(11) NOT NULL AUTO_INCREMENT,
  `itemName` varchar(50) NOT NULL,
  `itemCategory` int(11) NOT NULL,
  `UOM` varchar(10) DEFAULT '',
  `Size` char(2) DEFAULT '',
  `Color` varchar(50) DEFAULT '',
  `CreatedBy` int(11) NOT NULL,
  `itemStatus` int(11) NOT NULL,
  PRIMARY KEY (`itemID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
INSERT INTO `inventory_items` VALUES (1,'Pearl',1,'PACK','L','WHITE',100003,1),(2,'Tissue',2,'BOX','S','WHITE',100003,1),(3,'Milk Tea',1,'PACK','L','YELLOW',100003,1),(4,'Iced Tea',1,'PACK','L','RED',100003,1),(5,'Sugar',1,'PACK','L','WHITE',100003,1),(6,'Salt',1,'BOX','L','YELLOW',100003,1),(7,'Straw',1,'PACK','S','GREEN',100003,1),(8,'Grass Jelly',1,'PACK','M','GREEN',100003,1),(9,'Cups Large',2,'BOX','L','WHITE',100003,1),(10,'Cups Small',2,'BOX','XL','GREEN',100003,1);
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `ProdID` int(11) NOT NULL AUTO_INCREMENT,
  `ProdName` varchar(50) NOT NULL,
  `CatType` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`ProdID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (3,'Pearl Milk Tea',1,60),(4,'Coffee Jelly Milk Tea',1,60),(5,'Grass Jelly Milk Tea',1,60),(6,'Banana Milk Tea',1,60),(7,'Okinawa w/ Pearl',1,65),(8,'Chocolate Milk Tea w/ Pearl',2,65),(9,'Choco-Banana Milk Tea',2,65),(10,'Green Apple',4,40),(12,'Taro Milk Tea w/ Pearl',5,60),(13,'Wintermelon',6,75),(14,'Iced Coffee',7,55),(15,'Hot Milk Tea',8,55),(16,'Dynamint Milk Tea',9,65),(17,'Mat-choco Milk',10,65),(18,'Matcha',11,85),(19,'Honey-Lemon',12,75),(20,'Pearl',13,10),(21,'Grass Jelly',13,15);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_cashier`
--

DROP TABLE IF EXISTS `reading_cashier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reading_cashier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CashierID` int(11) NOT NULL,
  `ReadingStatus` varchar(10) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `ChangeFund` double NOT NULL,
  `TotalSalesAmt` double NOT NULL,
  `TotalVat` double NOT NULL,
  `TotalVatable` double NOT NULL,
  `TotalDiscount` double NOT NULL,
  `TotalTransactions` int(11) NOT NULL,
  `TotalSoldItems` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_cashier`
--

LOCK TABLES `reading_cashier` WRITE;
/*!40000 ALTER TABLE `reading_cashier` DISABLE KEYS */;
INSERT INTO `reading_cashier` VALUES (1,100003,'Close','2019-11-16 20:29:35',1000,165,17.68,147.32,0,1,4),(2,100004,'Close','2019-11-16 20:30:26',1000,224,24,200,56,2,5),(3,100003,'Close','2019-11-17 20:46:19',1000,340,36.43,303.57,0,1,8),(4,100004,'Close','2019-11-17 20:47:11',1000,212,22.72,189.28,53,2,4),(5,100003,'Open','2019-11-18 20:11:42',1000,0,0,0,0,0,0),(6,100003,'Open','2019-11-19 12:55:33',0,0,0,0,0,0,0),(7,100003,'Open','2019-11-23 13:48:55',0,0,0,0,0,0,0),(8,100003,'Close','2019-11-24 12:05:30',0,360,38.58,321.42,0,3,7),(9,100003,'Close','2019-11-24 14:13:29',0,100,10.71,89.29,0,1,1);
/*!40000 ALTER TABLE `reading_cashier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_eod`
--

DROP TABLE IF EXISTS `reading_eod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reading_eod` (
  `eodID` int(11) NOT NULL AUTO_INCREMENT,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) NOT NULL,
  PRIMARY KEY (`eodID`)
) ENGINE=InnoDB AUTO_INCREMENT=1000003 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_eod`
--

LOCK TABLES `reading_eod` WRITE;
/*!40000 ALTER TABLE `reading_eod` DISABLE KEYS */;
INSERT INTO `reading_eod` VALUES (1000001,'2019-11-16 20:44:18',100003),(1000002,'2019-11-17 21:06:46',100004);
/*!40000 ALTER TABLE `reading_eod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_register`
--

DROP TABLE IF EXISTS `reading_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reading_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CashierID` int(11) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `TransactionStart` int(11) DEFAULT NULL,
  `TransactionEnd` int(11) DEFAULT NULL,
  `TotalSalesAmt` double DEFAULT NULL,
  `TotalVat` double DEFAULT NULL,
  `TotalVatable` double DEFAULT NULL,
  `TotalDiscount` double NOT NULL,
  `TotalTransactions` int(11) DEFAULT NULL,
  `TotalSoldItems` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_register`
--

LOCK TABLES `reading_register` WRITE;
/*!40000 ALTER TABLE `reading_register` DISABLE KEYS */;
INSERT INTO `reading_register` VALUES (1,100003,'2019-11-16 20:34:27',10000001,10000003,389,41.68,347.32,56,3,9),(2,100004,'2019-11-17 20:48:50',10000004,10000006,552,59.15,492.85,53,3,12),(3,100004,'2019-11-17 21:05:40',10000004,10000006,552,59.15,492.85,53,3,12),(4,100003,'2019-11-24 14:07:02',10000014,10000016,360,38.58,321.42,0,3,7),(5,100003,'2019-11-24 14:12:57',10000014,10000016,360,38.58,321.42,0,3,7),(6,100003,'2019-11-24 14:14:26',10000014,10000017,460,49.29,410.71,0,4,8),(7,100003,'2019-11-24 14:17:48',10000014,10000017,460,49.29,410.71,0,4,8),(8,100003,'2019-11-24 14:34:08',10000014,10000017,460,49.29,410.71,0,4,8),(9,100003,'2019-11-24 14:38:13',10000014,10000017,460,49.29,410.71,0,4,8);
/*!40000 ALTER TABLE `reading_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockinventory`
--

DROP TABLE IF EXISTS `stockinventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stockinventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `ActionType` varchar(10) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `Quantity` int(11) NOT NULL,
  `Remarks` varchar(200) DEFAULT NULL,
  `CreatedBy` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockinventory`
--

LOCK TABLES `stockinventory` WRITE;
/*!40000 ALTER TABLE `stockinventory` DISABLE KEYS */;
INSERT INTO `stockinventory` VALUES (1,1,'1','2019-11-07 18:30:34',50,'sample stock',100003),(2,1,'2','2019-11-07 19:16:18',10,'sample use of stock',100003),(3,2,'1','2019-11-11 10:08:33',50,'sample stock',100003),(4,4,'1','2019-11-11 10:15:56',50,'',100003),(5,3,'1','2019-11-11 10:17:31',10,'',100003),(6,3,'1','2019-11-11 10:20:49',5,'',100003),(7,3,'1','2019-11-11 10:29:59',5,'',100003),(8,3,'2','2019-11-11 10:31:27',5,'',100003),(9,3,'1','2019-11-14 11:32:10',16,'',100003),(10,3,'2','2019-11-14 11:32:39',16,'',100003),(11,1,'2','2019-11-14 13:04:58',10,'',100003),(12,4,'2','2019-11-14 13:38:40',10,'',100003),(13,1,'2','2019-11-14 13:39:01',7,'',100003),(14,8,'1','2019-11-19 13:44:05',5,'',100003),(15,9,'1','2019-11-22 16:44:44',100,'From Bayanan Store',100003),(16,6,'1','2019-11-24 13:09:53',10,'',100003),(17,4,'2','2019-11-24 13:13:41',10,'store stock replenish',100003),(18,11,'1','2019-11-24 13:37:58',1,'',100003),(19,12,'1','2019-11-24 13:39:46',1,'',100003),(20,12,'2','2019-11-24 13:41:01',1,'',100003);
/*!40000 ALTER TABLE `stockinventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluserlevel`
--

DROP TABLE IF EXISTS `tbluserlevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbluserlevel` (
  `UserLevel` int(11) DEFAULT NULL,
  `UserDesc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluserlevel`
--

LOCK TABLES `tbluserlevel` WRITE;
/*!40000 ALTER TABLE `tbluserlevel` DISABLE KEYS */;
INSERT INTO `tbluserlevel` VALUES (1,'admin'),(2,'owner'),(3,'staff');
/*!40000 ALTER TABLE `tbluserlevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactiondetails`
--

DROP TABLE IF EXISTS `transactiondetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactiondetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `TransID` int(11) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `ProdID` int(11) NOT NULL,
  `ProdName` varchar(50) NOT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `TotalPrice` double DEFAULT NULL,
  `DiscCode` varchar(10) DEFAULT NULL,
  `DiscountValue` double NOT NULL,
  `CReadingID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactiondetails`
--

LOCK TABLES `transactiondetails` WRITE;
/*!40000 ALTER TABLE `transactiondetails` DISABLE KEYS */;
INSERT INTO `transactiondetails` VALUES (1,10000001,'2019-11-16 20:29:46',1002,'Coffee Jelly Milk Tea(S)',1,60,60,'',0,1),(2,10000001,'2019-11-16 20:29:46',1003,'Grass Jelly Milk Tea(R)',1,80,80,'',0,1),(3,10000001,'2019-11-16 20:29:46',13001,'Pearl(ADD-ON)',1,10,10,'',0,1),(4,10000001,'2019-11-16 20:29:46',13002,'Grass Jelly(ADD-ON)',1,15,15,'',0,1),(5,10000002,'2019-11-16 20:30:37',1001,'Pearl Milk Tea(S)',1,60,48,'SC',12,2),(6,10000002,'2019-11-16 20:30:37',1003,'Grass Jelly Milk Tea(S)',1,60,48,'SC',12,2),(7,10000003,'2019-11-16 20:31:35',2002,'Choco-Banana Milk Tea(S)',1,65,52,'PWD',13,2),(8,10000003,'2019-11-16 20:31:35',2001,'Chocolate Milk Tea w/ Pearl(R)',1,85,68,'PWD',17,2),(9,10000003,'2019-11-16 20:31:35',13001,'Pearl(ADD-ON)',1,10,8,'PWD',2,2),(10,10000004,'2019-11-17 20:46:32',1004,'Banana Milk Tea(S)',2,60,120,'',0,3),(11,10000004,'2019-11-17 20:46:32',1005,'Okinawa w/ Pearl(R)',2,85,170,'',0,3),(12,10000004,'2019-11-17 20:46:32',13001,'Pearl(ADD-ON)',2,10,20,'',0,3),(13,10000004,'2019-11-17 20:46:32',13002,'Grass Jelly(ADD-ON)',2,15,30,'',0,3),(14,10000005,'2019-11-17 20:47:53',1002,'Coffee Jelly Milk Tea(S)',1,60,48,'SC',12,4),(15,10000005,'2019-11-17 20:47:53',1005,'Okinawa w/ Pearl(R)',1,85,68,'SC',17,4),(16,10000006,'2019-11-17 20:48:09',4001,'Green Apple(R)',1,60,48,'PWD',12,4),(17,10000006,'2019-11-17 20:48:09',4002,'Passion Fruit(R)',1,60,48,'PWD',12,4),(18,10000007,'2019-11-19 14:04:11',1002,'Coffee Jelly Milk Tea(R)',2,80,160,'',0,6),(19,10000008,'2019-11-19 14:04:36',1005,'Okinawa w/ Pearl(S)',3,65,195,'',0,6),(20,10000008,'2019-11-19 14:04:36',13001,'Pearl(ADD-ON)',3,10,30,'',0,6),(21,10000009,'2019-11-19 14:05:36',1002,'Coffee Jelly Milk Tea(R)',1,80,80,'',0,6),(22,10000010,'2019-11-19 14:42:15',1002,'Coffee Jelly Milk Tea(L)',1,100,100,'',0,6),(23,10000011,'2019-11-20 14:46:36',4002,'Passion Fruit(L)',2,80,160,'',0,6),(24,10000012,'2019-11-19 14:58:06',1002,'Coffee Jelly Milk Tea(L)',1,100,100,'',0,6),(25,10000013,'2019-11-20 15:04:43',1002,'Coffee Jelly Milk Tea(L)',1,100,100,'',0,6),(26,10000014,'2019-11-24 12:19:39',4,'Coffee Jelly Milk Tea(S)',2,60,120,'',0,8),(27,10000015,'2019-11-24 12:30:38',4,'Coffee Jelly Milk Tea(S)',1,60,60,'',0,8),(28,10000016,'2019-11-24 12:32:55',5,'Grass Jelly Milk Tea(R)',2,80,160,'',0,8),(29,10000016,'2019-11-24 12:32:55',20,'Pearl(ADD-ON)',2,10,20,'',0,8),(30,10000017,'2019-11-24 14:13:36',4,'Coffee Jelly Milk Tea(L)',1,100,100,'',0,9);
/*!40000 ALTER TABLE `transactiondetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactionheader`
--

DROP TABLE IF EXISTS `transactionheader`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactionheader` (
  `TransID` int(11) NOT NULL AUTO_INCREMENT,
  `IsVoided` tinyint(1) DEFAULT '1',
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `TotalItems` int(11) NOT NULL,
  `TotalPrice` double NOT NULL,
  `Vatable` double NOT NULL,
  `VAT` double NOT NULL,
  `Discount` double unsigned NOT NULL,
  `SoldTo` varchar(20) NOT NULL DEFAULT '',
  `AmountPaid` double NOT NULL,
  `ChangeAmt` double unsigned NOT NULL,
  `UserID` int(11) NOT NULL,
  `CReadingID` int(11) NOT NULL,
  PRIMARY KEY (`TransID`)
) ENGINE=InnoDB AUTO_INCREMENT=10000018 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactionheader`
--

LOCK TABLES `transactionheader` WRITE;
/*!40000 ALTER TABLE `transactionheader` DISABLE KEYS */;
INSERT INTO `transactionheader` VALUES (10000001,0,'2019-11-16 20:29:46',4,165,147.32,17.68,0,'',200,35,100003,1),(10000002,0,'2019-11-16 20:30:37',2,96,85.71,10.29,24,'',100,4,100004,2),(10000003,0,'2019-11-16 20:31:35',3,128,114.29,13.71,32,'',128,0,100004,2),(10000004,0,'2019-11-17 20:46:32',8,340,303.57,36.43,0,'',500,160,100003,3),(10000005,0,'2019-11-17 20:47:53',2,116,103.57,12.43,29,'',120,4,100004,4),(10000006,0,'2019-11-17 20:48:09',2,96,85.71,10.29,24,'',100,4,100004,4),(10000007,0,'2019-11-19 14:04:11',2,160,142.86,17.14,0,'',160,0,100003,6),(10000008,0,'2019-11-19 14:04:36',6,225,200.89,24.11,0,'',250,25,100003,6),(10000009,0,'2019-11-19 14:05:36',1,80,71.43,8.57,0,'',100,20,100003,6),(10000010,0,'2019-11-19 14:42:15',1,100,89.29,10.71,0,'',100,0,100003,6),(10000011,0,'2019-11-20 14:46:36',2,160,142.86,17.14,0,'',160,0,100003,6),(10000012,0,'2019-11-19 14:58:06',1,100,89.29,10.71,0,'Mac Mac',100,0,100003,6),(10000013,0,'2019-11-20 15:04:43',1,100,89.29,10.71,0,'',100,0,100003,6),(10000014,0,'2019-11-24 12:19:39',2,120,107.14,12.86,0,'',120,0,100003,8),(10000015,0,'2019-11-24 12:30:38',1,60,53.57,6.43,0,'Eric',60,0,100003,8),(10000016,0,'2019-11-24 12:32:55',4,180,160.71,19.29,0,'',200,20,100003,8),(10000017,0,'2019-11-24 14:13:36',1,100,89.29,10.71,0,'',100,0,100003,9);
/*!40000 ALTER TABLE `transactionheader` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-24 15:15:56
