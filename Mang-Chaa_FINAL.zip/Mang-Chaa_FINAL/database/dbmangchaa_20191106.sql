-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: dbmangchaa
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `catID` int(11) NOT NULL,
  `category` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (0,'Milk Tea'),(1,'Chocolate'),(2,'Yakult Milk Tea'),(3,'Iced Tea'),(4,'Taro'),(5,'Rocksalt & Cheese'),(6,'Coffee'),(7,'Hot Milk Tea'),(8,'MINTerrific'),(9,'Matcha Mucho'),(10,'Frappe'),(11,'SODA'),(12,'ADD-ONS');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `contactno` varchar(11) NOT NULL,
  `position` varchar(20) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pword` varchar(20) NOT NULL,
  `userlevel` int(11) NOT NULL DEFAULT '0',
  `empstatus` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100005 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (100001,'Doe','John','09876543210','Owner','john','test123',2,1),(100002,'Administrator','System','N/A','System Administrator','admin','admin',1,1),(100003,'Doe','Jane','09876543210','Staff','jane','janedoe',3,1),(100004,'staff','sample','09171234567','Staff','staff','staff1',3,1);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ProdID` int(11) NOT NULL DEFAULT '0',
  `ProdName` varchar(50) NOT NULL,
  `CatType` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (3,1001,'Pearl Milk Tea',0,60),(4,1002,'Coffee Jelly Milk Tea',0,60),(5,1003,'Grass Jelly Milk Tea',0,60),(6,1004,'Banana Milk Tea',0,60),(7,1005,'Okinawa w/ Pearl',0,65),(8,2001,'Chocolate Milk Tea w/ Pearl',1,65),(9,2002,'Choco-Banana Milk Tea',1,65),(10,4001,'Green Apple',3,40),(11,4002,'Passion Fruit',3,40),(12,5001,'Taro Milk Tea w/ Pearl',4,60),(13,6001,'Wintermelon',5,75),(14,7001,'Iced Coffee',6,55),(15,8001,'Hot Milk Tea',7,55),(16,9001,'Dynamint Milk Tea',8,65),(17,10001,'Mat-choco Milk',9,65),(18,11001,'Matcha',10,85),(19,12001,'Honey-Lemon',11,75),(20,13001,'Pearl',12,10),(21,13002,'Grass Jelly',12,15);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_cashier`
--

DROP TABLE IF EXISTS `reading_cashier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reading_cashier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CashierID` int(11) NOT NULL,
  `ReadingStatus` varchar(10) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `ChangeFund` double NOT NULL,
  `TotalSalesAmt` double NOT NULL,
  `TotalVat` double NOT NULL,
  `TotalVatable` double NOT NULL,
  `TotalTransactions` int(11) NOT NULL,
  `TotalSoldItems` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_cashier`
--

LOCK TABLES `reading_cashier` WRITE;
/*!40000 ALTER TABLE `reading_cashier` DISABLE KEYS */;
INSERT INTO `reading_cashier` VALUES (1,100003,'Open','2019-11-04 01:38:54',1000,0,0,0,0,0),(2,100003,'Close','2019-11-05 15:15:29',1000,210,22.5,187.5,2,5),(3,100003,'Close','2019-11-06 03:44:03',1000,0,0,0,0,0),(4,100004,'Close','2019-11-06 03:44:17',1000,140,15,125,1,2),(5,100004,'Close','2019-11-06 16:54:56',1000,310,33.21,276.79,1,6),(6,100003,'Close','2019-11-06 18:04:25',0,0,0,0,0,0);
/*!40000 ALTER TABLE `reading_cashier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_register`
--

DROP TABLE IF EXISTS `reading_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reading_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CashierID` int(11) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `TransactionStart` int(11) DEFAULT NULL,
  `TransactionEnd` int(11) DEFAULT NULL,
  `TotalSalesAmt` double DEFAULT NULL,
  `TotalVat` double DEFAULT NULL,
  `TotalVatable` double DEFAULT NULL,
  `TotalTransactions` int(11) DEFAULT NULL,
  `TotalSoldItems` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_register`
--

LOCK TABLES `reading_register` WRITE;
/*!40000 ALTER TABLE `reading_register` DISABLE KEYS */;
INSERT INTO `reading_register` VALUES (1,100003,'2019-11-06 17:49:24',10000004,10000005,450,48.21,401.79,2,8),(2,100003,'2019-11-06 23:48:36',10000004,10000005,450,48.21,401.79,2,8);
/*!40000 ALTER TABLE `reading_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockinventory`
--

DROP TABLE IF EXISTS `stockinventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stockinventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ProdID` int(11) NOT NULL,
  `ActionType` varchar(10) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `Quantity` int(11) NOT NULL,
  `Remarks` varchar(200) DEFAULT NULL,
  `CreatedBy` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockinventory`
--

LOCK TABLES `stockinventory` WRITE;
/*!40000 ALTER TABLE `stockinventory` DISABLE KEYS */;
INSERT INTO `stockinventory` VALUES (1,1001,'1','2019-09-30 08:18:03',50,'','admin'),(2,1002,'1','2019-09-30 09:02:50',100,'','admin'),(3,13002,'1','2019-10-29 11:36:58',10,'','admin');
/*!40000 ALTER TABLE `stockinventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluserlevel`
--

DROP TABLE IF EXISTS `tbluserlevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbluserlevel` (
  `UserLevel` int(11) DEFAULT NULL,
  `UserDesc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluserlevel`
--

LOCK TABLES `tbluserlevel` WRITE;
/*!40000 ALTER TABLE `tbluserlevel` DISABLE KEYS */;
INSERT INTO `tbluserlevel` VALUES (1,'admin'),(2,'owner'),(3,'staff');
/*!40000 ALTER TABLE `tbluserlevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactiondetails`
--

DROP TABLE IF EXISTS `transactiondetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactiondetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `TransID` int(11) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `ProdID` int(11) NOT NULL,
  `ProdName` varchar(50) NOT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `TotalPrice` double DEFAULT NULL,
  `CReadingID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactiondetails`
--

LOCK TABLES `transactiondetails` WRITE;
/*!40000 ALTER TABLE `transactiondetails` DISABLE KEYS */;
INSERT INTO `transactiondetails` VALUES (1,1,'2019-11-04 17:27:50',1001,'Pearl Milk Tea',1,60,60,1),(2,1,'2019-11-04 17:27:50',1002,'Coffee Jelly Milk Tea',1,60,60,1),(3,1,'2019-11-04 17:27:50',13002,'Grass Jelly',1,15,15,1),(4,2,'2019-11-05 15:16:03',1001,'Pearl Milk Tea',1,60,60,2),(5,2,'2019-11-05 15:16:03',1002,'Coffee Jelly Milk Tea',1,60,60,2),(6,2,'2019-11-05 15:16:03',13002,'Grass Jelly',2,15,30,2),(7,10000003,'2019-11-05 15:18:12',1001,'Pearl Milk Tea',1,60,60,2),(8,10000004,'2019-11-06 03:55:26',1001,'Pearl Milk Tea (R)',1,60,60,4),(9,10000004,'2019-11-06 03:55:26',1002,'Coffee Jelly Milk Tea (L)',1,60,80,4),(10,10000005,'2019-11-06 16:55:23',1001,'Pearl Milk Tea (R)',1,60,60,5),(11,10000005,'2019-11-06 16:55:23',1002,'Coffee Jelly Milk Tea (R)',1,60,60,5),(12,10000005,'2019-11-06 16:55:23',1001,'Pearl Milk Tea (L)',1,60,80,5),(13,10000005,'2019-11-06 16:55:23',1002,'Coffee Jelly Milk Tea (L)',1,60,80,5),(14,10000005,'2019-11-06 16:55:23',13002,'Grass Jelly',2,15,30,5);
/*!40000 ALTER TABLE `transactiondetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactionheader`
--

DROP TABLE IF EXISTS `transactionheader`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactionheader` (
  `TransID` int(11) NOT NULL AUTO_INCREMENT,
  `IsVoided` tinyint(1) DEFAULT '1',
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `TotalItems` int(11) NOT NULL,
  `TotalPrice` double NOT NULL,
  `Vatable` double NOT NULL,
  `VAT` double NOT NULL,
  `UserID` int(11) NOT NULL,
  `CReadingID` int(11) NOT NULL,
  PRIMARY KEY (`TransID`)
) ENGINE=InnoDB AUTO_INCREMENT=10000006 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactionheader`
--

LOCK TABLES `transactionheader` WRITE;
/*!40000 ALTER TABLE `transactionheader` DISABLE KEYS */;
INSERT INTO `transactionheader` VALUES (1,0,'2019-11-04 17:27:50',3,135,120.54,14.46,100003,1),(2,0,'2019-11-05 15:16:03',4,150,133.93,16.07,100003,2),(10000003,0,'2019-11-05 15:18:12',1,60,53.57,6.43,100003,2),(10000004,0,'2019-11-06 03:55:26',2,140,125,15,100004,4),(10000005,0,'2019-11-06 16:55:23',6,310,276.79,33.21,100004,5);
/*!40000 ALTER TABLE `transactionheader` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-06 23:50:28
