-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: dbmangchaa
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `catID` int(11) NOT NULL,
  `category` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (0,'Milk Tea'),(1,'Chocolate'),(2,'Yakult Milk Tea'),(3,'Iced Tea'),(4,'Taro'),(5,'Rocksalt & Cheese'),(6,'Coffee'),(7,'Hot Milk Tea'),(8,'MINTerrific'),(9,'Matcha Mucho'),(10,'Frappe'),(11,'SODA'),(12,'ADD-ONS');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `pword` varchar(20) DEFAULT NULL,
  `contactno` varchar(11) DEFAULT NULL,
  `empstatus` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100002 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (100001,'Doe','John','test123','09876543210',1);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ProdID` int(11) NOT NULL DEFAULT '0',
  `ProdName` varchar(50) NOT NULL,
  `CatType` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (3,1001,'Pearl Milk Tea',0,60),(4,1002,'Coffee Jelly Milk Tea',0,60),(5,1003,'Grass Jelly Milk Tea',0,60),(6,1004,'Banana Milk Tea',0,60),(7,1005,'Okinawa w/ Pearl',0,65),(8,2001,'Chocolate Milk Tea w/ Pearl',1,65),(9,2002,'Choco-Banana Milk Tea',1,65),(10,4001,'Green Apple',3,40),(11,4002,'Passion Fruit',3,40),(12,5001,'Taro Milk Tea w/ Pearl',4,60),(13,6001,'Wintermelon',5,75),(14,7001,'Iced Coffee',6,55),(15,8001,'Hot Milk Tea',7,55),(16,9001,'Dynamint Milk Tea',8,65),(17,10001,'Mat-choco Milk',9,65),(18,11001,'Matcha',10,85),(19,12001,'Honey-Lemon',11,75),(20,13001,'Pearl',12,10),(21,13002,'Grass Jelly',12,15);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockinventory`
--

DROP TABLE IF EXISTS `stockinventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stockinventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ProdID` int(11) NOT NULL,
  `ActionType` varchar(10) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `Quantity` int(11) NOT NULL,
  `Remarks` varchar(200) DEFAULT NULL,
  `CreatedBy` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockinventory`
--

LOCK TABLES `stockinventory` WRITE;
/*!40000 ALTER TABLE `stockinventory` DISABLE KEYS */;
INSERT INTO `stockinventory` VALUES (1,1001,'1','2019-09-30 08:18:03',50,'','admin'),(2,1002,'1','2019-09-30 09:02:50',100,'','admin');
/*!40000 ALTER TABLE `stockinventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbluser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `userpass` varchar(20) DEFAULT NULL,
  `UserLevel` int(11) DEFAULT NULL,
  `userstatus` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser`
--

LOCK TABLES `tbluser` WRITE;
/*!40000 ALTER TABLE `tbluser` DISABLE KEYS */;
INSERT INTO `tbluser` VALUES (1,'admin','admin',1,1),(2,'staff','staff1',2,1);
/*!40000 ALTER TABLE `tbluser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactiondetails`
--

DROP TABLE IF EXISTS `transactiondetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactiondetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `TransID` int(11) NOT NULL,
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `ProdID` int(11) NOT NULL,
  `ProdName` varchar(50) NOT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `TotalPrice` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactiondetails`
--

LOCK TABLES `transactiondetails` WRITE;
/*!40000 ALTER TABLE `transactiondetails` DISABLE KEYS */;
INSERT INTO `transactiondetails` VALUES (1,10000001,'2019-09-30 16:26:44',1001,'Pearl Milk Tea',1,60,60),(2,10000001,'2019-09-30 16:26:44',2001,'Chocolate Milk Tea w/ Pearl',1,65,65),(3,10000001,'2019-09-30 16:26:44',13001,'Pearl (Add-On)',1,10,10),(4,10000002,'2019-09-30 16:27:13',4001,'Green Apple',1,40,40),(5,10000002,'2019-09-30 16:27:13',13001,'Pearl (Add-On)',1,10,10),(6,10000002,'2019-09-30 16:27:13',13002,'Grass Jelly (Add-On)',1,15,15),(7,10000003,'2019-09-30 16:28:04',1005,'Okinawa w/ Pearl',2,60,120),(8,10000003,'2019-09-30 16:28:04',13001,'Pearl (Add-On)',1,10,10),(9,10000003,'2019-09-30 16:28:04',13002,'Grass Jelly (Add-On)',1,15,15);
/*!40000 ALTER TABLE `transactiondetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactionheader`
--

DROP TABLE IF EXISTS `transactionheader`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactionheader` (
  `TransID` int(11) NOT NULL AUTO_INCREMENT,
  `IsVoided` tinyint(1) DEFAULT '1',
  `DateCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `TotalItems` int(11) NOT NULL,
  `TotalPrice` double NOT NULL,
  `Vatable` double NOT NULL,
  `VAT` double NOT NULL,
  `UserID` int(11) NOT NULL,
  PRIMARY KEY (`TransID`)
) ENGINE=InnoDB AUTO_INCREMENT=10000004 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactionheader`
--

LOCK TABLES `transactionheader` WRITE;
/*!40000 ALTER TABLE `transactionheader` DISABLE KEYS */;
INSERT INTO `transactionheader` VALUES (10000001,0,'2019-09-30 16:26:44',3,135,120.54,14.46,0),(10000002,0,'2019-09-30 16:27:13',3,65,58.04,6.96,0),(10000003,0,'2019-09-30 16:28:04',4,145,129.46,15.54,0);
/*!40000 ALTER TABLE `transactionheader` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-01  0:06:02
