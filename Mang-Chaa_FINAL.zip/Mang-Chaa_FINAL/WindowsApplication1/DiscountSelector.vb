﻿Public Class DiscountSelector

    Private Sub DiscountSelector_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDiscounts()
    End Sub

    Sub LoadDiscounts()
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT DiscountCode,DiscountType FROM discount WHERE stat = 1"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        ComboBox1.DataSource = table
        ComboBox1.DisplayMember = "DiscountType"
        ComboBox1.ValueMember = "DiscountCode"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT DiscountValue FROM discount WHERE DiscountCode = @code"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
            .Parameters.AddWithValue("@code", ComboBox1.SelectedValue)
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        cmd.Parameters.Clear()

        For Each oRow As DataGridViewRow In POS.DataGridView1.Rows

            oRow.Cells("Disc_Code").Value = ComboBox1.SelectedValue
            oRow.Cells("Discount").Value = FormatNumber(oRow.Cells("Price").Value * table.Rows(0).Item("DiscountValue"), 2)
            oRow.Cells("Price").Value = FormatNumber(oRow.Cells("Price").Value - oRow.Cells("Discount").Value, 2)
        Next
        POS.Compute() 're-compute
        POS.HasAppliedDisc = True

        Me.Close()
    End Sub
End Class