﻿Public Class SelectSize
    Dim PID As Integer
    Dim ItemName As String
    Dim ItemPrice As Double

    Private Sub btnSmall_Click(sender As Object, e As EventArgs) Handles btnSmall.Click
        If ComboBox1.Text = "" Then
            MsgBox("No quantity selected!", vbExclamation + vbOKOnly, "System")
        ElseIf ComboBox2.Text = "" Then
            MsgBox("No Sugar Level selected!", vbExclamation + vbOKOnly, "System")
        Else
            PrepareItem(Strings.Left(btnSmall.Text, 1), PID, ItemName, ItemPrice)
            Me.Close()
        End If
    End Sub

    Private Sub btnRegular_Click(sender As Object, e As EventArgs) Handles btnRegular.Click
        If ComboBox1.Text = "" Then
            MsgBox("No quantity selected!", vbExclamation + vbOKOnly, "System")
        ElseIf ComboBox2.Text = "" Then
            MsgBox("No Sugar Level selected!", vbExclamation + vbOKOnly, "System")
        Else
            PrepareItem(Strings.Left(btnRegular.Text, 1), PID, ItemName, ItemPrice)
            btnRegular.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 128)
            Me.Close()
        End If
    End Sub

    Private Sub btnLarge_Click(sender As Object, e As EventArgs) Handles btnLarge.Click
        If ComboBox1.Text = "" Then
            MsgBox("No quantity selected!", vbExclamation + vbOKOnly, "System")
        ElseIf ComboBox2.Text = "" Then
            MsgBox("No Sugar Level selected!", vbExclamation + vbOKOnly, "System")
        Else
            PrepareItem(Strings.Left(btnLarge.Text, 1), PID, ItemName, ItemPrice)
            Me.Close()
        End If
    End Sub

    Public Sub PrepareInitialValues(prodID As Integer, item As String, price As Double)
        PID = prodID
        ItemName = item
        ItemPrice = price
    End Sub

    Public Sub PrepareItem(size As String, prodID As Integer, item As String, price As Double)
        POS.GetItemWithSize(size, prodID, item, CInt(ComboBox1.Text), FormatNumber(price, 2), ComboBox2.Text)
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

   
    Private Sub SelectSize_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadQuantity()
    End Sub

    Sub LoadQuantity()
        ComboBox1.Items.Clear()

        Dim NumArray()
        NumArray = {1, 2, 3, 4, 5, 6, 7, 8, 9}
        ComboBox1.Items.AddRange(NumArray)
    End Sub

    Private Sub btnSmall_MouseEnter(sender As Object, e As EventArgs) Handles btnSmall.MouseEnter
        btnSmall.BackColor = Color.FromArgb(255, 192, 128)
    End Sub

    Private Sub btnRegular_MouseEnter(sender As Object, e As EventArgs) Handles btnRegular.MouseEnter
        btnRegular.BackColor = Color.FromArgb(255, 192, 128)
    End Sub

    Private Sub btnLarge_MouseEnter(sender As Object, e As EventArgs) Handles btnLarge.MouseEnter
        btnLarge.BackColor = Color.FromArgb(255, 192, 128)
    End Sub


    Private Sub btnSmall_MouseLeave(sender As Object, e As EventArgs) Handles btnSmall.MouseLeave
        btnSmall.BackColor = Color.FromArgb(255, 255, 192)
    End Sub

    Private Sub btnRegular_MouseLeave(sender As Object, e As EventArgs) Handles btnRegular.MouseLeave
        btnRegular.BackColor = Color.FromArgb(255, 255, 192)
    End Sub

    Private Sub btnLarge_MouseLeave(sender As Object, e As EventArgs) Handles btnLarge.MouseLeave
        btnLarge.BackColor = Color.FromArgb(255, 255, 192)
    End Sub

    Private Sub btnCancel_MouseEnter(sender As Object, e As EventArgs) Handles btnCancel.MouseEnter
        btnCancel.BackColor = Color.FromArgb(255, 192, 128)
    End Sub

    Private Sub btnCancel_MouseLeave(sender As Object, e As EventArgs) Handles btnCancel.MouseLeave
        btnCancel.BackColor = Color.FromArgb(255, 255, 192)
    End Sub
End Class