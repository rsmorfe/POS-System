﻿Public Class OnlyStaff

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Products.Show()
        Me.Close()

        'Dim products As New Products
        'products.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'LOAD DEFAULT VALUES
        CashierID = 0
        ReadingID = 0

        HasPerformedEOD = CheckStatus_EOD()

        If HasPerformedEOD = True Then
            MsgBox("This register has already performed EOD.", vbExclamation + vbOKOnly, "System")
        Else
            POS.Show()
            Me.Close()
        End If
        
        'Dim pos As New POS
        'pos.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Inventory.Show()
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Login.Show()
        Me.Close()
    End Sub

    Private Sub OnlyStaff_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class