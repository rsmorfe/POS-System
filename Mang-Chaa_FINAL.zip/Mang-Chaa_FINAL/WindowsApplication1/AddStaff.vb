﻿Public Class AddStaff
    Dim commandstat As String

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadUserLevel()
        LoadRecords()

        txtContact.MaxLength = 11
        cbxUserLevel.Text = ""
    End Sub

    Sub LoadUserLevel()
        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT * from tbluserlevel"

        With cmd
            .Connection = MysqlConn
            .CommandText = sql
        End With

        da.SelectCommand = cmd
        da.Fill(publictable)

        cbxUserLevel.DataSource = publictable
        cbxUserLevel.DisplayMember = "UserDesc"
        cbxUserLevel.ValueMember = "UserLevel"
    End Sub

    Sub LoadRecords()
        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT * from employees"

        With cmd
            .Connection = MysqlConn
            .CommandText = sql
        End With

        da.SelectCommand = cmd
        da.Fill(publictable)

        DataGridView1.DataSource = publictable

        DataGridView1.Columns.Item(0).HeaderText = "Emp ID"
        DataGridView1.Columns.Item(1).HeaderText = "Surname"
        DataGridView1.Columns.Item(2).HeaderText = "Firstname"
        DataGridView1.Columns.Item(3).HeaderText = "Contact No"
        DataGridView1.Columns.Item(4).HeaderText = "Position"
        DataGridView1.Columns.Item(7).HeaderText = "User Level"
        DataGridView1.Columns.Item(8).HeaderText = "Status"

        DataGridView1.Columns.Item(5).Visible = False 'password
        DataGridView1.Columns.Item(6).Visible = False 'empstatus
    End Sub

    Sub AddRecord()
        Dim result As Integer

        Try
            'we open Connection
            'MysqlConn.Open()

            With cmd
                .Connection = MysqlConn
                .CommandText = "INSERT INTO employees" _
                    & "(lname,fname,contactno,position,uname,pword,userlevel)" _
                    & "VALUES(@lname,@fname,@contact,@position,@uname,@pword,@userlvl)"
                .Parameters.AddWithValue("@lname", txtLast.Text)
                .Parameters.AddWithValue("@fname", txtFirst.Text)
                .Parameters.AddWithValue("@contact", txtContact.Text)
                .Parameters.AddWithValue("@position", txtPosition.Text)
                .Parameters.AddWithValue("@uname", txtUser.Text)
                .Parameters.AddWithValue("@pword", txtPass.Text)
                .Parameters.AddWithValue("@userlvl", cbxUserLevel.SelectedValue)

                'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                result = cmd.ExecuteNonQuery
                'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                Else
                    MsgBox("Successfully saved!", vbOKOnly + vbInformation, "System")


                End If
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        cmd.Parameters.Clear()

        DataGridView1.DataSource = ""
        LoadRecords()

        ClearFields()

        txtFirst.Enabled = False
        txtLast.Enabled = False
        txtContact.Enabled = False
        txtPosition.Enabled = False

        txtUser.Enabled = False
        txtPass.Enabled = False
        txtConfirmPass.Enabled = False
        cbxUserLevel.Enabled = False

        DataGridView1.Enabled = True
        btnAdd.Enabled = True
        btnSave.Enabled = False
        btnUpdate.Enabled = False
    End Sub

    Sub UpdateRecord()
        Dim result As Integer

        Try
            'we open Connection
            'MysqlConn.Open()

            With cmd
                .Connection = MysqlConn
                .CommandText = "UPDATE employees set lname=@lname,fname=@fname,contactno=@contact,position=@position," & _
                     "uname=@uname,pword=@pword,userlevel=@userlvl where id=@id"
                .Parameters.AddWithValue("@lname", txtLast.Text)
                .Parameters.AddWithValue("@fname", txtFirst.Text)
                .Parameters.AddWithValue("@contact", txtContact.Text)
                .Parameters.AddWithValue("@position", txtPosition.Text)
                .Parameters.AddWithValue("@uname", txtUser.Text)
                .Parameters.AddWithValue("@pword", txtPass.Text)
                .Parameters.AddWithValue("@userlvl", cbxUserLevel.SelectedValue)
                .Parameters.AddWithValue("@id", txtID.Text)

                'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                result = cmd.ExecuteNonQuery

                'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                Else
                    MsgBox("Record successfully updated!", vbOKOnly + vbInformation, "System")


                End If
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        cmd.Parameters.Clear()

        DataGridView1.DataSource = ""
        LoadRecords()

        ClearFields()

        txtFirst.Enabled = False
        txtLast.Enabled = False
        txtContact.Enabled = False
        txtPosition.Enabled = False

        txtUser.Enabled = False
        txtPass.Enabled = False
        txtConfirmPass.Enabled = False
        cbxUserLevel.Enabled = False

        DataGridView1.Enabled = True
        btnAdd.Enabled = True
        btnSave.Enabled = False
        btnUpdate.Enabled = False
    End Sub

    Sub ClearFields()

        txtID.Clear()
        txtFirst.Clear()
        txtLast.Clear()
        txtContact.Clear()
        txtPosition.Clear()

        txtUser.Clear()
        txtPass.Clear()
        txtConfirmPass.Clear()
        cbxUserLevel.Text = ""

        DataGridView1.DataSource = ""
        LoadRecords()
    End Sub


    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        commandstat = "ADD"

        txtFirst.Enabled = True
        txtLast.Enabled = True
        txtContact.Enabled = True
        txtPosition.Enabled = True

        txtUser.Enabled = True
        txtPass.Enabled = True
        txtConfirmPass.Enabled = True
        cbxUserLevel.Enabled = True

        DataGridView1.Enabled = False
        btnAdd.Enabled = False
        btnSave.Enabled = True

        txtLast.Focus()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        commandstat = "UPDATE"

        txtFirst.Enabled = True
        txtLast.Enabled = True
        txtContact.Enabled = True
        txtPosition.Enabled = True

        txtUser.Enabled = True
        txtPass.Enabled = True
        txtConfirmPass.Enabled = True
        cbxUserLevel.Enabled = True

        DataGridView1.Enabled = False
        btnUpdate.Enabled = False
        btnSave.Enabled = True
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtFirst.Text = "" Or txtLast.Text = "" Or txtContact.Text = "" Or txtPosition.Text = "" Or txtUser.Text = "" Or
            txtPass.Text = "" Or txtConfirmPass.Text = "" Or cbxUserLevel.Text = "" Then
            MsgBox("Some of the fields is empty", vbExclamation + vbOKOnly, "System")
        Else
            If txtPass.Text.Equals(txtConfirmPass.Text) = True Then
                If commandstat = "ADD" Then
                    AddRecord()
                ElseIf commandstat = "UPDATE" Then
                    UpdateRecord()
                End If
            Else
                MsgBox("Please re-type your desired password", vbExclamation + vbOKOnly, "System")
                txtPass.Clear()
                txtConfirmPass.Clear()
                txtPass.Focus()
            End If
        End If
        
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        ClearFields()

        txtFirst.Enabled = False
        txtLast.Enabled = False
        txtContact.Enabled = False
        txtPosition.Enabled = False

        txtUser.Enabled = False
        txtPass.Enabled = False
        txtConfirmPass.Enabled = False
        cbxUserLevel.Enabled = False

        DataGridView1.Enabled = True
        btnAdd.Enabled = True
        btnSave.Enabled = False
        btnUpdate.Enabled = False

        DataGridView1.DataSource = ""
        LoadRecords()
    End Sub


    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        Dim row As DataGridViewRow = DataGridView1.CurrentRow

        On Error Resume Next
        If row.Cells(0).Value.ToString() = "" Then
            'do nothing
            ClearFields()
        Else
            txtID.Text = row.Cells(0).Value.ToString()
            txtLast.Text = row.Cells(1).Value.ToString()
            txtFirst.Text = row.Cells(2).Value.ToString()
            txtContact.Text = row.Cells(3).Value.ToString()
            txtPosition.Text = row.Cells(4).Value.ToString()

            txtUser.Text = row.Cells(5).Value.ToString()
            txtPass.Text = row.Cells(6).Value.ToString()
            txtConfirmPass.Text = row.Cells(6).Value.ToString()
            cbxUserLevel.SelectedValue = row.Cells(7).Value

        End If

        btnAdd.Enabled = False
        btnUpdate.Enabled = True
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Dim stat As Integer = DataGridView1.CurrentRow.Cells("empstatus").Value
        If stat = 1 Then
            Dim a = MsgBox("Deactivate the selected account?", vbQuestion + vbYesNo, "System")
            If a = vbYes Then
                Dim sql As String
                sql = "UPDATE employees set empstatus = 0 WHERE id = @id"

                With cmd
                    .Connection = MysqlConn
                    .CommandText = sql
                    .Parameters.AddWithValue("@id", DataGridView1.CurrentRow.Cells("id").Value)
                End With

                Dim result As Integer

                result = cmd.ExecuteNonQuery()
                If result > 0 Then
                    MsgBox("Account Deactivated", vbInformation + vbOKOnly, "System")
                    LoadRecords()
                End If
                cmd.Parameters.Clear()
            End If
        Else
            Dim a = MsgBox("Activate the selected account?", vbQuestion + vbYesNo, "System")
            If a = vbYes Then
                Dim sql As String
                sql = "UPDATE employees set empstatus = 1 WHERE id = @id"

                With cmd
                    .Connection = MysqlConn
                    .CommandText = sql
                    .Parameters.AddWithValue("@id", DataGridView1.CurrentRow.Cells("id").Value)
                End With

                Dim result As Integer

                result = cmd.ExecuteNonQuery()
                If result > 0 Then
                    MsgBox("Account Activated", vbInformation + vbOKOnly, "System")
                    LoadRecords()
                End If
                cmd.Parameters.Clear()
            End If
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If DataGridView1.Rows.Count = 0 Then
            'nothing
        Else
            If MsgBox("Do you really want to delete this item?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
                Dim sql As String
                sql = "DELETE FROM employees WHERE id = @uid"

                Try
                    With cmd
                        .CommandText = sql
                        .Connection = MysqlConn
                        .Parameters.AddWithValue("@uid", DataGridView1.CurrentRow.Cells("id").Value)
                        .ExecuteNonQuery()
                    End With

                    cmd.Parameters.Clear()
                    LoadRecords()
                Catch ex As Exception
                    MsgBox(ex.Message)
                    cmd.Parameters.Clear()
                End Try

            End If

        End If
    End Sub
End Class