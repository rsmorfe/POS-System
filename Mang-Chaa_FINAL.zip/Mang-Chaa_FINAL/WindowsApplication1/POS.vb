﻿Public Class POS
    Public table As New DataTable 'for handling data for setting up EventHandler
    Public HasAppliedDisc As Boolean

    Sub CreateRows()
        DataGridView1.Columns.Add("ProdID", "ProdID")
        DataGridView1.Columns(0).Width = 92
        DataGridView1.Columns(0).Visible = True
        DataGridView1.Columns.Add("Item", "Product")
        DataGridView1.Columns(1).Width = 210
        DataGridView1.Columns(1).Visible = True
        DataGridView1.Columns.Add("Size", "Size")
        DataGridView1.Columns(2).Width = 92
        DataGridView1.Columns(2).Visible = True
        DataGridView1.Columns.Add("OriginalPrice", "Price")
        DataGridView1.Columns(3).Width = 92
        DataGridView1.Columns(3).Visible = False
        DataGridView1.Columns.Item(3).DefaultCellStyle.Format = "####.#0"
        DataGridView1.Columns.Add("Qty", "Quantity")
        DataGridView1.Columns(4).Width = 90
        DataGridView1.Columns(4).Visible = True
        DataGridView1.Columns.Add("SugarLevel", "Sugar Level")
        DataGridView1.Columns(5).Width = 92
        DataGridView1.Columns(5).Visible = True
        DataGridView1.Columns.Add("Price", "Total Price")
        DataGridView1.Columns(6).Width = 92
        DataGridView1.Columns.Item(6).DefaultCellStyle.Format = "####.#0"
        DataGridView1.Columns(6).Visible = False
        DataGridView1.Columns.Add("Disc_Code", "Disc_Code")
        DataGridView1.Columns(7).Width = 92
        DataGridView1.Columns(7).Visible = False
        DataGridView1.Columns.Add("Discount", "Discount")
        DataGridView1.Columns(8).Width = 92
        DataGridView1.Columns.Item(8).DefaultCellStyle.Format = "####.#0"
        DataGridView1.Columns(8).Visible = False
    End Sub

    Sub Compute()
        Dim totalitems As Integer = 0
        Dim totalamt As Double = 0.0
        Dim totaldisc As Double = 0.0

        If DataGridView1.RowCount > 0 Then

            For index As Integer = 0 To DataGridView1.RowCount - 1
                totalitems += CInt(DataGridView1.Rows(index).Cells(4).Value)
                totalamt += FormatNumber(DataGridView1.Rows(index).Cells(6).Value, 2)
                totaldisc += FormatNumber(DataGridView1.Rows(index).Cells(8).Value, 2)
            Next
        End If

        txtTotalItems.Text = totalitems
        'totalamt = totalamt - totaldisc 'DISCOUNTED PRICE
        'txtTotalPrice.Text = FormatNumber(totalamt, 2)
        txtTotalPrice.Text = FormatNumber(Decimal.Round(CDec(totalamt), 2), 2)
        'txtVatable.Text = FormatNumber(totalamt / Vatable, 2)
        txtVatable.Text = Decimal.Round(CDec(totalamt / Vatable), 2)
        'txtVat.Text = FormatNumber(FormatNumber(totalamt / Vatable, 2) * VAT, 2)
        txtVat.Text = Decimal.Round(CDec(txtVatable.Text) * CDec(VAT), 2)
        'txtDiscount.Text = FormatNumber(totaldisc, 2)
        txtDiscount.Text = FormatNumber(Decimal.Round(CDec(totaldisc), 2), 2)
    End Sub

    Public Sub GetItemWithoutSize(prodID As Integer, item As String, price As Double)
        'CHECK STOCKS FIRST
        'Dim sql As String
        'Dim publictable As New DataTable

        'sql = "SELECT ((COALESCE(SUM(Quantity),0)) - " _
        '    & "(SELECT COALESCE(SUM(Quantity),0) FROM transactiondetails WHERE ProdID = '" & prodID & "'))AS Stock " _
        '    & "FROM stockinventory WHERE stockinventory.ProdID = '" & prodID & "'"

        'With cmd
        '    .Connection = MysqlConn
        '    .CommandText = sql
        'End With

        'da.SelectCommand = cmd
        'da.Fill(publictable)

        'Dim stock As Integer = publictable.Rows(0).Item(0)
        'If stock <= 0 Then
        '    'IF NO STOCK AVAILABLE
        '    MsgBox("Out of stock", vbExclamation + vbOKOnly, "System")
        'Else
        'IF ITEM HAS STOCK

        '--- NO STOCK VALIDATION ---
        Dim Prodname As String
        Dim qty As Integer = 1
        Dim ProdPrice As Double 'price * qty


        Prodname = item
        ProdPrice = qty * price

        Dim RecordFound As Boolean = False

        For Each oRow As DataGridViewRow In DataGridView1.Rows
            Dim oPRoductCell As DataGridViewCell = oRow.Cells(1)
            If oPRoductCell.Value = Prodname & "(ADD-ON)" Then

                oRow.Cells(4).Value += qty
                oRow.Cells(6).Value = oRow.Cells(4).Value * price

                RecordFound = True
                Compute()
                Me.Focus()
            End If
        Next


        If RecordFound = False Then
            DataGridView1.Rows.Add(prodID, Prodname & "(ADD-ON)", "", price, qty, "", ProdPrice, "", FormatNumber(0, 2))
            Compute()
            Me.Focus()
        End If
        'End If

    End Sub

    Public Sub GetItemWithSize(size As String, prodID As Integer, item As String, itemQty As Integer, price As Double, sugarlevel As String)
        'CHECK STOCKS FIRST
        'Dim sql As String
        'Dim publictable As New DataTable

        'sql = "SELECT ((COALESCE(SUM(Quantity),0)) - " _
        '    & "(SELECT COALESCE(SUM(Quantity),0) FROM transactiondetails WHERE ProdID = '" & prodID & "'))AS Stock " _
        '    & "FROM stockinventory WHERE stockinventory.ProdID = '" & prodID & "'"

        'With cmd
        '    .Connection = MysqlConn
        '    .CommandText = sql
        'End With

        'da.SelectCommand = cmd
        'da.Fill(publictable)

        'Dim stock As Integer = publictable.Rows(0).Item(0)
        'If stock <= 0 Then
        '    'IF NO STOCK AVAILABLE
        '    MsgBox("Out of stock", vbExclamation + vbOKOnly, "System")
        'Else
        'IF ITEM HAS STOCK

        '--- NO STOCK VALIDATION ---
        Dim Prodname As String
        Dim qty As Integer = itemQty
        Dim ProdPrice As Double 'price * qty

        Prodname = item
        If size = "R" Then
            price += 20
        ElseIf size = "L" Then
            price += 40
        End If

        ProdPrice = qty * price

        Dim RecordFound As Boolean = False

        For Each oRow As DataGridViewRow In DataGridView1.Rows
            Dim oPRoductCell As DataGridViewCell = oRow.Cells(1)
            If oPRoductCell.Value = Prodname & "(" & size & ")" Then

                oRow.Cells(4).Value += qty
                oRow.Cells(6).Value = oRow.Cells(4).Value * price

                RecordFound = True
                Compute()
                Me.Focus()
            End If
        Next


        If RecordFound = False Then
            'If size = "L" Then
            '    price += 20
            'End If
            DataGridView1.Rows.Add(prodID, Prodname & "(" & size & ")", size, price, qty, sugarlevel, ProdPrice, "", FormatNumber(0, 2))
            Compute()
            Me.Focus()
        End If
        'End If

    End Sub


    Sub CreateTransactionHeader(isVoided As Boolean, totalItems As Integer, totalprice As Double, vatable As Double, vat As Double, discount As Double, SoldTo As String, AmountPaid As Double, ChangeAmt As Double, userid As Integer, crid As Integer)
        Dim result As Integer

        Try
            'we open Connection
            'MysqlConn.Open()
            'Dim cat_index As Integer = ComboBox1.SelectedIndex
            With cmd
                .Connection = MysqlConn
                .CommandText = "INSERT INTO transactionheader" _
                    & "(IsVoided,TotalItems,TotalPrice,Vatable,VAT,Discount,SoldTo,AmountPaid,ChangeAmt,UserID,CReadingID) VALUES(@IsVoided,@TotalItems,@TotalPrice,@Vatable,@VAT,@Discount,@SoldTo,@AmtPayed,@ChangeAmt,@uid,@crid)"

                .Parameters.AddWithValue("@IsVoided", isVoided)
                .Parameters.AddWithValue("@TotalItems", totalItems)
                .Parameters.AddWithValue("@TotalPrice", FormatNumber(totalprice, 2))
                .Parameters.AddWithValue("@Vatable", FormatNumber(vatable, 2))
                .Parameters.AddWithValue("@VAT", FormatNumber(vat, 2))
                .Parameters.AddWithValue("@Discount", FormatNumber(discount, 2))
                .Parameters.AddWithValue("@SoldTo", If(SoldTo, DBNull.Value))
                .Parameters.AddWithValue("@AmtPayed", FormatNumber(AmountPaid, 2))
                .Parameters.AddWithValue("@ChangeAmt", FormatNumber(ChangeAmt, 2))
                .Parameters.AddWithValue("@uid", userid)
                .Parameters.AddWithValue("@crid", crid)

                'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                result = cmd.ExecuteNonQuery
                'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                Else
                    cmd.Parameters.Clear()
                    CreateTransactionDetails(GetLastTransID(CashierID, ReadingID), SoldTo)
                End If
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Public Function GetLastTransID(cid As Integer, crid As Integer)
        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT MAX(TransID) FROM transactionheader WHERE UserID = @uid AND CReadingID = @crid"

        With cmd
            .Connection = MysqlConn
            .CommandText = sql
            .Parameters.AddWithValue("@uid", cid)
            .Parameters.AddWithValue("@crid", crid)
        End With

        da.SelectCommand = cmd
        da.Fill(publictable)

        cmd.Parameters.Clear()
        Return publictable.Rows(0).Item(0)
    End Function


    Sub CreateTransactionDetails(transID As Integer, soldto As String)
        Dim result As Integer

        Try
            'we open Connection
            'MysqlConn.Open()
            'Dim cat_index As Integer = ComboBox1.SelectedIndex
            For Each ProductInList As DataGridViewRow In DataGridView1.Rows
                With cmd
                    .Connection = MysqlConn
                    .CommandText = "INSERT INTO transactiondetails" _
                        & "(TransID,ProdID,ProdName,Quantity,Price,TotalPrice,DiscCode,DiscountValue,CReadingID) VALUES(@TransID,@ProdID,@ProdName,@Quantity,@Price,@TotalPrice,@disccode,@discval,@crid)"

                    .Parameters.AddWithValue("@TransID", transID)
                    .Parameters.AddWithValue("@ProdID", ProductInList.Cells("ProdID").Value)
                    .Parameters.AddWithValue("@ProdName", ProductInList.Cells("Item").Value)
                    .Parameters.AddWithValue("@Quantity", ProductInList.Cells("Qty").Value)
                    .Parameters.AddWithValue("@Price", FormatNumber(ProductInList.Cells("OriginalPrice").Value, 2))
                    .Parameters.AddWithValue("@TotalPrice", FormatNumber(ProductInList.Cells("Price").Value, 2))
                    .Parameters.AddWithValue("@disccode", ProductInList.Cells("Disc_Code").Value)
                    .Parameters.AddWithValue("@discval", FormatNumber(ProductInList.Cells("Discount").Value, 2))
                    .Parameters.AddWithValue("@crid", ReadingID)

                    'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                    result = cmd.ExecuteNonQuery
                    'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                    If result = 0 Then
                        MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                        Exit Sub
                    End If
                End With
                cmd.Parameters.Clear()
            Next
            'MsgBox("Processed Successfully!", vbInformation + vbOKOnly, "Process Complete")
            cmd.Parameters.Clear()

            Dim preview As New ReceiptPreview 'Print Receipt Form
            preview.strPrint = PrepareTransactionReceipt(GetLastTransID(CashierID, ReadingID), 1, "", soldto)
            preview.ShowDialog()

            HasAppliedDisc = False
            DataGridView1.Rows.Clear()
            ResetFields()
        Catch ex As Exception
            MsgBox(ex.Message)
            cmd.Parameters.Clear()
        End Try

        cmd.Parameters.Clear()
    End Sub

    Sub ResetFields()
        txtTotalItems.Text = 0
        txtTotalPrice.Text = FormatNumber(0, 2)
        txtDiscount.Text = FormatNumber(0, 2)
        txtVatable.Text = FormatNumber(0, 2)
        txtVat.Text = FormatNumber(0, 2)
    End Sub

    Private Sub POS_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Login.Show()
    End Sub

    Private Sub POS_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F12 Then
            If DataGridView1.Rows.Count > 0 Then

                Dim checkout As New POS_CheckOutSummary
                With checkout
                    .TotalItems = CInt(txtTotalItems.Text)
                    .TotalAmount = CDbl(txtTotalPrice.Text)
                    .TotalVatable = CDbl(txtVatable.Text)
                    .TotalVat = CDbl(txtVat.Text)
                    .LoadSubtotal()
                    .TextBox1.Focus()
                End With
                checkout.ShowDialog()

                'CreateTransactionHeader(False, CInt(txtTotalItems.Text), CDbl(txtTotalPrice.Text), CDbl(txtVatable.Text), CDbl(txtVat.Text), LoggedUserID, ReadingID)
            Else
                'MsgBox("no items in transaction list!", vbExclamation + vbOKOnly, "No items")
                'Do Nothing
            End If
        End If
    End Sub

    Private Sub POS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CheckIFCashierReadingExists()
        CreateRows()
    End Sub

    Sub CheckIFCashierIDIsSet()
        If CashierID = 0 And ReadingID = 0 Then
            Dim createdFund As New EnterChangeFund
            createdFund.ShowDialog() 'CREATE
        End If
    End Sub

    Sub CheckIFCashierReadingExists()
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT * FROM reading_cashier WHERE CashierID = @cid and Date(DateCreated) = Date(NOW()) and ReadingStatus = 'OPEN'"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
            .Parameters.AddWithValue("@cid", LoggedUserID)
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        cmd.Parameters.Clear()

        If table.Rows.Count > 0 Then
            LoadCashierReading(table.Rows(0).Item(1).ToString, "Open") 'LOAD
            'ElseIf table.Rows(0).Item(2).ToString = "Close" Then
        End If
    End Sub


    Private Sub DataGridView1_KeyDown(sender As Object, e As KeyEventArgs) Handles DataGridView1.KeyDown
        If e.KeyCode = Keys.Delete Then
            If DataGridView1.Rows.Count = 0 Then
                'nothing
            Else
                Dim a = MsgBox("Remove the selected item?", vbQuestion + vbYesNo)
                If a = MsgBoxResult.Yes Then
                    DataGridView1.Rows.Remove(DataGridView1.CurrentRow())
                    Compute()
                End If
            End If

        ElseIf e.KeyCode = Keys.Escape Then
            DataGridView1.Rows.Clear()
            Compute()
        ElseIf e.KeyCode = Keys.Back Then
            If DataGridView1.CurrentRow.Cells(3).Value = 1 Then
                'Do Nothing
            Else
                DataGridView1.CurrentRow.Cells(3).Value -= 1
                DataGridView1.CurrentRow.Cells(4).Value = FormatNumber(CInt(DataGridView1.CurrentRow.Cells(2).Value) * CInt(DataGridView1.CurrentRow.Cells(3).Value), 2)

                Compute()
            End If
        End If
    End Sub

    'FOR calling GetItem function
    'GetItem(1001, Label4.Text, FormatNumber(CDbl(60.0), 2))

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        If DataGridView1.Rows.Count > 0 Then
            Dim checkout As New POS_CheckOutSummary
            With checkout
                .TotalItems = CInt(txtTotalItems.Text)
                .TotalAmount = CDbl(txtTotalPrice.Text)
                .TotalVatable = CDbl(txtVatable.Text)
                .TotalVat = CDbl(txtVat.Text)
                .totalDiscount = CDbl(txtDiscount.Text)
                .LoadSubtotal()
                .TextBox1.Focus()
            End With
            checkout.ShowDialog()

            'CreateTransactionHeader(False, CInt(txtTotalItems.Text), CDbl(txtTotalPrice.Text), CDbl(txtVatable.Text), CDbl(txtVat.Text), LoggedUserID, ReadingID)
        Else
            'MsgBox("no items in transaction list!", vbExclamation + vbOKOnly, "No items")
            'Do Nothing
        End If

    End Sub

    Private Sub btnViewTransaction_Click(sender As Object, e As EventArgs) Handles btnViewTransaction.Click
        POS_Transactions.ShowDialog()
    End Sub

    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        CheckIFCashierIDIsSet()
        LoadButtons(1)
    End Sub

    Sub LoadButtons(catType As Integer)
        'CLEAR FlowLayoutPanel Controls
        If FlowLayoutPanel1.Controls.Count > 0 Then
            Dim cnt As Integer = FlowLayoutPanel1.Controls.Count - 1
            While FlowLayoutPanel1.Controls.Count > 0
                FlowLayoutPanel1.Controls(cnt).Dispose()
                cnt -= 1
            End While
        End If

        Dim publictable As New DataTable
        Dim sql As String

        sql = "SELECT ProdID,CatType,(SELECT category from categories WHERE catID = CatType) as CatName,ProdName,price from products WHERE CatType = @cat"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
            .Parameters.AddWithValue("@cat", catType)
        End With

        With da
            .SelectCommand = cmd
            .Fill(publictable)
            .Fill(table) 'used for setting up AddHandler with Call Function
        End With

        cmd.Parameters.Clear()

        If table.Rows.Count > 0 Then
            For i As Integer = 0 To publictable.Rows.Count - 1
                Dim b As Button = New Button() 'Create new button

                'set button properties
                b.Name = "Button" + (i + 1).ToString
                b.Text = publictable.Rows(i).Item("ProdName").ToString
                b.ForeColor = SystemColors.ControlText
                b.BackColor = Color.FromArgb(255, 255, 192)
                b.Font = New Font("Comic Sans MS", 12, FontStyle.Bold)
                b.Width = 155
                b.Height = 85
                b.TextAlign = ContentAlignment.MiddleCenter
                b.Margin = New Padding(6)

                'add button to FlowLayoutPanel
                FlowLayoutPanel1.Controls.Add(b)

                'add Handler (EventHandler)
                AddHandler b.Click, AddressOf ButtonClick
            Next
            FlowLayoutPanel1.FlowDirection = FlowLayoutPanel1.FlowDirection 'refresh FlowLayoutPanel
        End If

    End Sub


    'For creating EventHandler on generated buttons
    Private Sub ButtonClick(sender As Object, e As EventArgs)
        Dim btn As Button = DirectCast(sender, Button)

        Dim dr() As System.Data.DataRow 'Array
        dr = table.Select("ProdName='" & btn.Text & "'") 'get data form table, them search for specific Product Name
        If dr.Length > 0 Then
            'Array(Selected Record) = Array(ProdID),Array(ProdName),Array(Price)
            If dr(0)("CatName") = "ADD-ONS" Then
                GetItemWithoutSize(dr(0)("ProdID").ToString, dr(0)("ProdName").ToString, FormatNumber(CDbl(dr(0)("price").ToString), 2))
            Else
                Dim selectSize As New SelectSize
                selectSize.PrepareInitialValues(dr(0)("ProdID").ToString, dr(0)("ProdName").ToString, FormatNumber(CDbl(dr(0)("price").ToString), 2))
                selectSize.ShowDialog()
            End If
        End If

    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        CheckIFCashierIDIsSet()
        LoadButtons(2)
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        CheckIFCashierIDIsSet()
        LoadButtons(3)
    End Sub

    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        CheckIFCashierIDIsSet()
        LoadButtons(4)
    End Sub

    Private Sub btn5_Click(sender As Object, e As EventArgs) Handles btn5.Click
        CheckIFCashierIDIsSet()
        LoadButtons(5)
    End Sub

    Private Sub btn6_Click(sender As Object, e As EventArgs) Handles btn6.Click
        CheckIFCashierIDIsSet()
        LoadButtons(6)
    End Sub

    Private Sub btn7_Click(sender As Object, e As EventArgs) Handles btn7.Click
        CheckIFCashierIDIsSet()
        LoadButtons(7)
    End Sub

    Private Sub btn8_Click(sender As Object, e As EventArgs) Handles btn8.Click
        CheckIFCashierIDIsSet()
        LoadButtons(8)
    End Sub

    Private Sub btn9_Click(sender As Object, e As EventArgs) Handles btn9.Click
        CheckIFCashierIDIsSet()
        LoadButtons(9)
    End Sub

    Private Sub btn10_Click(sender As Object, e As EventArgs) Handles btn10.Click
        CheckIFCashierIDIsSet()
        LoadButtons(10)
    End Sub

    Private Sub btn11_Click(sender As Object, e As EventArgs) Handles btn11.Click
        CheckIFCashierIDIsSet()
        LoadButtons(11)
    End Sub

    Private Sub btn12_Click(sender As Object, e As EventArgs) Handles btn12.Click
        CheckIFCashierIDIsSet()
        LoadButtons(12)
    End Sub

    Private Sub btn13_Click(sender As Object, e As EventArgs) Handles btn13.Click
        CheckIFCashierIDIsSet()
        LoadButtons(13)
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If DataGridView1.Rows.Count = 0 Then
            'nothing
        Else
            Dim a = MsgBox("Remove the selected item?", vbQuestion + vbYesNo)
            If a = MsgBoxResult.Yes Then
                DataGridView1.Rows.Remove(DataGridView1.CurrentRow())
                Compute()
            End If
        End If
    End Sub

    Private Sub btnCancel_Click_1(sender As Object, e As EventArgs) Handles btnCancel.Click
        If DataGridView1.Rows.Count = 0 Then
            'nothing
        Else
            If MsgBox("Cancel current transaction?", vbQuestion + vbYesNo, "System") = MsgBoxResult.Yes Then

                'CLEAR FlowLayoutPanel Controls
                If FlowLayoutPanel1.Controls.Count > 0 Then
                    Dim cnt As Integer = FlowLayoutPanel1.Controls.Count - 1
                    While FlowLayoutPanel1.Controls.Count > 0
                        FlowLayoutPanel1.Controls(cnt).Dispose()
                        cnt -= 1
                    End While
                End If

                HasAppliedDisc = False
                DataGridView1.Columns.Clear()
                CreateRows()
                Compute()
            End If
        End If
    End Sub

    Private Sub btnMinus_Click(sender As Object, e As EventArgs) Handles btnMinus.Click
        If DataGridView1.Rows.Count = 0 Then
            'Do Nothing
        ElseIf DataGridView1.CurrentRow.Cells(4).Value = 1 Then
            'Do Nothing
        Else
            DataGridView1.CurrentRow.Cells(4).Value -= 1
            DataGridView1.CurrentRow.Cells(6).Value = FormatNumber(CInt(DataGridView1.CurrentRow.Cells(4).Value) * CInt(DataGridView1.CurrentRow.Cells(3).Value), 2)

            Compute()
        End If
    End Sub

    Private Sub btnReadings_Click(sender As Object, e As EventArgs) Handles btnReadings.Click
        Dim generateReading As New SelectReading
        generateReading.ShowDialog()
    End Sub

    Public Function PrepareTransactionReceipt(transID As Integer, printmode As Integer, printDate As String, soldto As String)
        Dim strPrint As String

        Dim config As New IniFile(Application.StartupPath & "\" & "Config.ini")

        'RECEIPT HEADER
        Dim CompanyName As String = config.GetString("Receipt", "StoreName", "Company XYZ")
        Dim CompanyAddress As String = config.GetString("Receipt", "StoreAddress", "Address Here")

        strPrint = " " & vbCrLf
        'strPrint = strPrint & " " & vbCrLf
        strPrint = strPrint & CompanyName.ToString.PadLeft(21) & vbCrLf
        strPrint = strPrint & CompanyAddress.ToString.PadLeft(28) & vbCrLf
        If printmode = 2 Then 'RE-PRINT
            strPrint = strPrint & "RE-PRINTED RECEIPT".ToString.PadLeft(26) & vbCrLf
        Else
            'do nothing
        End If
        strPrint = strPrint & " " & vbNewLine

        'BODY
        Dim sql As String
        Dim table As New DataTable

        'Transaction Number and Date
        If printmode = 2 Then 'RE-PRINT
            strPrint = strPrint & "".PadRight(3) & "TN:".ToString.PadRight(2) & transID.ToString.PadRight(10) & "Date:".PadRight(2) & printDate & vbCrLf
        Else
            strPrint = strPrint & "".PadRight(3) & "TN:".ToString.PadRight(2) & transID.ToString.PadRight(10) & "Date:".PadRight(2) & Format(Date.Today, "MM/dd/yyyy") & vbCrLf
        End If

        strPrint = strPrint & "" & vbNewLine & vbCrLf
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        strPrint = strPrint & " " & vbNewLine

        'Items
        sql = "SELECT ProdName,Quantity,Price,DiscountValue," _
            & "(SELECT AmountPaid FROM transactionheader where TransID = transactiondetails.TransID) as AmountPaid," _
            & "(SELECT ChangeAmt FROM transactionheader where TransID = transactiondetails.TransID) as ChangeAmt FROM transactiondetails WHERE TransID = @transID"
        table = New DataTable
        Try
            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@transID", transID)
            End With

            da.SelectCommand = cmd
            da.Fill(table)

            cmd.Parameters.Clear()
            Dim totalqty As Integer = 0
            Dim subtotal As Double = 0.0
            Dim totaldisc As Double = 0.0
            Dim amtPaid As Double = 0.0
            Dim change As Double = 0.0

            For Each row As DataRow In table.Rows
                Dim quantity As Integer = row.Item("Quantity")
                Dim price As Double = FormatNumber(row.Item("Price"), 2)
                Dim totalprice As Double = FormatNumber(quantity * price)
                Dim disc As Double = FormatNumber(row.Item("DiscountValue"), 2)
                totalqty += quantity
                subtotal += totalprice
                totaldisc += disc
                amtPaid = FormatNumber(row.Item("AmountPaid"), 2)
                change = FormatNumber(row.Item("ChangeAmt"), 2)
                strPrint = strPrint & "".PadRight(1) & Strings.Left(row.Item("ProdName"), 17).ToString.PadRight(20) & (price & "x" & quantity).ToString.PadRight(7) & FormatNumber(totalprice, 2).ToString.PadLeft(6) & vbCrLf
            Next


            'Subtotal,Vatable,VAT
            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Sub Total".ToString.PadRight(20) & FormatNumber(subtotal, 2).ToString.PadLeft(13) & vbCrLf

            subtotal = subtotal - totaldisc 'Discount deducted to subtotal

            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & " ".PadRight(1) & "LESS:" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "DISCOUNT".ToString.PadRight(20) & FormatNumber(totaldisc, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "No of Items".ToString.PadRight(20) & totalqty.ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Vatable".ToString.PadRight(20) & FormatNumber(subtotal / Vatable, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "VAT".ToString.PadRight(20) & FormatNumber(FormatNumber(subtotal / Vatable, 2) * VAT, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "TOTAL".ToString.PadRight(20) & FormatNumber(subtotal, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "SOLD TO".ToString.PadRight(20) & soldto.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Amount Paid".ToString.PadRight(20) & FormatNumber(amtPaid, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Change".ToString.PadRight(20) & FormatNumber(change, 2).ToString.PadLeft(13) & vbCrLf
        Catch ex As Exception
            'MsgBox(ex.Message)
            If MsgBox(ex.Message) = DialogResult.OK Then
                cmd.Parameters.Clear()
            End If
        End Try

        'FOOTER
        Dim Message1 As String = config.GetString("Receipt", "Message1", "Message1")
        Dim Message2 As String = config.GetString("Receipt", "Message2", "Message2")
        Dim Message3 As String = config.GetString("Receipt", "Message3", "Message3")

        strPrint = strPrint & " " & vbCrLf
        strPrint = strPrint & Message1.ToString.PadLeft(26.5) & vbCrLf
        strPrint = strPrint & Message2.ToString.PadLeft(25) & vbCrLf
        strPrint = strPrint & Message3.ToString.PadLeft(22) & vbCrLf

        Return strPrint
        'Printer.Print(strPrint)
    End Function

    Private Sub btnApplyDisc_Click(sender As Object, e As EventArgs) Handles btnApplyDisc.Click

        If DataGridView1.Rows.Count = 0 Then
            'do nothing
        Else
            'If DataGridView1.CurrentRow.Cells("Disc_Code").Value <> String.Empty Then
            If HasAppliedDisc = True Then
                MsgBox("Remove the applied discount before applying a new discount", vbExclamation + vbOKOnly, "System")
            Else
                Dim DiscSelect As New DiscountSelector
                DiscSelect.ShowDialog()
            End If
        End If
        

    End Sub

    Private Sub btnRemoveDisc_Click(sender As Object, e As EventArgs) Handles btnRemoveDisc.Click
        If DataGridView1.Rows.Count = 0 Then
            'do nothing
        Else
            If MsgBox("Remove applied discount to all items?", vbQuestion + vbYesNo, "System") = MsgBoxResult.Yes Then
                For Each oRow As DataGridViewRow In DataGridView1.Rows
                    oRow.Cells("Price").Value = FormatNumber(oRow.Cells("OriginalPrice").Value * oRow.Cells("Qty").Value, 2)
                    oRow.Cells("Disc_Code").Value = ""
                    oRow.Cells("Discount").Value = FormatNumber(0.0, 2)
                Next
                Compute() 're-compute
                HasAppliedDisc = False
            Else
                'Do Nothing
            End If
        End If
    End Sub


End Class