﻿Imports System.IO
Public Class Login

    'Public Sub MysqlConnection()
    '    MysqlConn = New MySql.Data.MySqlClient.MySqlConnection

    '    'Connection String
    '    MysqlConn.ConnectionString = "server=localhost;" _
    '    & "user id=root;" _
    '    & "password=;" _
    '    & "database=dbmangchaa"

    '    'OPENING THE MysqlConnNECTION
    '    MysqlConn.Open()

    'End Sub
    Public Sub VerifyAccount()
        Dim sql As String
        Dim publictable As New DataTable

        Try
            'check if the textbox is equal to nothing then it will display the message below!.
            If TextBox1.Text = "" Or TextBox2.Text = "" Then
                MsgBox("Please enter username and password", vbOKOnly + vbCritical, "System")
                TextBox1.Focus()

            Else
                sql = "select id,uname,pword,userlevel,empstatus,concat(fname,' ',lname) as EmpName from employees where uname = @user and pword = @pass and empstatus = 1"
                'bind the MysqlConnnection and query
                With cmd
                    .Connection = MysqlConn
                    .CommandText = sql
                    .Parameters.AddWithValue("@user", TextBox1.Text)
                    .Parameters.AddWithValue("@pass", TextBox2.Text)
                End With

                da.SelectCommand = cmd
                da.Fill(publictable)
                'Dim FILENAME As String = "C:\Users\audrey\Documents\log.txt"
                'check if theres a result by getting the count number of rows
                If publictable.Rows.Count > 0 Then

                    'it gets the data from specific column and assign to the variable
                    Dim user, pass As String
                    Dim level As Integer
                    user = publictable.Rows(0).Item(1)
                    pass = publictable.Rows(0).Item(2)
                    level = publictable.Rows(0).Item(3)


                    'check if the type of user is admin
                    'Dim FILE_NAME As String = "C:\Users\audrey\Documents\log.txt"
                    'If System.IO.File.Exists(FILE_NAME) = True And level = "1" Then
                    If user.Equals(TextBox1.Text) = True And pass.Equals(TextBox2.Text) And level <= 2 Then
                        'welcomes the user as Administrator

                        'Dim objWriter As New System.IO.StreamWriter(FILE_NAME, True)

                        'objWriter.WriteLine(TextBox1.Text & " - " & Now & " - " & "Success")
                        'objWriter.Close()

                        MsgBox("Welcome " & user & ". Admin", vbOKOnly + vbInformation, "System")

                        'get user credentials
                        LoggedUserID = publictable.Rows(0).Item(0)
                        LoggedUserLvl = level

                        TextBox1.Text = ""
                        TextBox2.Text = ""

                        'OnlyOwner.Show()
                        SysManager.Label1.Text = "Hello, " & publictable.Rows(0).Item("EmpName") & "!"
                        SysManager.Timer1.Enabled = True
                        SysManager.Show()
                        Me.Close()

                    ElseIf user.Equals(TextBox1.Text) = True And pass.Equals(TextBox2.Text) And level = 3 Then
                        'welcomes the user as Staff

                        'Dim objWriter As New System.IO.StreamWriter(FILE_NAME, True)

                        'objWriter.WriteLine(TextBox1.Text & " - " & Now & " - " & "Success")
                        'objWriter.Close()

                        MsgBox("Welcome " & user & ". Staff", vbOKOnly + vbInformation, "System")

                        'get user credentials
                        LoggedUserID = publictable.Rows(0).Item(0)
                        LoggedUserLvl = level

                        TextBox1.Text = ""
                        TextBox2.Text = ""

                        'LOAD DEFAULT VALUES
                        CashierID = 0
                        ReadingID = 0

                        HasPerformedEOD = CheckStatus_EOD()

                        If HasPerformedEOD = True Then
                            MsgBox("This register has already performed EOD.", vbExclamation + vbOKOnly, "System")
                        Else
                            POS.Show()
                            Me.Close()
                        End If

                    Else
                        MsgBox("Username or Password is invalid", vbOKOnly + vbCritical, "System")
                        TextBox1.Text = ""
                        TextBox2.Text = ""
                        TextBox1.Focus()
                    End If
                    'ElseIf System.IO.File.Exists(FILENAME) = True Then
                Else
                    'Dim objWriters As New System.IO.StreamWriter(FILENAME, True)

                    'objWriters.WriteLine(TextBox1.Text & " - " & Now & " - " & "Failed")
                    'objWriters.Close()

                    MsgBox("Your Account is Invalid", vbOKOnly + vbCritical, "System")
                    TextBox1.Text = ""
                    TextBox2.Text = ""
                    TextBox1.Focus()

                    'Else

                    'File.Create("C:\Users\audrey\Documents\log.txt").Dispose()
                End If

                    da.Dispose()
                End If

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
        cmd.Parameters.Clear()
    End Sub

    Private Sub PassShow_Hide_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Form Load
        LoadConfiguration() 'Load Configurations
        MysqlConnection() 'Prepare and open connection
        lblDate.Text = Date.Today
        LblTime.Text = TimeOfDay
        Timer1.Enabled = True
        TextBox2.UseSystemPasswordChar = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        VerifyAccount()
        'Me.Hide()

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If TextBox2.UseSystemPasswordChar = True Then

            TextBox2.UseSystemPasswordChar = False
            CheckBox1.Text = "Show Password"

        Else

            TextBox2.UseSystemPasswordChar = True
            CheckBox1.Text = "Show Password"

        End If
    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If MsgBox("Are you sure you want to close ?", MsgBoxStyle.YesNo) = Windows.Forms.DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblDate.Text = Date.Today
        LblTime.Text = TimeOfDay
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Dim recovery As New PasswordRecovery
        recovery.ShowDialog()
    End Sub
End Class