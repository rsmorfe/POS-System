﻿Public Class POS_Transactions

    Sub LoadRecords()
        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT * FROM transactionheader WHERE UserID = @uid AND DATE(DateCreated) = DATE(NOW()) ORDER BY DateCreated DESC"

        With cmd
            .Connection = MysqlConn
            .CommandText = sql
            .Parameters.AddWithValue("@uid", LoggedUserID)
        End With

        da.SelectCommand = cmd
        da.Fill(publictable)

        DataGridView1.DataSource = publictable
        'DataGridView1.Columns(0).Width = 100
        'DataGridView1.Columns(1).Width = 200
        'DataGridView1.Columns(2).Width = 100
        'DataGridView1.Columns.Item(2).DefaultCellStyle.Format = "####.#0"
        DataGridView1.Columns(8).Visible = False

        cmd.Parameters.Clear()

    End Sub

    Sub SearchTransaction(txt As String, dateCreated As String)
        Dim sql As String
        Dim publictable As New DataTable

        If txt.Equals("") = True Then
            sql = "SELECT * FROM transactionheader WHERE DATE_FORMAT(DateCreated,'%Y-%m-%d') = @date AND UserID = @uid ORDER BY DateCreated DESC"

            With cmd
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@date", dateCreated)
                .Parameters.AddWithValue("@uid", LoggedUserID)
            End With
        Else
            Sql = "SELECT * FROM transactionheader WHERE TransID = @tid AND DATE_FORMAT(DateCreated,'%Y-%m-%d') = @date AND UserID = @uid ORDER BY DateCreated DESC"

            With cmd
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@tid", txt)
                .Parameters.AddWithValue("@date", dateCreated)
                .Parameters.AddWithValue("@uid", LoggedUserID)
            End With
        End If

        da.SelectCommand = cmd
        da.Fill(publictable)

        DataGridView1.DataSource = publictable
        'DataGridView1.Columns(0).Width = 100
        'DataGridView1.Columns(1).Width = 200
        'DataGridView1.Columns(2).Width = 100
        'DataGridView1.Columns.Item(2).DefaultCellStyle.Format = "####.#0"
        DataGridView1.Columns(8).Visible = False

        cmd.Parameters.Clear()

    End Sub

    Private Sub DataGridView1_KeyDown(sender As Object, e As KeyEventArgs) Handles DataGridView1.KeyDown
        If e.KeyCode = Keys.Enter Then
            Dim row As DataGridViewRow = DataGridView1.CurrentRow

            On Error Resume Next
            If row.Cells(0).Value.ToString() = "" Then
                'do nothing
            Else

            End If
        End If
    End Sub


    Private Sub POS_Transactions_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadRecords()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        SearchTransaction(txtSearch.Text, DateTimePicker1.Value.ToString("yyyy-MM-dd"))

    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtSearch.Text = "" Then
                LoadRecords()
            Else
                SearchTransaction(txtSearch.Text, DateTimePicker1.Value.ToString("yyyy-MM-dd"))
            End If
        End If
    End Sub

    Private Sub txtReprint_Click(sender As Object, e As EventArgs) Handles txtReprint.Click

        Dim preview As New ReceiptPreview 'Print Receipt Form

        'Dim ConvertedDate As Date = CType(DataGridView1.CurrentRow.Cells("DateCreated").Value, Date).ToString("MM/dd/yyyy")

        'Format(DataGridView1.CurrentRow.Cells("DateCreated").Value, "yyyy-MM-dd")
        preview.strPrint = POS.PrepareTransactionReceipt(CInt(DataGridView1.CurrentRow.Cells("TransID").Value), 2, Format(DataGridView1.CurrentRow.Cells("DateCreated").Value, "MM/dd/yyyy"), DataGridView1.CurrentRow.Cells("SoldTo").Value)
        'set ControlBox property
        preview.ControlBox = True
        preview.MinimizeBox = False
        preview.MaximizeBox = False
        preview.ShowDialog()
    End Sub

End Class