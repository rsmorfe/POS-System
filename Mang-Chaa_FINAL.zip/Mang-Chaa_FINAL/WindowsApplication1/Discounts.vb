﻿Public Class Discounts
    Private selected_id As Integer

    Private Sub Discounts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDiscounts()
        SetButtons(True, False, False, False)
    End Sub

    Sub LoadDiscounts()
        DataGridView1.DataSource = "" 'CLEAR/REFRESH DataGrid

        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT * FROM discount"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        cmd.Parameters.Clear()

        DataGridView1.DataSource = table
        DataGridView1.Columns("id").Visible = False
    End Sub

    Sub CreateDiscount(code As String, type As String, value As Double)
        Dim sql As String

        sql = "INSERT INTO discount(DiscountCode,DiscountType,DiscountValue)VALUES(@code,@name,@value)"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
            .Parameters.AddWithValue("@code", code)
            .Parameters.AddWithValue("@name", type)
            .Parameters.AddWithValue("@value", value)
        End With

        Dim result As Integer
        Try
            result = cmd.ExecuteNonQuery

            If result > 0 Then
                MsgBox("New Discount Type created", vbInformation + vbOKOnly, "System")
                cmd.Parameters.Clear()

                ClearFields()
                SetButtons(True, False, False, False)

                txtDiscCode.Enabled = False
                txtDiscType.Enabled = False
                txtDiscVal.Enabled = False

                LoadDiscounts()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            cmd.Parameters.Clear()
        End Try
    End Sub

    Sub UpdateDiscount(id As Integer, code As String, type As String, value As Double)
        Dim sql As String
        sql = "UPDATE discount set DiscountCode = @code, DiscountType = @type, DiscountValue = @val WHERE id = @id"

        With cmd
            .Connection = MysqlConn
            .CommandText = sql
            .Parameters.AddWithValue("@code", code)
            .Parameters.AddWithValue("@type", type)
            .Parameters.AddWithValue("@val", value)
            .Parameters.AddWithValue("@id", id)
        End With

        Dim result As Integer

        result = cmd.ExecuteNonQuery()
        If result > 0 Then
            MsgBox("Successfully updated", vbInformation + vbOKOnly, "System")

            ClearFields()
            SetButtons(True, False, False, False)

            txtDiscCode.Enabled = False
            txtDiscType.Enabled = False
            txtDiscVal.Enabled = False

            LoadDiscounts()

            cmd.Parameters.Clear()
        End If
        cmd.Parameters.Clear()
    End Sub

    Sub UpdateStat(id As Integer)
        Dim stat As Integer = DataGridView1.CurrentRow.Cells("stat").Value
        If stat = 1 Then
            Dim a = MsgBox("Disable the selected discount type?", vbQuestion + vbYesNo, "System")
            If a = vbYes Then
                Dim sql As String
                sql = "UPDATE discount set stat = 0 WHERE id = @id"

                With cmd
                    .Connection = MysqlConn
                    .CommandText = sql
                    .Parameters.AddWithValue("@id", id)
                End With

                Dim result As Integer

                result = cmd.ExecuteNonQuery()
                If result > 0 Then
                    'MsgBox("Discount type disabled", vbInformation + vbOKOnly, "System")

                    ClearFields()
                    SetButtons(True, False, False, False)
                    LoadDiscounts()
                End If
                cmd.Parameters.Clear()
            End If
        Else
            Dim a = MsgBox("Enable the selected discount type?", vbQuestion + vbYesNo, "System")
            If a = vbYes Then
                Dim sql As String
                sql = "UPDATE discount set stat = 1 WHERE id = @id"

                With cmd
                    .Connection = MysqlConn
                    .CommandText = sql
                    .Parameters.AddWithValue("@id", id)
                End With

                Dim result As Integer

                result = cmd.ExecuteNonQuery()
                If result > 0 Then
                    'MsgBox("Discount type enabled", vbInformation + vbOKOnly, "System")

                    ClearFields()
                    SetButtons(True, False, False, False)
                    LoadDiscounts()
                End If
                cmd.Parameters.Clear()
            End If
        End If
    End Sub

    Sub ClearFields()
        txtDiscCode.Clear()
        txtDiscType.Clear()
        txtDiscVal.Clear()

        selected_id = 0
    End Sub

    Sub SetButtons(add As Boolean, save As Boolean, update As Boolean, changestat As Boolean)
        btnAdd.Enabled = add
        btnSave.Enabled = save
        btnUpdate.Enabled = update
        btnChangeDiscStatus.Enabled = changestat
    End Sub


    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtDiscCode.Text = "" Or txtDiscType.Text = "" Or txtDiscVal.Text = "" Then
            MsgBox("Please fill up the required fields", vbExclamation + vbOKOnly, "System")
        Else
            CreateDiscount(txtDiscCode.Text, txtDiscType.Text, CDbl(txtDiscVal.Text))
        End If

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If txtDiscCode.Text = "" Or txtDiscType.Text = "" Or txtDiscVal.Text = "" Then
            MsgBox("Please fill up the required fields", vbExclamation + vbOKOnly, "System")
        Else
            UpdateDiscount(selected_id, txtDiscCode.Text, txtDiscType.Text, CDbl(txtDiscVal.Text))
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        ClearFields()
        SetButtons(True, False, False, False)
        txtDiscCode.Enabled = False
        txtDiscType.Enabled = False
        txtDiscVal.Enabled = False
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        SetButtons(False, True, False, False)

        txtDiscCode.Enabled = True
        txtDiscType.Enabled = True
        txtDiscVal.Enabled = True
        txtDiscCode.Focus()
    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        If DataGridView1.Rows.Count = 0 Then
            'Do Nothing
        Else
            selected_id = DataGridView1.CurrentRow.Cells("id").Value
            txtDiscCode.Text = DataGridView1.CurrentRow.Cells("DiscountCode").Value
            txtDiscType.Text = DataGridView1.CurrentRow.Cells("DiscountType").Value
            txtDiscVal.Text = DataGridView1.CurrentRow.Cells("DiscountValue").Value

            SetButtons(False, False, True, True)
            txtDiscCode.Enabled = True
            txtDiscType.Enabled = True
            txtDiscVal.Enabled = True
        End If
    End Sub

    Private Sub btnChangeDiscStatus_Click(sender As Object, e As EventArgs) Handles btnChangeDiscStatus.Click
        UpdateStat(selected_id)
    End Sub

    Private Sub txtDiscVal_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDiscVal.KeyPress
        Dim DecimalSeparator As String = Application.CurrentCulture.NumberFormat.NumberDecimalSeparator
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or
                         Asc(e.KeyChar) = 8 Or
                         (e.KeyChar = DecimalSeparator And sender.Text.IndexOf(DecimalSeparator) = -1))

        If Char.IsControl(e.KeyChar) Then
        ElseIf Char.IsDigit(e.KeyChar) OrElse e.KeyChar = "."c Then
            'If TextBox2.TextLength = 5 And TextBox2.Text.Contains(".") = False Then
            'TextBox2.AppendText(".")
            'Elseif
            If e.KeyChar = "." And txtDiscVal.Text.IndexOf(".") <> -1 Then
                e.Handled = True
            ElseIf Char.IsDigit(e.KeyChar) Then
                If txtDiscVal.Text.IndexOf(".") <> -1 Then
                    If txtDiscVal.Text.Length >= txtDiscVal.Text.IndexOf(".") + 3 Then
                        e.Handled = True
                    End If
                End If
            End If
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If DataGridView1.Rows.Count = 0 Then
            'nothing
        Else
            If MsgBox("Do you really want to delete this item?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
                Dim sql As String
                sql = "DELETE FROM discount WHERE id = @itemid"

                Try
                    With cmd
                        .CommandText = sql
                        .Connection = MysqlConn
                        .Parameters.AddWithValue("@itemid", DataGridView1.CurrentRow.Cells("id").Value)
                        .ExecuteNonQuery()
                    End With

                    cmd.Parameters.Clear()
                    LoadDiscounts()
                Catch ex As Exception
                    MsgBox(ex.Message)
                    cmd.Parameters.Clear()
                End Try

            End If

        End If
    End Sub


End Class