﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class POS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(POS))
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.txtTotalItems = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtVatable = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtVat = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtTotalPrice = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Label()
        Me.btn2 = New System.Windows.Forms.Label()
        Me.btn3 = New System.Windows.Forms.Label()
        Me.btn4 = New System.Windows.Forms.Label()
        Me.btn8 = New System.Windows.Forms.Label()
        Me.btn7 = New System.Windows.Forms.Label()
        Me.btn6 = New System.Windows.Forms.Label()
        Me.btn5 = New System.Windows.Forms.Label()
        Me.btn12 = New System.Windows.Forms.Label()
        Me.btn11 = New System.Windows.Forms.Label()
        Me.btn10 = New System.Windows.Forms.Label()
        Me.btn9 = New System.Windows.Forms.Label()
        Me.btn13 = New System.Windows.Forms.Label()
        Me.btnViewTransaction = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.btnReadings = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnMinus = New System.Windows.Forms.Button()
        Me.btnApplyDisc = New System.Windows.Forms.Button()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnRemoveDisc = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveBorder
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.DataGridView1.Location = New System.Drawing.Point(12, 440)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(579, 173)
        Me.DataGridView1.TabIndex = 4
        '
        'txtTotalItems
        '
        Me.txtTotalItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalItems.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalItems.Location = New System.Drawing.Point(168, 11)
        Me.txtTotalItems.Name = "txtTotalItems"
        Me.txtTotalItems.ReadOnly = True
        Me.txtTotalItems.Size = New System.Drawing.Size(120, 22)
        Me.txtTotalItems.TabIndex = 18
        Me.txtTotalItems.TabStop = False
        Me.txtTotalItems.Text = "0"
        Me.txtTotalItems.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(14, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 15)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Total Items"
        '
        'txtVatable
        '
        Me.txtVatable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVatable.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVatable.Location = New System.Drawing.Point(168, 45)
        Me.txtVatable.Name = "txtVatable"
        Me.txtVatable.ReadOnly = True
        Me.txtVatable.Size = New System.Drawing.Size(120, 22)
        Me.txtVatable.TabIndex = 28
        Me.txtVatable.TabStop = False
        Me.txtVatable.Text = "0.00"
        Me.txtVatable.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label1.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(14, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 15)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Vatable"
        '
        'txtVat
        '
        Me.txtVat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVat.Location = New System.Drawing.Point(168, 78)
        Me.txtVat.Name = "txtVat"
        Me.txtVat.ReadOnly = True
        Me.txtVat.Size = New System.Drawing.Size(120, 22)
        Me.txtVat.TabIndex = 30
        Me.txtVat.TabStop = False
        Me.txtVat.Text = "0.00"
        Me.txtVat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label2.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(14, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 15)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "VAT"
        '
        'txtTotalPrice
        '
        Me.txtTotalPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalPrice.Location = New System.Drawing.Point(168, 135)
        Me.txtTotalPrice.Name = "txtTotalPrice"
        Me.txtTotalPrice.ReadOnly = True
        Me.txtTotalPrice.Size = New System.Drawing.Size(120, 22)
        Me.txtTotalPrice.TabIndex = 26
        Me.txtTotalPrice.TabStop = False
        Me.txtTotalPrice.Text = "0.00"
        Me.txtTotalPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label6.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.Control
        Me.Label6.Location = New System.Drawing.Point(14, 138)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 15)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Total"
        '
        'btnCompute
        '
        Me.btnCompute.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnCompute.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompute.Location = New System.Drawing.Point(930, 621)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(111, 49)
        Me.btnCompute.TabIndex = 31
        Me.btnCompute.Text = "CHECKOUT"
        Me.btnCompute.UseVisualStyleBackColor = False
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn1.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.Location = New System.Drawing.Point(18, 17)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(156, 58)
        Me.btn1.TabIndex = 33
        Me.btn1.Text = "Milk Tea"
        Me.btn1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn2.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.Location = New System.Drawing.Point(18, 81)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(156, 58)
        Me.btn2.TabIndex = 34
        Me.btn2.Text = "Chocolate"
        Me.btn2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn3.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.Location = New System.Drawing.Point(18, 146)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(156, 58)
        Me.btn3.TabIndex = 35
        Me.btn3.Text = "Yakult Milk Tea"
        Me.btn3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn4.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4.Location = New System.Drawing.Point(227, 16)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(156, 58)
        Me.btn4.TabIndex = 36
        Me.btn4.Text = "Iced Tea"
        Me.btn4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn8.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn8.Location = New System.Drawing.Point(437, 81)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(156, 58)
        Me.btn8.TabIndex = 40
        Me.btn8.Text = "Hot Milk Tea"
        Me.btn8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn7.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn7.Location = New System.Drawing.Point(437, 16)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(156, 58)
        Me.btn7.TabIndex = 39
        Me.btn7.Text = "Coffee"
        Me.btn7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn6.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn6.Location = New System.Drawing.Point(227, 146)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(156, 58)
        Me.btn6.TabIndex = 38
        Me.btn6.Text = "Rocksalt and Cheese"
        Me.btn6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn5.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn5.Location = New System.Drawing.Point(227, 81)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(156, 58)
        Me.btn5.TabIndex = 37
        Me.btn5.Text = "Taro"
        Me.btn5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn12
        '
        Me.btn12.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn12.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn12.Location = New System.Drawing.Point(652, 146)
        Me.btn12.Name = "btn12"
        Me.btn12.Size = New System.Drawing.Size(156, 58)
        Me.btn12.TabIndex = 44
        Me.btn12.Text = "SODA"
        Me.btn12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn11
        '
        Me.btn11.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn11.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn11.Location = New System.Drawing.Point(652, 81)
        Me.btn11.Name = "btn11"
        Me.btn11.Size = New System.Drawing.Size(156, 58)
        Me.btn11.TabIndex = 43
        Me.btn11.Text = "Frappe"
        Me.btn11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn10
        '
        Me.btn10.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn10.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn10.Location = New System.Drawing.Point(652, 16)
        Me.btn10.Name = "btn10"
        Me.btn10.Size = New System.Drawing.Size(156, 58)
        Me.btn10.TabIndex = 42
        Me.btn10.Text = "Matcha Mucho"
        Me.btn10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn9.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn9.Location = New System.Drawing.Point(437, 146)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(156, 58)
        Me.btn9.TabIndex = 41
        Me.btn9.Text = "MINTerrific"
        Me.btn9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn13
        '
        Me.btn13.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btn13.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn13.Location = New System.Drawing.Point(860, 17)
        Me.btn13.Name = "btn13"
        Me.btn13.Size = New System.Drawing.Size(156, 58)
        Me.btn13.TabIndex = 45
        Me.btn13.Text = "ADD-ONS"
        Me.btn13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnViewTransaction
        '
        Me.btnViewTransaction.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnViewTransaction.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewTransaction.Location = New System.Drawing.Point(931, 454)
        Me.btnViewTransaction.Name = "btnViewTransaction"
        Me.btnViewTransaction.Size = New System.Drawing.Size(111, 50)
        Me.btnViewTransaction.TabIndex = 108
        Me.btnViewTransaction.Text = "View Transaction"
        Me.btnViewTransaction.UseVisualStyleBackColor = False
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.FlowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FlowLayoutPanel1.ForeColor = System.Drawing.SystemColors.Control
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(13, 220)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Padding = New System.Windows.Forms.Padding(1, 1, 0, 0)
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(1029, 202)
        Me.FlowLayoutPanel1.TabIndex = 109
        '
        'btnReadings
        '
        Me.btnReadings.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnReadings.Location = New System.Drawing.Point(931, 510)
        Me.btnReadings.Name = "btnReadings"
        Me.btnReadings.Size = New System.Drawing.Size(112, 49)
        Me.btnReadings.TabIndex = 110
        Me.btnReadings.Text = "READINGS"
        Me.btnReadings.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(129, 621)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(111, 52)
        Me.btnDelete.TabIndex = 111
        Me.btnDelete.Text = "Delete Item"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(246, 623)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(111, 49)
        Me.btnCancel.TabIndex = 112
        Me.btnCancel.Text = "Clear Entries"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnMinus
        '
        Me.btnMinus.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnMinus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.btnMinus.Location = New System.Drawing.Point(12, 623)
        Me.btnMinus.Name = "btnMinus"
        Me.btnMinus.Size = New System.Drawing.Size(111, 51)
        Me.btnMinus.TabIndex = 113
        Me.btnMinus.Text = "Reduce Quantity"
        Me.btnMinus.UseVisualStyleBackColor = False
        '
        'btnApplyDisc
        '
        Me.btnApplyDisc.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnApplyDisc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.btnApplyDisc.Location = New System.Drawing.Point(363, 622)
        Me.btnApplyDisc.Name = "btnApplyDisc"
        Me.btnApplyDisc.Size = New System.Drawing.Size(111, 50)
        Me.btnApplyDisc.TabIndex = 114
        Me.btnApplyDisc.Text = "Apply Discount"
        Me.btnApplyDisc.UseVisualStyleBackColor = False
        '
        'txtDiscount
        '
        Me.txtDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDiscount.Location = New System.Drawing.Point(168, 107)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.ReadOnly = True
        Me.txtDiscount.Size = New System.Drawing.Size(120, 22)
        Me.txtDiscount.TabIndex = 118
        Me.txtDiscount.TabStop = False
        Me.txtDiscount.Text = "0.00"
        Me.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label4.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(14, 110)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(87, 15)
        Me.Label4.TabIndex = 117
        Me.Label4.Text = "Discount"
        '
        'btnRemoveDisc
        '
        Me.btnRemoveDisc.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnRemoveDisc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.btnRemoveDisc.Location = New System.Drawing.Point(480, 624)
        Me.btnRemoveDisc.Name = "btnRemoveDisc"
        Me.btnRemoveDisc.Size = New System.Drawing.Size(111, 49)
        Me.btnRemoveDisc.TabIndex = 119
        Me.btnRemoveDisc.Text = "Remove Discount"
        Me.btnRemoveDisc.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.btn1)
        Me.GroupBox1.Controls.Add(Me.btn2)
        Me.GroupBox1.Controls.Add(Me.btn3)
        Me.GroupBox1.Controls.Add(Me.btn6)
        Me.GroupBox1.Controls.Add(Me.btn4)
        Me.GroupBox1.Controls.Add(Me.btn5)
        Me.GroupBox1.Controls.Add(Me.btn9)
        Me.GroupBox1.Controls.Add(Me.btn7)
        Me.GroupBox1.Controls.Add(Me.btn8)
        Me.GroupBox1.Controls.Add(Me.btn11)
        Me.GroupBox1.Controls.Add(Me.btn10)
        Me.GroupBox1.Controls.Add(Me.btn12)
        Me.GroupBox1.Controls.Add(Me.btn13)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1030, 214)
        Me.GroupBox1.TabIndex = 120
        Me.GroupBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.txtTotalItems)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.txtVatable)
        Me.Panel1.Controls.Add(Me.txtDiscount)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.txtVat)
        Me.Panel1.Controls.Add(Me.txtTotalPrice)
        Me.Panel1.Location = New System.Drawing.Point(597, 440)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(300, 173)
        Me.Panel1.TabIndex = 0
        '
        'POS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1053, 682)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnRemoveDisc)
        Me.Controls.Add(Me.btnApplyDisc)
        Me.Controls.Add(Me.btnMinus)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnReadings)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.btnViewTransaction)
        Me.Controls.Add(Me.btnCompute)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "POS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "POS"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents txtTotalItems As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtVatable As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtVat As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtTotalPrice As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnCompute As System.Windows.Forms.Button
    Friend WithEvents btn1 As System.Windows.Forms.Label
    Friend WithEvents btn2 As System.Windows.Forms.Label
    Friend WithEvents btn3 As System.Windows.Forms.Label
    Friend WithEvents btn4 As System.Windows.Forms.Label
    Friend WithEvents btn8 As System.Windows.Forms.Label
    Friend WithEvents btn7 As System.Windows.Forms.Label
    Friend WithEvents btn6 As System.Windows.Forms.Label
    Friend WithEvents btn5 As System.Windows.Forms.Label
    Friend WithEvents btn12 As System.Windows.Forms.Label
    Friend WithEvents btn11 As System.Windows.Forms.Label
    Friend WithEvents btn10 As System.Windows.Forms.Label
    Friend WithEvents btn9 As System.Windows.Forms.Label
    Friend WithEvents btn13 As System.Windows.Forms.Label
    Friend WithEvents btnViewTransaction As System.Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents btnReadings As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnMinus As System.Windows.Forms.Button
    Friend WithEvents btnApplyDisc As System.Windows.Forms.Button
    Friend WithEvents txtDiscount As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnRemoveDisc As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
