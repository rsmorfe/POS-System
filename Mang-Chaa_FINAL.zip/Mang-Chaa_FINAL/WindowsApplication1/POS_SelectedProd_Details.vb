﻿Public Class POS_SelectedProd_Details
    Public ProdID As Integer

    Sub Sizes()
        ComboBox1.Items.Clear()

        ComboBox1.Items.Add("Regular")
        ComboBox1.Items.Add("Large")
        ComboBox1.Items.Add("XL")
    End Sub

    Sub AddToTransactionItems(id As Integer, item As String, qty As Integer, size As String, price As Double)
        Dim Prodname As String
        Dim Prodsize As String = size
        Dim ProdPrice As Double 'price * qty

        If size = "Regular" Then
            Prodsize = "(R)"
        ElseIf size = "Large" Then
            Prodsize = "(L)"
        ElseIf size = "XL" Then
            Prodsize = "(XL)"
        End If

        Prodname = item & Prodsize
        ProdPrice = qty * price
        POS.DataGridView1.Rows.Add(id, Prodname, price, qty, ProdPrice)

        POS.Compute() 'compute/recompute total items and total amount
        Me.Dispose()
        Inventory_AddStock.Dispose()
    End Sub

    Private Sub POS_SelectedProd_Details_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Sizes()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If ComboBox1.Text = "" Or txtQty.Text = "" Then
                MsgBox("One of the required fields is empty", vbExclamation + vbOKOnly, "System")
            Else
                AddToTransactionItems(ProdID, txtProdName.Text, CInt(txtQty.Text), ComboBox1.Text, CDbl(txtPrice.Text))
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class