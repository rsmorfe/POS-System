﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SysManager
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.FileMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.InventoryMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.POSMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.DiscountsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.WeeklyRpt = New System.Windows.Forms.ToolStripMenuItem()
        Me.CurrentRpt = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonthlyRpt = New System.Windows.Forms.ToolStripMenuItem()
        Me.TotalGrossSales = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.SystemMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Config = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.CascadeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ArrangeIconsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.MenuStrip.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileMenu, Me.WindowsMenu})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 45)
        Me.MenuStrip.MdiWindowListItem = Me.WindowsMenu
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(645, 24)
        Me.MenuStrip.TabIndex = 5
        Me.MenuStrip.Text = "MenuStrip"
        '
        'FileMenu
        '
        Me.FileMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AccountsMenu, Me.InventoryMenu, Me.ToolStripSeparator3, Me.POSMenu, Me.ReportsMenu, Me.ToolStripSeparator4, Me.SystemMenu, Me.ToolStripSeparator5, Me.ExitToolStripMenuItem})
        Me.FileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder
        Me.FileMenu.Name = "FileMenu"
        Me.FileMenu.Size = New System.Drawing.Size(50, 20)
        Me.FileMenu.Text = "&Menu"
        '
        'AccountsMenu
        '
        Me.AccountsMenu.ImageTransparentColor = System.Drawing.Color.Black
        Me.AccountsMenu.Name = "AccountsMenu"
        Me.AccountsMenu.ShowShortcutKeys = False
        Me.AccountsMenu.Size = New System.Drawing.Size(152, 22)
        Me.AccountsMenu.Text = "&Accounts"
        '
        'InventoryMenu
        '
        Me.InventoryMenu.ImageTransparentColor = System.Drawing.Color.Black
        Me.InventoryMenu.Name = "InventoryMenu"
        Me.InventoryMenu.ShowShortcutKeys = False
        Me.InventoryMenu.Size = New System.Drawing.Size(152, 22)
        Me.InventoryMenu.Text = "&Inventory"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(149, 6)
        '
        'POSMenu
        '
        Me.POSMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DiscountsMenu, Me.ProductsMenu})
        Me.POSMenu.ImageTransparentColor = System.Drawing.Color.Black
        Me.POSMenu.Name = "POSMenu"
        Me.POSMenu.Size = New System.Drawing.Size(152, 22)
        Me.POSMenu.Text = "&POS"
        '
        'ProductsMenu
        '
        Me.ProductsMenu.Name = "ProductsMenu"
        Me.ProductsMenu.Size = New System.Drawing.Size(152, 22)
        Me.ProductsMenu.Text = "&Products"
        '
        'DiscountsMenu
        '
        Me.DiscountsMenu.Name = "DiscountsMenu"
        Me.DiscountsMenu.Size = New System.Drawing.Size(152, 22)
        Me.DiscountsMenu.Text = "&Discounts"
        '
        'ReportsMenu
        '
        Me.ReportsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CurrentRpt, Me.WeeklyRpt, Me.MonthlyRpt, Me.TotalGrossSales})
        Me.ReportsMenu.ImageTransparentColor = System.Drawing.Color.Black
        Me.ReportsMenu.Name = "ReportsMenu"
        Me.ReportsMenu.Size = New System.Drawing.Size(152, 22)
        Me.ReportsMenu.Text = "&Reports"
        '
        'WeeklyRpt
        '
        Me.WeeklyRpt.Name = "WeeklyRpt"
        Me.WeeklyRpt.Size = New System.Drawing.Size(180, 22)
        Me.WeeklyRpt.Text = "&Weekly Sales"
        '
        'CurrentRpt
        '
        Me.CurrentRpt.Name = "CurrentRpt"
        Me.CurrentRpt.Size = New System.Drawing.Size(180, 22)
        Me.CurrentRpt.Text = "&Current Sales"
        '
        'MonthlyRpt
        '
        Me.MonthlyRpt.Name = "MonthlyRpt"
        Me.MonthlyRpt.Size = New System.Drawing.Size(180, 22)
        Me.MonthlyRpt.Text = "&Monthly Gross Sales"
        '
        'TotalGrossSales
        '
        Me.TotalGrossSales.Name = "TotalGrossSales"
        Me.TotalGrossSales.Size = New System.Drawing.Size(180, 22)
        Me.TotalGrossSales.Text = "&Total Gross Sales"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(149, 6)
        '
        'SystemMenu
        '
        Me.SystemMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Config})
        Me.SystemMenu.ImageTransparentColor = System.Drawing.Color.Black
        Me.SystemMenu.Name = "SystemMenu"
        Me.SystemMenu.Size = New System.Drawing.Size(152, 22)
        Me.SystemMenu.Text = "&System"
        '
        'Config
        '
        Me.Config.Name = "Config"
        Me.Config.Size = New System.Drawing.Size(152, 22)
        Me.Config.Text = "&Configuration"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(149, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'WindowsMenu
        '
        Me.WindowsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CascadeToolStripMenuItem, Me.CloseAllToolStripMenuItem, Me.ArrangeIconsToolStripMenuItem})
        Me.WindowsMenu.Name = "WindowsMenu"
        Me.WindowsMenu.Size = New System.Drawing.Size(68, 20)
        Me.WindowsMenu.Text = "&Windows"
        '
        'CascadeToolStripMenuItem
        '
        Me.CascadeToolStripMenuItem.Name = "CascadeToolStripMenuItem"
        Me.CascadeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CascadeToolStripMenuItem.Text = "&Cascade"
        '
        'CloseAllToolStripMenuItem
        '
        Me.CloseAllToolStripMenuItem.Name = "CloseAllToolStripMenuItem"
        Me.CloseAllToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CloseAllToolStripMenuItem.Text = "C&lose All"
        '
        'ArrangeIconsToolStripMenuItem
        '
        Me.ArrangeIconsToolStripMenuItem.Name = "ArrangeIconsToolStripMenuItem"
        Me.ArrangeIconsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ArrangeIconsToolStripMenuItem.Text = "&Arrange Icons"
        '
        'Label1
        '
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(313, 39)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Hello, Owner!"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(639, 39)
        Me.TableLayoutPanel1.TabIndex = 12
        '
        'Label2
        '
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(322, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(314, 39)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Hello, Owner!"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Timer1
        '
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 645.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.TableLayoutPanel1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.MenuStrip, 0, 1)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(632, 74)
        Me.TableLayoutPanel2.TabIndex = 14
        '
        'SysManager
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(632, 453)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.MaximizeBox = False
        Me.Name = "SysManager"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.ResumeLayout(False)

End Sub
    Friend WithEvents ArrangeIconsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WindowsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CascadeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents SystemMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AccountsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InventoryMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents POSMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents ProductsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DiscountsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WeeklyRpt As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CurrentRpt As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MonthlyRpt As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TotalGrossSales As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Config As System.Windows.Forms.ToolStripMenuItem

End Class
