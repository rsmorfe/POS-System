﻿Public Class Configuration

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        SaveConfiguration(CDbl(txtVAT.Text), CDbl(txtVatable.Text), txtServer.Text, txtUser.Text, txtPass.Text, txtDBName.Text)

        'LoadConfig() 'apply latest config to fields

    End Sub

    Private Sub Configuration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadConfig()
    End Sub

    Sub LoadConfig()
        'Get configuration values from Module2
        txtVAT.Text = FormatNumber(VAT, 2)
        txtVatable.Text = FormatNumber(Vatable, 2)

        txtServer.Text = DB_Server
        txtUser.Text = DB_User
        txtPass.Text = DB_Pass
        txtDBName.Text = DB_Name
    End Sub
End Class