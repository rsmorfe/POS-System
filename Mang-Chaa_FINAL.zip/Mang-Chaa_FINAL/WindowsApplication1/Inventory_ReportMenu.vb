﻿Public Class Inventory_ReportMenu

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub btnStocks_Click(sender As Object, e As EventArgs) Handles btnStocks.Click
        Dim objRpt As New CurrentStocks
        objRpt.Refresh()

        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .ShowDialog()
        End With
    End Sub

    Private Sub btnResupply_Click(sender As Object, e As EventArgs) Handles btnResupply.Click
        Dim objRpt As New ForUrgentResupply
        objRpt.Refresh()

        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .ShowDialog()
        End With
    End Sub

    Private Sub btnTopItems_Click(sender As Object, e As EventArgs) Handles btnTopItems.Click
        Dim objRpt As New TopUsedItems
        objRpt.Refresh()

        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .ShowDialog()
        End With
    End Sub

    Private Sub btnTopSold_Click(sender As Object, e As EventArgs) Handles btnTopSold.Click
        Dim objRpt As New TopSoldProduct
        objRpt.Refresh()

        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .ShowDialog()
        End With
    End Sub
End Class