﻿Public Class ReceiptPreview
    Public strPrint As String
    Private Sub ReceiptPreview_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtPreview.Text = strPrint
        Button1.Focus()
    End Sub

    'Public Sub PrepareTransactionReceipt(transID As Integer)

    '    Dim config As New IniFile(Application.StartupPath & "\" & "Config.ini")

    '    'RECEIPT HEADER
    '    Dim CompanyName As String = config.GetString("Receipt", "StoreName", "Company XYZ")
    '    Dim CompanyAddress As String = config.GetString("Receipt", "StoreAddress", "Address Here")

    '    strPrint = " " & vbCrLf
    '    strPrint = strPrint & " " & vbCrLf
    '    strPrint = strPrint & CompanyName.ToString.PadLeft(21) & vbCrLf
    '    strPrint = strPrint & CompanyAddress.ToString.PadLeft(28) & vbCrLf
    '    strPrint = strPrint & " " & vbNewLine

    '    'BODY
    '    Dim sql As String
    '    Dim table As New DataTable

    '    'Transaction Number and Date
    '    strPrint = strPrint & "".PadRight(3) & "TN:".ToString.PadRight(2) & transID.ToString.PadRight(15) & Date.Today.ToShortDateString & vbCrLf
    '    strPrint = strPrint & "" & vbNewLine & vbCrLf
    '    strPrint = strPrint & " ---------------------------------" & vbCrLf
    '    strPrint = strPrint & " " & vbNewLine

    '    'Items
    '    sql = "SELECT ProdName,Quantity,Price FROM transactiondetails WHERE TransID = @transID"
    '    table = New DataTable
    '    Try
    '        With cmd
    '            .CommandText = sql
    '            .Connection = MysqlConn
    '            .Parameters.AddWithValue("@transID", transID)
    '        End With

    '        da.SelectCommand = cmd
    '        da.Fill(table)

    '        cmd.Parameters.Clear()
    '        Dim subtotal As Double = 0.0
    '        For Each row As DataRow In table.Rows
    '            Dim quantity As Integer = row.Item("Quantity")
    '            Dim price As Double = FormatNumber(row.Item("Price"), 2)
    '            Dim totalprice As Double = FormatNumber(quantity * price)
    '            subtotal += totalprice
    '            strPrint = strPrint & "".PadRight(1) & Strings.Left(row.Item("ProdName"), 17).ToString.PadLeft(5) & price.ToString.PadLeft(5) & " x " & quantity.ToString.PadRight(3) & FormatNumber(totalprice, 2).ToString & vbCrLf
    '        Next

    '        'Subtotal,Vatable,VAT
    '        strPrint = strPrint & " " & vbCrLf
    '        strPrint = strPrint & " ---------------------------------" & vbCrLf
    '        strPrint = strPrint & "".PadRight(1) & "Vatable".ToString.PadRight(20) & FormatNumber(subtotal / Vatable, 2).ToString.PadLeft(13) & vbCrLf
    '        strPrint = strPrint & "".PadRight(1) & "VAT".ToString.PadRight(20) & FormatNumber(FormatNumber(subtotal / Vatable, 2) * VAT, 2).ToString.PadLeft(13) & vbCrLf
    '        strPrint = strPrint & "".PadRight(1) & "TOTAL".ToString.PadRight(20) & FormatNumber(subtotal, 2).ToString.PadLeft(13) & vbCrLf

    '    Catch ex As Exception
    '        'MsgBox(ex.Message)
    '        If MsgBox(ex.Message) = DialogResult.OK Then
    '            cmd.Parameters.Clear()
    '            Exit Sub
    '        End If
    '    End Try

    '    'FOOTER
    '    Dim Message1 As String = config.GetString("Receipt", "Message1", "Message1")
    '    Dim Message2 As String = config.GetString("Receipt", "Message2", "Message2")
    '    Dim Message3 As String = config.GetString("Receipt", "Message3", "Message3")

    '    strPrint = strPrint & " " & vbCrLf
    '    strPrint = strPrint & Message1.ToString.PadLeft(26.5) & vbCrLf
    '    strPrint = strPrint & Message2.ToString.PadLeft(25) & vbCrLf
    '    strPrint = strPrint & Message3.ToString.PadLeft(22) & vbCrLf

    '    txtPreview.Text = strPrint
    '    'Printer.Print(strPrint)
    'End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Printer.Print(strPrint)
        Me.Close()
    End Sub
End Class