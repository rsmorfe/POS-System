﻿Imports System.Windows.Forms
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.CrystalReports.Engine

Public Class SysManager

    'Private Sub ShowNewForm(ByVal sender As Object, ByVal e As EventArgs) Handles NewToolStripMenuItem.Click
    '    ' Create a new instance of the child form.
    '    Dim ChildForm As New System.Windows.Forms.Form
    '    ' Make it a child of this MDI form before showing it.
    '    ChildForm.MdiParent = Me

    '    m_ChildFormNumber += 1
    '    ChildForm.Text = "Window " & m_ChildFormNumber

    '    ChildForm.Show()
    'End Sub


    Private Sub ExitToolsStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ExitToolStripMenuItem.Click
        Login.Show()
        Me.Close()
    End Sub

    Private Sub CascadeToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles CascadeToolStripMenuItem.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub ArrangeIconsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ArrangeIconsToolStripMenuItem.Click
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub

    Private Sub CloseAllToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles CloseAllToolStripMenuItem.Click
        ' Close all child forms of the parent.
        For Each ChildForm As Form In Me.MdiChildren
            ChildForm.Close()
        Next
    End Sub

    Private m_ChildFormNumber As Integer

    Private Sub SysManager_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Timer1.Enabled = True
    End Sub

    Private Sub AccountsMenu_Click(sender As Object, e As EventArgs) Handles AccountsMenu.Click
        Dim UserAdmin As New AddStaff
        UserAdmin.MdiParent = Me
        UserAdmin.Show()
    End Sub

    Private Sub InventoryMenu_Click(sender As Object, e As EventArgs) Handles InventoryMenu.Click
        Inventory.MdiParent = Me
        Inventory.Show()
    End Sub

    Private Sub Products_Click(sender As Object, e As EventArgs) Handles ProductsMenu.Click
        Products.MdiParent = Me
        Products.Show()
    End Sub

    Private Sub DiscountsMenu_Click(sender As Object, e As EventArgs) Handles DiscountsMenu.Click
        Dim discounts As New Discounts
        discounts.MdiParent = Me
        discounts.Show()
    End Sub

    Private Sub Config_Click(sender As Object, e As EventArgs) Handles Config.Click
        Dim config As New Configuration
        config.MdiParent = Me
        config.Show()
    End Sub

    Private Sub WeeklyRpt_Click(sender As Object, e As EventArgs) Handles WeeklyRpt.Click
        Dim objRpt As New WeeklySales
        objRpt.Refresh()

        'DirectCast(objRpt.ReportDefinition.ReportObjects("Text6"), TextObject).Text = "Current Sales Report (Daily)"
        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Me
            .WindowState = FormWindowState.Maximized
            .Show()
        End With
    End Sub

    Private Sub CurrentRpt_Click(sender As Object, e As EventArgs) Handles CurrentRpt.Click
        Dim objRpt As New CurrentSales
        objRpt.Refresh()

        DirectCast(objRpt.ReportDefinition.ReportObjects("Text6"), TextObject).Text = "Current Sales Report (Daily)"
        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Me
            .WindowState = FormWindowState.Maximized
            .Show()
        End With
    End Sub

    Private Sub TotalGrossSales_Click(sender As Object, e As EventArgs) Handles TotalGrossSales.Click
        Dim objRpt As New TotalGrossSales
        objRpt.Refresh()

        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Me
            .WindowState = FormWindowState.Maximized
            .Show()
        End With
    End Sub

    Private Sub MonthlyRpt_Click(sender As Object, e As EventArgs) Handles MonthlyRpt.Click
        Dim selectmonth As New SelectMonth
        selectmonth.ShowDialog()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label2.Text = System.DateTime.Today & " " & TimeOfDay
    End Sub
End Class
