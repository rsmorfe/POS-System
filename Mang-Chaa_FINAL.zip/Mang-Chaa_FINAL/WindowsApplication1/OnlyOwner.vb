﻿Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.CrystalReports.Engine
Public Class OnlyOwner

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Login.Show()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim objRpt As New CurrentSales
        objRpt.Refresh()

        DirectCast(objRpt.ReportDefinition.ReportObjects("Text6"), TextObject).Text = "Current Sales Report (Daily)"
        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .ShowDialog()
        End With
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim selectmonth As New SelectMonth
        selectmonth.ShowDialog()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim objRpt As New TotalGrossSales
        objRpt.Refresh()

        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .ShowDialog()
        End With
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim objRpt As New WeeklySales
        objRpt.Refresh()

        'DirectCast(objRpt.ReportDefinition.ReportObjects("Text6"), TextObject).Text = "Current Sales Report (Daily)"
        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .ShowDialog()
        End With
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim UserAdmin As New AddStaff
        UserAdmin.ShowDialog()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim discounts As New Discounts
        discounts.ShowDialog()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim config As New Configuration
        config.ShowDialog()
    End Sub


    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Products.Show()
        Me.Close()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Inventory.Show()
        Me.Close()
    End Sub
End Class