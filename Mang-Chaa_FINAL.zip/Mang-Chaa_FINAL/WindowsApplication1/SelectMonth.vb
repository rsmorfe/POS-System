﻿Public Class SelectMonth

    Private Sub btnGenerateRpt_Click(sender As Object, e As EventArgs) Handles btnGenerateRpt.Click
        Dim objRpt As New MontlySales
        objRpt.Refresh()
        objRpt.SetParameterValue("selectedYear", cbxYear.SelectedValue)
        objRpt.SetParameterValue("selectedMonth", cbxMonth.SelectedValue)

        Dim rptView As New ReportViewer
        With rptView
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Refresh()
            .MdiParent = SysManager
            .WindowState = FormWindowState.Maximized
            .Show()
        End With

        Me.Close()
    End Sub

    Sub LoadYear()
        cbxYear.Items.Clear()

        Dim table As New DataTable
        Dim sql As String

        sql = "SELECT DISTINCT Year(DateCreated) as year FROM transactionheader"

        With cmd
            .CommandText = Sql
            .Connection = MysqlConn
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        cbxYear.DataSource = table
        cbxYear.DisplayMember = "year"
        cbxYear.ValueMember = "year"
    End Sub

    Sub LoadMonthList()
        cbxMonth.Items.Clear() 'clear list first


        Dim table As New DataTable
        Dim sql As String

        sql = "SELECT DISTINCT MONTH(DateCreated) as monthVal,MONTHNAME(DateCreated) as monthName  FROM transactionheader"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        cbxMonth.DataSource = table
        cbxMonth.DisplayMember = "monthName"
        cbxMonth.ValueMember = "monthVal"
    End Sub

    Private Sub SelectMonth_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadYear()
        LoadMonthList()
    End Sub
End Class