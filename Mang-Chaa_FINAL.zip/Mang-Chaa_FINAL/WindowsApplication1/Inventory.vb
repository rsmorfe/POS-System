﻿Public Class Inventory

    Sub LoadProducts(txt As String)
        If txt = "" Then
            Dim sql As String
            Dim publictable As New DataTable

            'PRODUCT LIST WITH AVAILABLE AND USED STOCK
            'sql = "SELECT a.CatType,a.ProdID,a.ProdName,a.price," _
            '    & "((SELECT COALESCE(SUM(Quantity),0) FROM stockinventory WHERE ActionType = 1 AND ProdID = a.ProdID) - " _
            '    & "(SELECT COALESCE(SUM(Quantity),0) FROM transactiondetails WHERE ProdID = a.ProdID))AS Stocks," _
            '    & "(CASE WHEN (SELECT COALESCE(SUM(Quantity),0) FROM stockinventory WHERE ActionType = 1 AND ProdID = a.ProdID) = 0 THEN 0 " _
            '    & "ELSE (SELECT SUM(Quantity) FROM stockinventory WHERE ActionType = 1 AND ProdID = a.ProdID) END) AS Received," _
            '    & "(CASE WHEN (SELECT COALESCE(SUM(Quantity),0) FROM transactiondetails WHERE ProdID = a.ProdID) = 0 THEN 0 " _
            '    & "ELSE (SELECT SUM(Quantity) FROM transactiondetails WHERE ProdID = a.ProdID) END) AS Used " _
            '    & "FROM products a order by a.CatType,a.ProdID ASC"

            sql = "SELECT a.itemID,a.itemName,(SELECT catName from inventory_category where catID = a.itemCategory) as Category,a.UOM,a.Size,a.Color," _
                & "((SELECT COALESCE(SUM(Quantity),0) FROM stockinventory WHERE ActionType = 1 AND ItemID = a.ItemID) - " _
                & "(SELECT COALESCE(SUM(Quantity),0) FROM stockinventory WHERE ActionType = 2 AND ItemID = a.ItemID)) AS Stock " _
                & "FROM inventory_items a ORDER BY Category ASC, a.itemName ASC"

            With cmd
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = cmd
            da.Fill(publictable)

            DataGridView1.DataSource = publictable
            'DataGridView1.Columns(0).Width = 75
            DataGridView1.Columns(0).HeaderText = "ID"
            DataGridView1.Columns(0).Visible = False
            DataGridView1.Columns(1).HeaderText = "Item"
            'DataGridView1.Columns(2).Visible = False
            'DataGridView1.Columns(3).Width = 125
            'DataGridView1.Columns.Item(3).DefaultCellStyle.Format = "####.#0"
        Else
            Dim sql As String
            Dim publictable As New DataTable

            'PRODUCT LIST WITH AVAILABLE AND USED STOCK
            'sql = "SELECT a.CatType,a.ProdID,a.ProdName,a.price," _
            '    & "((SELECT COALESCE(SUM(Quantity),0) FROM stockinventory WHERE ActionType = 1 AND ProdID = a.ProdID) - " _
            '    & "(SELECT COALESCE(SUM(Quantity),0) FROM transactiondetails WHERE ProdID = a.ProdID))AS Stocks," _
            '    & "(CASE WHEN (SELECT COALESCE(SUM(Quantity),0) FROM stockinventory WHERE ActionType = 1 AND ProdID = a.ProdID) = 0 THEN 0 " _
            '    & "ELSE (SELECT SUM(Quantity) FROM stockinventory WHERE ActionType = 1 AND ProdID = a.ProdID) END) AS Received," _
            '    & "(CASE WHEN (SELECT COALESCE(SUM(Quantity),0) FROM transactiondetails WHERE ProdID = a.ProdID) = 0 THEN 0 " _
            '    & "ELSE (SELECT SUM(Quantity) FROM transactiondetails WHERE ProdID = a.ProdID) END) AS Used " _
            '    & "from products a WHERE a.ProdID LIKE '%" & txt & "%' OR a.ProdName LIKE '%" & txt & "%' " _
            '    & "ORDER BY a.CatType,a.ProdID ASC"

            sql = "SELECT a.itemID,a.itemName,(SELECT catName from inventory_category where catID = a.itemCategory) as Category,a.UOM,a.Size,a.Color," _
            & "((SELECT COALESCE(SUM(Quantity),0) FROM stockinventory WHERE ActionType = 1 AND ItemID = a.ItemID) - " _
            & "(SELECT COALESCE(SUM(Quantity),0) FROM stockinventory WHERE ActionType = 2 AND ItemID = a.ItemID)) AS Stock " _
            & "FROM inventory_items a WHERE a.itemID =@search OR a.itemName LIKE CONCAT('%',@search,'%') ORDER BY Category ASC, a.itemName ASC"

            With cmd
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@search", txt)
            End With

            da.SelectCommand = cmd
            da.Fill(publictable)

            DataGridView1.DataSource = publictable
            'DataGridView1.Columns(0).Width = 75
            DataGridView1.Columns(0).HeaderText = "ID"
            DataGridView1.Columns(0).Visible = False
            DataGridView1.Columns(1).HeaderText = "Item"
            'DataGridView1.Columns(2).Visible = False
            'DataGridView1.Columns(3).Width = 125
            'DataGridView1.Columns.Item(3).DefaultCellStyle.Format = "####.#0"

            cmd.Parameters.Clear()
        End If



        'If DataGridView1.CurrentRow.Selected = True Then
        '    DataGridView1.CurrentRow.Selected = False
        'End If

        txtSearch.Focus()
        DataGridView1.ClearSelection()
    End Sub

    Private Sub btcnClose_Click(sender As Object, e As EventArgs) Handles btcnClose.Click
        'OnlyOwner.Show()
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        Inventory_ItemDetails.ItemID = DataGridView1.CurrentRow.Cells(0).Value
        Inventory_ItemDetails.ItemName = DataGridView1.CurrentRow.Cells(1).Value

        Inventory_ItemDetails.ShowDialog()
    End Sub

    Private Sub Inventory_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'OnlyStaff.Show()
    End Sub

    Private Sub Inventory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadProducts("")
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            LoadProducts(txtSearch.Text)
        End If
    End Sub

    Private Sub btnAddStock_Click(sender As Object, e As EventArgs) Handles btnAddStock.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            Inventory_AddStock.commandstat = 1
            Inventory_AddStock.itemID = DataGridView1.CurrentRow.Cells(0).Value
            Inventory_AddStock.txtItemName.Text = DataGridView1.CurrentRow.Cells(1).Value
            Inventory_AddStock.Text = "Inventory Stock [ADD]"
            Inventory_AddStock.ShowDialog()
        End If
    End Sub

    Private Sub btnNewItem_Click(sender As Object, e As EventArgs) Handles btnNewItem.Click
        With Inventory_NewItem
            .commandstat = 1
            .Text = "[Inventory] - New Item"
            .ShowDialog()
        End With
    End Sub

    Private Sub btnUpdateItem_Click(sender As Object, e As EventArgs) Handles btnUpdateItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            With Inventory_NewItem
                .commandstat = 2
                .itemID = DataGridView1.CurrentRow.Cells(0).Value
                .txtItemName.Text = DataGridView1.CurrentRow.Cells(1).Value.ToString()
                .setindex = DataGridView1.CurrentRow.Cells(2).Value
                If DataGridView1.CurrentRow.Cells(3).Value.ToString = String.Empty Then

                Else
                    .ComboBox1.SelectedIndex = .ComboBox1.FindString(If(DataGridView1.CurrentRow.Cells(3).Value, DBNull.Value))
                End If

                If DataGridView1.CurrentRow.Cells(4).Value.ToString = String.Empty Then

                Else
                    .ComboBox2.SelectedIndex = .ComboBox2.FindString(If(DataGridView1.CurrentRow.Cells(4).Value, DBNull.Value))
                End If

                If DataGridView1.CurrentRow.Cells(5).Value.ToString = String.Empty Then

                Else
                    .ComboBox3.SelectedIndex = .ComboBox3.FindString(If(DataGridView1.CurrentRow.Cells(5).Value, DBNull.Value))
                End If
                .Text = "[Inventory] - Update Item"
                .ShowDialog()
            End With
        End If
    End Sub

    Private Sub btnUseStock_Click(sender As Object, e As EventArgs) Handles btnUseStock.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            Inventory_AddStock.commandstat = 2
            Inventory_AddStock.itemID = DataGridView1.CurrentRow.Cells(0).Value
            Inventory_AddStock.txtItemName.Text = DataGridView1.CurrentRow.Cells(1).Value
            Inventory_AddStock.currentStock = DataGridView1.CurrentRow.Cells(6).Value
            Inventory_AddStock.Text = "Inventory Stock [USE]"
            Inventory_AddStock.ShowDialog()
        End If
    End Sub

    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        Inventory_ReportMenu.ShowDialog()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MsgBox("Do you really want to delete this item?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
            If DataGridView1.CurrentRow.Cells("Stock").Value > 0 Then
                MsgBox("Unable to remove item. Selected item has remaining stock", vbExclamation + vbOKOnly, "System")
                DataGridView1.ClearSelection()
            Else
                Dim sql As String
                sql = "DELETE FROM inventory_items WHERE itemID = @itemID"

                Try
                    With cmd
                        .CommandText = sql
                        .Connection = MysqlConn
                        .Parameters.AddWithValue("@itemID", DataGridView1.CurrentRow.Cells("itemID").Value)
                        .ExecuteNonQuery()
                    End With

                    cmd.Parameters.Clear()
                    LoadProducts("")
                Catch ex As Exception
                    MsgBox(ex.Message)
                    cmd.Parameters.Clear()
                End Try
            End If
        End If
    End Sub
End Class