﻿Public Class Product_Details
    Public commandstat As String
    Public setindex As String
    Public prodid As Integer

    Private Sub ProductDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Debug.WriteLine("setindex: " + setindex.ToString)
        LoadCategory()

        'Set Selected value in Combobox   
        'ComboBox1.SelectedValue = setindex --- INTEGER
        ComboBox1.SelectedIndex = ComboBox1.FindString(setindex)
        'Debug.WriteLine("SelectedValue: " + ComboBox1.SelectedValue.ToString)

    End Sub

    Sub LoadCategory()
        ComboBox1.Items.Clear()

        Dim sql As String
        Dim publictable As New DataTable

        Try

            sql = "SELECT * FROM categories"
            'bind the MysqlConnnection and query
            With cmd
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = cmd
            da.Fill(publictable)
            'Dim FILENAME As String = "C:\Users\audrey\Documents\log.txt"
            'check if theres a result by getting the count number of rows
            If publictable.Rows.Count > 0 Then
                ComboBox1.DataSource = publictable
                ComboBox1.DisplayMember = "category"
                ComboBox1.ValueMember = "CatID"
                ComboBox1.SelectionStart = 0
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        'ComboBox1.Items.Add("Milk Tea")
        'ComboBox1.Items.Add("Chocolate")
        'ComboBox1.Items.Add("Yakult Milk Tea")
        'ComboBox1.Items.Add("Iced Tea")
        'ComboBox1.Items.Add("Taro")
        'ComboBox1.Items.Add("Rocksalt & Cheese")
        'ComboBox1.Items.Add("Coffee")
        'ComboBox1.Items.Add("Hot Milk Tea")
        'ComboBox1.Items.Add("MINTerrific")
        'ComboBox1.Items.Add("Matcha Mucho")
        'ComboBox1.Items.Add("Frappe")
        'ComboBox1.Items.Add("SODA")
        'ComboBox1.Items.Add("ADD-ONS")


    End Sub

    Sub AddProduct()
        Dim result As Integer

        Try
            'we open Connection
            'MysqlConn.Open()
            'Dim cat_index As Integer = ComboBox1.SelectedIndex
            With cmd
                .Connection = MysqlConn
                .CommandText = "INSERT INTO products" _
                    & "(ProdName,CatType,price) VALUES(@prodName,@CatType,@price)"

                .Parameters.AddWithValue("@prodName", txtProdName.Text)
                .Parameters.AddWithValue("@CatType", ComboBox1.SelectedValue)
                .Parameters.AddWithValue("@price", txtPrice.Text)

                'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                result = cmd.ExecuteNonQuery
                'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                Else
                    MsgBox("Successfully saved!", vbOKOnly + vbInformation, "System")

                    Products.DataGridView1.DataSource = ""
                    Products.LoadProducts()
                    Me.Close()
                End If
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        cmd.Parameters.Clear()
    End Sub

    Sub UpdateProduct()
        Dim result As Integer

        Try
            'we open Connection
            'MysqlConn.Open()

            With cmd
                .Connection = MysqlConn
                .CommandText = "UPDATE products set " & _
                     "ProdName=@prodName, " & _
                     "CatType=@CatType, " & _
                     "price=@price " & _
                     "where ProdID=@prodID"

                .Parameters.AddWithValue("@prodName", txtProdName.Text)
                .Parameters.AddWithValue("@CatType", ComboBox1.SelectedValue)
                .Parameters.AddWithValue("@price", txtPrice.Text)
                .Parameters.AddWithValue("@prodID", prodid)

                'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                result = cmd.ExecuteNonQuery

                'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                Else
                    MsgBox("Record successfully updated!", vbOKOnly + vbInformation, "System")

                    Products.DataGridView1.DataSource = ""
                    Products.LoadProducts()
                    Me.Close()
                End If
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        cmd.Parameters.Clear()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Products.btnUpdate.Enabled = False

        Me.Dispose()
    End Sub

    Private Sub btnCreateProduct_Click(sender As Object, e As EventArgs) Handles btnCreateProduct.Click
        If ComboBox1.Text = "" Or txtPrice.Text = "" Or txtProdName.Text = "" Then
            MsgBox("Ono of the fields is empty", vbExclamation + vbOKOnly, "System")
        Else
            If commandstat = "ADD" Then
                'Dim ProdIDExists As Boolean = CheckProdIdIfExists(CInt(txtProdID.Text))
                'If ProdIDExists = True Then
                '    MsgBox("Entered product ID already in use", vbExclamation + vbOKOnly, "System")
                '    txtProdID.Clear()
                '    txtProdID.Focus()
                'Else
                '    AddProduct()
                '    Products.btnUpdate.Enabled = False
                'End If

                AddProduct()
                Products.btnUpdate.Enabled = False

            ElseIf commandstat = "UPDATE" Then
                UpdateProduct()
                Products.btnUpdate.Enabled = False
            End If
        End If
        
        'MsgBox(ComboBox1.Text + "," + ComboBox1.SelectedValue.ToString)
    End Sub

    Function CheckProdIdIfExists(id As Integer)
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT ProdID from products WHERE ProdID = @pid"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
            .Parameters.AddWithValue("@pid", id)
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        Dim result As Boolean
        If table.Rows.Count > 0 Then
            result = True
        Else
            result = False
        End If

        Return result
    End Function

    Private Sub txtProdID_KeyPress(sender As Object, e As KeyPressEventArgs)
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or
                         Asc(e.KeyChar) = 8)
    End Sub

    Private Sub txtPrice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPrice.KeyPress
        Dim DecimalSeparator As String = Application.CurrentCulture.NumberFormat.NumberDecimalSeparator
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or
                         Asc(e.KeyChar) = 8 Or
                         (e.KeyChar = DecimalSeparator And sender.Text.IndexOf(DecimalSeparator) = -1))

        If Char.IsControl(e.KeyChar) Then
        ElseIf Char.IsDigit(e.KeyChar) OrElse e.KeyChar = "."c Then
            'If TextBox2.TextLength = 5 And TextBox2.Text.Contains(".") = False Then
            'TextBox2.AppendText(".")
            'Elseif
            If e.KeyChar = "." And txtPrice.Text.IndexOf(".") <> -1 Then
                e.Handled = True
            ElseIf Char.IsDigit(e.KeyChar) Then
                If txtPrice.Text.IndexOf(".") <> -1 Then
                    If txtPrice.Text.Length >= txtPrice.Text.IndexOf(".") + 3 Then
                        e.Handled = True
                    End If
                End If
            End If
        Else
            e.Handled = True
        End If
    End Sub
End Class