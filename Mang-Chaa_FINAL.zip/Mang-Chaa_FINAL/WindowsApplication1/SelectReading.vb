﻿Public Class SelectReading

    Private Sub btnCashier_Click(sender As Object, e As EventArgs) Handles btnCashier.Click
        Dim sql As String
        Dim table As New DataTable

        If CashierID = 0 And ReadingID = 0 Then
            'Nothing
        Else
            'CASHIER READING
            sql = "SELECT cast(SUM(TotalPrice) AS decimal(12,2)) as TotalSales," _
                & "cast(SUM(Vatable) AS decimal(12,2)) as TotalVatable," _
                & "cast(SUM(VAT) AS decimal(12,2)) as TotalVAT," _
                & "cast(SUM(Discount) AS decimal(12,2)) as Discount,COUNT(TransID) as TotalTrans," _
                & "SUM(TotalItems) as TotalSold FROM transactionheader WHERE UserID = @uid AND CReadingID = @rid"

            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@uid", CashierID)
                .Parameters.AddWithValue("@rid", ReadingID)
            End With

            da.SelectCommand = cmd
            da.Fill(table)

            cmd.Parameters.Clear()

            If table.Rows.Count > 0 Then
                sql = "UPDATE reading_cashier SET " _
                    & "ReadingStatus=@status," _
                    & "TotalSalesAmt=@totalsales," _
                    & "TotalVat=@totalvat," _
                    & "TotalVatable=@totalvatable," _
                    & "TotalDiscount=@totaldisc," _
                    & "TotalTransactions=@totaltrans," _
                    & "TotalSoldItems=@totalsold " _
                    & "WHERE id =@crid and ReadingStatus='Open'"

                'UPDATE Cashier Reading, then update its status
                With cmd
                    .CommandText = sql
                    .Connection = MysqlConn
                    .Parameters.AddWithValue("@status", "Close")
                    .Parameters.AddWithValue("@totalsales", table.Rows(0).Item("TotalSales"))
                    .Parameters.AddWithValue("@totalvat", table.Rows(0).Item("TotalVAT"))
                    .Parameters.AddWithValue("@totalvatable", table.Rows(0).Item("TotalVatable"))
                    .Parameters.AddWithValue("@totaldisc", table.Rows(0).Item("Discount"))
                    .Parameters.AddWithValue("@totaltrans", table.Rows(0).Item("TotalTrans"))
                    .Parameters.AddWithValue("@totalsold", table.Rows(0).Item("TotalSold"))
                    .Parameters.AddWithValue("@crid", ReadingID)
                End With

                Dim result As Integer = cmd.ExecuteNonQuery
                If result = 0 Then
                    MsgBox("Unable to process Cashier Reading", vbCritical + vbOKOnly, "System")
                    cmd.Parameters.Clear()
                Else
                    'MsgBox("Performed Cashier Reading. Closing the POS..", vbInformation + vbOKOnly, "System")
                    cmd.Parameters.Clear()

                    Dim preview As New ReceiptPreview
                    preview.strPrint = PrepareCashierReadingReceipt(CashierID)
                    preview.ShowDialog()

                    Me.Close()
                    POS.Close()
                End If
            End If
        End If

        
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        'REGISTER READING
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT COUNT(ReadingStatus) as OpenCashierReading from reading_cashier WHERE ReadingStatus =@stat AND DATE(DateCreated) = DATE(NOW())"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
            .Parameters.AddWithValue("@stat", "Open")
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        cmd.Parameters.Clear()

        If table.Rows(0).Item("OpenCashierReading") > 0 Then
            MsgBox(table.Rows(0).Item("OpenCashierReading") & " cashier readings still open", vbExclamation + vbOKOnly, "System")
        Else
            sql = "SELECT (SELECT MIN(TransID) FROM transactionheader WHERE DATE(DateCreated) = DATE(NOW())) as TransactionStart," _
                & "(SELECT MAX(TransID) FROM transactionheader WHERE DATE(DateCreated) = DATE(NOW())) as TransactionEnd," _
                & "SUM(a.TotalSalesAmt) as TotalSalesAmt,SUM(a.TotalVat) as TotalVat,ROUND(SUM(a.TotalVatable),2) as TotalVatable," _
                & "SUM(a.TotalDiscount) as TotalDiscount,SUM(a.TotalVat) as TotalVat,ROUND(SUM(a.TotalVatable),2) as TotalVatable," _
                & "SUM(a.TotalTransactions) as TotalTransactions,SUM(a.TotalSoldItems) as TotalSoldItems " _
                & "FROM reading_cashier a WHERE DATE(a.DateCreated) = DATE(NOW()) AND a.ReadingStatus = 'Close'"

            With cmd
                .CommandText = sql
                .Connection = MysqlConn
            End With

            table = New DataTable 're-instatiates as new table

            da.SelectCommand = cmd
            da.Fill(table)

            sql = "INSERT INTO reading_register(CashierID,TransactionStart,TransactionEnd,TotalSalesAmt,TotalVat,TotalVatable,TotalDiscount,TotalTransactions,TotalSoldItems)" _
                & "VALUES(@uid,@start,@end,@totalsales,@totalvat,@totalvatable,@totaldisc,@totaltrans,@totalsold)"

            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@uid", LoggedUserID)
                .Parameters.AddWithValue("@start", table.Rows(0).Item("TransactionStart"))
                .Parameters.AddWithValue("@end", table.Rows(0).Item("TransactionEnd"))
                .Parameters.AddWithValue("@totalsales", table.Rows(0).Item("TotalSalesAmt"))
                .Parameters.AddWithValue("@totalvat", table.Rows(0).Item("TotalVat"))
                .Parameters.AddWithValue("@totalvatable", table.Rows(0).Item("TotalVatable"))
                .Parameters.AddWithValue("@totaldisc", table.Rows(0).Item("TotalDiscount"))
                .Parameters.AddWithValue("@totaltrans", table.Rows(0).Item("TotalTransactions"))
                .Parameters.AddWithValue("@totalsold", table.Rows(0).Item("TotalSoldItems"))
            End With

            Dim result = cmd.ExecuteNonQuery
            If result = 0 Then
                MsgBox("Unable to process Register Reading", vbCritical + vbOKOnly, "System")
                cmd.Parameters.Clear()
            Else
                'MsgBox("Performed Register Reading", vbInformation + vbOKOnly, "System")

                Dim preview As New ReceiptPreview
                preview.strPrint = PrepareRegisterReadingReceipt(LoggedUserID)
                preview.ShowDialog()

                cmd.Parameters.Clear()
                Me.Close()
            End If
        End If

        'Dim preview As New ReceiptPreview
        'preview.strPrint = PrepareRegisterReadingReceipt(LoggedUserID)
        'preview.ShowDialog()
    End Sub

    Private Sub btnEOD_Click(sender As Object, e As EventArgs) Handles btnEOD.Click
        'GENERATE EOD FILE
        Dim sql As String
        Dim table As New DataTable
        'VALIDATE IF ALL CASHIER HAS PERFORMED CASHIER READING (Status = CLOSE)
        sql = "SELECT COUNT(ReadingStatus) as OpenCashierReading from reading_cashier WHERE ReadingStatus =@stat AND DATE(DateCreated) = DATE(NOW())"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
            .Parameters.AddWithValue("@stat", "Open")
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        cmd.Parameters.Clear()

        If table.Rows(0).Item("OpenCashierReading") > 0 Then
            If table.Rows(0).Item("OpenCashierReading") > 1 Then
                MsgBox(table.Rows(0).Item("OpenCashierReading") & " cashier accounts are still open", vbExclamation + vbOKOnly, "System")
            Else
                MsgBox(table.Rows(0).Item("OpenCashierReading") & " cashier account is still open", vbExclamation + vbOKOnly, "System")
            End If
        Else
            sql = "INSERT INTO reading_EOD(CreatedBy)VALUES(@uid)"

            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@uid", LoggedUserID)
            End With

            Dim result As Integer
            result = cmd.ExecuteNonQuery()

            If result = 0 Then
                MsgBox("Unable to process EOD", vbCritical + vbOKOnly, "System")
                cmd.Parameters.Clear()
            Else
                cmd.Parameters.Clear()


                Dim preview As New ReceiptPreview
                preview.strPrint = PrepareEODReadingReceipt(GetEODReferenceNo())
                preview.ShowDialog()

                Me.Close()
                POS.Close()
            End If
        End If
    End Sub

    Public Function GetEODReferenceNo() As Integer
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT eodID FROM reading_eod WHERE Date(DateCreated) = Date(NOW())"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        cmd.Parameters.Clear()

        Return table.Rows(0).Item("eodID")
    End Function

    Public Function PrepareCashierReadingReceipt(cid As Integer)
        Dim strPrint As String = ""

        Dim config As New IniFile(Application.StartupPath & "\" & "Config.ini")

        'RECEIPT HEADER
        Dim CompanyName As String = config.GetString("Receipt", "StoreName", "Company XYZ")
        Dim CompanyAddress As String = config.GetString("Receipt", "StoreAddress", "Address Here")

        strPrint = " " & vbCrLf
        strPrint = strPrint & " " & vbCrLf
        strPrint = strPrint & CompanyName.ToString.PadLeft(21) & vbCrLf
        strPrint = strPrint & CompanyAddress.ToString.PadLeft(28) & vbCrLf
        strPrint = strPrint & " " & vbNewLine

        'BODY
        Dim sql As String
        Dim table As New DataTable

        'Sales Date and Date Performed
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        strPrint = strPrint & "".PadRight(1) & "Sales Date  : ".ToString.PadRight(2) & Format(Date.Today, "MM/dd/yyyy") & vbCrLf
        strPrint = strPrint & "".PadRight(1) & "Cashier     : ".ToString.PadRight(2) & GetCashierName(LoggedUserID) & vbCrLf
        'strPrint = strPrint & "" & vbNewLine & vbCrLf
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        strPrint = strPrint & "".PadRight(7) & "Cashier Sales Total".ToString.PadRight(2) & vbCrLf
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        'strPrint = strPrint & " " & vbNewLine

        'Items
        sql = "SELECT TotalTransactions AS TotalTrans,TotalSoldItems," _
            & "TotalSalesAmt AS TotalSales,ChangeFund,TotalDiscount,(TotalSalesAmt +  ChangeFund) AS TotalCashInDrawer " _
            & "FROM reading_cashier WHERE DATE(DateCreated) = DATE(NOW()) AND CashierID = @cid and id = @rid"
        table = New DataTable
        Try
            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@cid", cid)
                .Parameters.AddWithValue("@rid", ReadingID)
            End With

            da.SelectCommand = cmd
            da.Fill(table)

            cmd.Parameters.Clear()

            'Subtotal,Vatable,VAT
            'strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "No of Transactions".ToString.PadRight(24) & table.Rows(0).Item("TotalTrans").ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "No of Items Sold".ToString.PadRight(24) & table.Rows(0).Item("TotalSoldItems").ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "NET Sales".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalSales"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "ADD:" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Discount".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalDiscount"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "CASHIER GROSS SALES".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalSales") + table.Rows(0).Item("TotalDiscount"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "CASH Sales".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalSales"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Change Fund".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("ChangeFund"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Total Cash in Drawer".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalCashInDrawer"), 2).ToString.PadLeft(9) & vbCrLf

        Catch ex As Exception
            'MsgBox(ex.Message)
            If MsgBox(ex.Message) = DialogResult.OK Then
                cmd.Parameters.Clear()
            End If
        End Try

        'FOOTER


        Return strPrint
        'Printer.Print(strPrint)
    End Function

    Public Function PrepareRegisterReadingReceipt(cid As Integer)
        Dim strPrint As String = ""

        Dim config As New IniFile(Application.StartupPath & "\" & "Config.ini")

        'RECEIPT HEADER
        Dim CompanyName As String = config.GetString("Receipt", "StoreName", "Company XYZ")
        Dim CompanyAddress As String = config.GetString("Receipt", "StoreAddress", "Address Here")

        strPrint = " " & vbCrLf
        strPrint = strPrint & " " & vbCrLf
        strPrint = strPrint & CompanyName.ToString.PadLeft(21) & vbCrLf
        strPrint = strPrint & CompanyAddress.ToString.PadLeft(28) & vbCrLf
        strPrint = strPrint & " " & vbNewLine

        'BODY
        Dim sql As String
        Dim table As New DataTable

        'Sales Date and Date Performed
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        strPrint = strPrint & "".PadRight(1) & "Sales Date  : ".ToString.PadRight(2) & Format(Date.Today, "MM/dd/yyyy") & vbCrLf
        strPrint = strPrint & "".PadRight(1) & "Prepared By : ".ToString.PadRight(2) & GetCashierName(LoggedUserID) & vbCrLf
        'strPrint = strPrint & "" & vbNewLine & vbCrLf
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        strPrint = strPrint & "".PadRight(7) & "Register Sales Total".ToString.PadRight(2) & vbCrLf
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        'strPrint = strPrint & " " & vbNewLine

        'Items
        sql = "SELECT TotalTransactions AS TotalTrans,TotalSoldItems," _
            & "TotalSalesAmt AS TotalSales,TotalVatable as VatableSales,TotalVat as Vat,TotalDiscount as Discount " _
            & "FROM reading_register WHERE id = (SELECT max(id) from reading_register WHERE DATE(DateCreated) = DATE(NOW()) AND CashierID = @cid)"
        table = New DataTable
        Try
            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@cid", cid)
            End With

            da.SelectCommand = cmd
            da.Fill(table)

            cmd.Parameters.Clear()

            'Subtotal,Vatable,VAT
            'strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Register Audit" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "No of Transactions".ToString.PadRight(24) & table.Rows(0).Item("TotalTrans").ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "No of Items Sold".ToString.PadRight(24) & table.Rows(0).Item("TotalSoldItems").ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            'strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Vatable Sales".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("VatableSales"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "VAT Amount".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("Vat"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Register Net Sales".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalSales"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "ADD:" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Discount".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("Discount"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "REGISTER GROSS SALES".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalSales") + table.Rows(0).Item("Discount"), 2).ToString.PadLeft(9) & vbCrLf
        Catch ex As Exception
            'MsgBox(ex.Message)
            If MsgBox(ex.Message) = DialogResult.OK Then
                cmd.Parameters.Clear()
            End If
        End Try

        'FOOTER

        Return strPrint
    End Function

    Public Function PrepareEODReadingReceipt(eodID As Integer)
        Dim strPrint As String = ""

        Dim config As New IniFile(Application.StartupPath & "\" & "Config.ini")

        'RECEIPT HEADER
        Dim CompanyName As String = config.GetString("Receipt", "StoreName", "Company XYZ")
        Dim CompanyAddress As String = config.GetString("Receipt", "StoreAddress", "Address Here")

        strPrint = " " & vbCrLf
        strPrint = strPrint & " " & vbCrLf
        strPrint = strPrint & CompanyName.ToString.PadLeft(21) & vbCrLf
        strPrint = strPrint & CompanyAddress.ToString.PadLeft(28) & vbCrLf
        strPrint = strPrint & " " & vbNewLine

        'BODY
        Dim sql As String
        Dim table As New DataTable
        Dim currTotalSales As Double
        'Sales Date and Date Performed
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        strPrint = strPrint & "".PadRight(1) & "Sales Date  : ".ToString.PadRight(2) & Format(Date.Today, "MM/dd/yyyy") & vbCrLf
        strPrint = strPrint & "".PadRight(1) & "Prepared By : ".ToString.PadRight(2) & GetCashierName(LoggedUserID) & vbCrLf
        'strPrint = strPrint & "" & vbNewLine & vbCrLf
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        strPrint = strPrint & "".PadRight(9) & "END-OF-DAY TOTAL".ToString.PadRight(2) & vbCrLf
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        'strPrint = strPrint & " " & vbNewLine

        'Total Gross Sales Today
        sql = "SELECT TransactionStart,TransactionEnd,TotalSalesAmt,TotalDiscount FROM reading_register WHERE DATE(DateCreated) = DATE(NOW()) ORDER BY DateCreated DESC LIMIT 1"

        Try
            With cmd
                .CommandText = sql
                .Connection = MysqlConn
            End With

            da.SelectCommand = cmd
            da.Fill(table)


            'Subtotal,Vatable,VAT
            'strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Control No  : ".ToString.PadRight(2) & eodID & vbCrLf
            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "TRANSACTION NUMBER" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "START".ToString.PadRight(24) & table.Rows(0).Item("TransactionStart").ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "END".ToString.PadRight(24) & table.Rows(0).Item("TransactionEnd").ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            'strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "REGISTER SALES(TODAY)".ToString.PadRight(24) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Register Net Sales".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalSalesAmt"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "ADD:".ToString.PadRight(24) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Discount".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalDiscount"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "REGISTER GROSS SALES".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalSalesAmt") + table.Rows(0).Item("TotalDiscount"), 2).ToString.PadLeft(9) & vbCrLf
            currTotalSales = table.Rows(0).Item("TotalSalesAmt") + table.Rows(0).Item("TotalDiscount")
        Catch ex As Exception
            'MsgBox(ex.Message)
            If MsgBox(ex.Message) = DialogResult.OK Then
                cmd.Parameters.Clear()
            End If
        End Try

        'Total Gross Sales (OLD)
        'sql = "SELECT COALESCE(SUM(TotalSalesAmt),0.00) as TotalSalesOLD," _
        '    & "COALESCE(SUM(TotalDiscount),0.00) as TotalDiscOLD FROM reading_register WHERE DATE(DateCreated) < DATE(NOW())"
        sql = "SELECT COALESCE(SUM(TotalPrice),0.00) as TotalSalesOLD," _
            & "COALESCE(SUM(DiscountValue),0.00) as TotalDiscOLD FROM transactiondetails WHERE DATE(DateCreated) < DATE(NOW())"
        table = New DataTable
        Try
            With cmd
                .CommandText = sql
                .Connection = MysqlConn
            End With

            da.SelectCommand = cmd
            da.Fill(table)

            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "OLD GROSS SALES".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalSalesOLD"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "ADD".ToString.PadRight(24) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Discount".ToString.PadRight(24) & FormatNumber(table.Rows(0).Item("TotalDiscOLD"), 2).ToString.PadLeft(9) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "NEW GROSS SALES".ToString.PadRight(24) & FormatNumber(currTotalSales + table.Rows(0).Item("TotalSalesOLD") + table.Rows(0).Item("TotalDiscOLD"), 2).ToString.PadLeft(9) & vbCrLf

        Catch ex As Exception
            'MsgBox(ex.Message)
            If MsgBox(ex.Message) = DialogResult.OK Then
                cmd.Parameters.Clear()
            End If
        End Try


        Return strPrint
    End Function
End Class