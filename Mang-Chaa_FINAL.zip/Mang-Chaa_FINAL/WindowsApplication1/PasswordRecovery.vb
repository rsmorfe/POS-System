﻿Public Class PasswordRecovery
    Dim userid As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Len(Trim(txtUser.Text)) = 0 Then
            MsgBox("Enter your username", vbExclamation + vbOKOnly, "Username Required")
            txtUser.Focus()
        Else
            CheckIfUserExists(txtUser.Text)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If Len(Trim(txtPass.Text)) = 0 Or Len(Trim(txtConfirm.Text)) = 0 Then
            MsgBox("One of the required fields is empty", vbExclamation + vbOKOnly, "Empty Field")
        ElseIf txtPass.Text <> txtConfirm.Text Then
            MsgBox("Both passwords are different", vbExclamation + vbOKOnly, "Empty Field")
            txtPass.Clear()
            txtConfirm.Clear()
            txtPass.Focus()
        Else
            updateAccount(txtPass.Text)
        End If
    End Sub

    Sub CheckIfUserExists(user As String)
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT id from employees WHERE uname = @uname"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
            .Parameters.AddWithValue("@uname", user)
        End With

        da.SelectCommand = cmd
        da.Fill(table)
        da.Dispose()

        cmd.Parameters.Clear()

        If table.Rows.Count > 0 Then
            txtUser.Enabled = False
            Button1.Enabled = False
            userid = table.Rows(0).Item(0)
            GroupBox1.Enabled = True
            btnSave.Enabled = True
            txtPass.Focus()
        Else
            MsgBox("This username doesn't exists", vbExclamation + vbOKOnly, "System")
            txtUser.Focus()
        End If
    End Sub

    Sub updateAccount(pword As String)
        Dim sql As String

        sql = "UPDATE employees SET pword = @pword WHERE id = @uid"

        Try
            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@pword", pword)
                .Parameters.AddWithValue("@uid", userid)
                .ExecuteNonQuery()
            End With

            MsgBox("Your account's password has been updated.", vbInformation + vbOKOnly, "Update Successful")

            cmd.Parameters.Clear()

            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            cmd.Parameters.Clear()
        End Try
        
    End Sub

End Class