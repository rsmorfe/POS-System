﻿
Public Class Inventory_AddStock
    Public commandstat As Integer
    Public itemID As Integer
    Public currentStock As Integer 'FOR UPDATE, to validate current stock with user input
    Public actionType As Integer

    Sub ExecuteProcess(command As Integer)
        Dim result As Integer

        If commandstat = 1 Then
            actionType = 1
        Else
            actionType = 2
        End If

        Try
            'we open Connection
            'MysqlConn.Open()
            'Dim cat_index As Integer = ComboBox1.SelectedIndex

            With cmd
                .Connection = MysqlConn
                .CommandText = "INSERT INTO stockinventory" _
                    & "(ItemID,ActionType,Quantity,Remarks,CreatedBy) VALUES(@itemID,@type,@qty,@remarks,@user)"

                .Parameters.AddWithValue("@itemID", itemID)
                .Parameters.AddWithValue("@type", actionType)
                .Parameters.AddWithValue("@qty", txtQty.Text)
                .Parameters.AddWithValue("@remarks", If(txtRemarks.Text, DBNull.Value))
                .Parameters.AddWithValue("@user", LoggedUserID)

                'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                result = cmd.ExecuteNonQuery
                'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                Else
                    MsgBox("Successfully saved!", vbOKOnly + vbInformation, "System")

                    Inventory.DataGridView1.DataSource = ""
                    Inventory.LoadProducts("")
                    'Inventory.DataGridView1.CurrentRow.Selected = False

                    Me.Dispose()
                End If
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        cmd.Parameters.Clear()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Inventory.DataGridView1.ClearSelection()
        Me.Close()
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        If txtQty.Text = "" Then
            MsgBox("Enter quantity", vbExclamation + vbOKOnly, "Blank Field")
            txtQty.Focus()
        ElseIf IsNumeric(txtQty.Text) = False Then
            MsgBox("Numeric values only", vbExclamation + vbOKOnly, "Incorrect Input")
            txtQty.Focus()
        ElseIf CInt(txtQty.Text) = 0 Then
            MsgBox("Non-zero value only", vbExclamation + vbOKOnly, "Incorrect Input")
        ElseIf commandstat = 2 And CInt(txtQty.Text) > currentStock Then
            MsgBox("Entered value is higher than the current stock", vbExclamation + vbOKOnly, "Incorrect Input")
        Else
            Dim reconfirm As String = MsgBox("Are all details correct?", vbQuestion + vbYesNo, "System")
            If reconfirm = vbYes Then
                ExecuteProcess(commandstat)
                'MsgBox("Test Process done!")
            Else
                'Do Nothing
                'MsgBox("Test Process 2 done!")
            End If

        End If
    End Sub

    Private Sub txtQty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQty.KeyPress
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or
                 Asc(e.KeyChar) = 8)
    End Sub

    Private Sub Inventory_AddStock_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        txtItemName.Clear()
        txtRemarks.Clear()
        txtQty.Clear()
    End Sub

End Class