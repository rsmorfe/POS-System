﻿Public Class ManageCategories

    Public selected_CatID As Integer

    Sub LoadCategories()
        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT * from categories"

        With cmd
            .Connection = MysqlConn
            .CommandText = sql
        End With

        da.SelectCommand = cmd
        da.Fill(publictable)

        DataGridView1.DataSource = publictable
        DataGridView1.Columns.Item(0).HeaderText = "ID"
        DataGridView1.Columns.Item(0).Width = 25
        DataGridView1.Columns.Item(1).HeaderText = "Category"
        DataGridView1.Columns.Item(1).Width = 165
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        txtCategory.Clear()
        txtCategory.Focus()

        btnAdd.Enabled = True
        btnSave.Enabled = False
        btnUpdate.Enabled = False
        txtCategory.Enabled = False

        Me.LoadCategories()
    End Sub

    Private Sub ManageCategories_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCategories()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        btnUpdate.Enabled = False
        btnAdd.Enabled = True
        txtCategory.Enabled = False
    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        Dim row As DataGridViewRow = DataGridView1.CurrentRow

        If row.Cells(0).Value.ToString() = "" Then
            'do nothing
        Else
            txtCategory.Text = row.Cells(1).Value.ToString()
            selected_CatID = row.Cells(0).Value.ToString()
            btnUpdate.Enabled = True
            btnAdd.Enabled = False
            txtCategory.Enabled = True
        End If
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        txtCategory.Enabled = True
        btnSave.Enabled = True
        btnAdd.Enabled = False
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If Len(Trim(txtCategory.Text)) = 0 Then
            MsgBox("The required field is empty", vbExclamation + vbOKOnly, "System")
            txtCategory.Focus()
        Else
            Dim catID As Integer = selected_CatID
            Dim sql As String
            Dim result As Integer

            Try
                sql = "UPDATE categories set category =@catName WHERE CatID =@catid"

                With cmd
                    .CommandText = sql
                    .Connection = MysqlConn
                    .Parameters.AddWithValue("@catid", catID)
                    .Parameters.AddWithValue("@catName", txtCategory.Text)
                End With

                result = cmd.ExecuteNonQuery

                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                Else
                    MsgBox("Category has been updated!", vbOKOnly + vbInformation, "System")

                    DataGridView1.DataSource = ""
                    txtCategory.Clear()
                    txtCategory.Focus()

                    btnAdd.Enabled = True
                    btnSave.Enabled = False
                    btnUpdate.Enabled = False
                    txtCategory.Enabled = False

                    Me.LoadCategories()
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            cmd.Parameters.Clear()
        End If
       
    End Sub


    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If Len(Trim(txtCategory.Text)) = 0 Then
            MsgBox("The required field is empty", vbExclamation + vbOKOnly, "System")
            txtCategory.Focus()
        Else
            'Dim catID As Integer = DataGridView1.Rows.Count
            Dim sql As String
            Dim result As Integer

            Try
                sql = "INSERT INTO categories(category)VALUES(@catName)"

                With cmd
                    .CommandText = sql
                    .Connection = MysqlConn
                    '.Parameters.AddWithValue("@catid", catID)
                    .Parameters.AddWithValue("@catName", txtCategory.Text)
                End With

                result = cmd.ExecuteNonQuery

                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                Else
                    MsgBox("New category created!", vbOKOnly + vbInformation, "System")

                    DataGridView1.DataSource = ""
                    txtCategory.Clear()
                    txtCategory.Focus()

                    btnAdd.Enabled = True
                    btnSave.Enabled = False
                    btnUpdate.Enabled = False
                    txtCategory.Enabled = False

                    Me.LoadCategories()
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            cmd.Parameters.Clear()
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If DataGridView1.Rows.Count = 0 Then
            'nothing
        Else
            If MsgBox("Do you really want to delete this item?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
                Dim sql As String
                sql = "DELETE FROM categories WHERE catID = @catid"

                Try
                    With cmd
                        .CommandText = sql
                        .Connection = MysqlConn
                        .Parameters.AddWithValue("@catid", DataGridView1.CurrentRow.Cells(0).Value)
                        .ExecuteNonQuery()
                    End With

                    cmd.Parameters.Clear()
                    LoadCategories()
                Catch ex As Exception
                    MsgBox(ex.Message)
                    cmd.Parameters.Clear()
                End Try

            End If

        End If
    End Sub
End Class