﻿Public Class Inventory_ItemDetails
    Public ItemID As Integer
    Public ItemName As String

    Private Sub ProductDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ResetFields()


        txtProdID.Text = ItemID
        txtProdName.Text = ItemName

        LoadItemsAdded(ItemID)
        LoadItemsUsed(ItemID)
        ComputeStock()
    End Sub

    Sub ResetFields()
        lblReceived.Text = 0
        lblPurchased.Text = 0
        lblAvailable.Text = 0
    End Sub

    Sub ComputeStock()
        Dim totalAdded As Integer = 0
        Dim totalUsed As Integer = 0
        Dim availableStock As Integer = 0

        'ADDED
        For Each AddedRows As DataGridViewRow In DataGridView1.Rows
            Dim added As DataGridViewCell = AddedRows.Cells("Quantity")
            totalAdded += added.Value
        Next

        'USED
        For Each UsedRows As DataGridViewRow In DataGridView2.Rows
            Dim used As DataGridViewCell = UsedRows.Cells("Quantity")
            totalUsed += used.Value
        Next

        'AVAILABLE STOCK
        availableStock = totalAdded - totalUsed

        lblReceived.Text = totalAdded
        lblPurchased.Text = totalUsed
        lblAvailable.Text = availableStock
    End Sub

    Sub LoadItemsAdded(id As Integer)

        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT DATE_FORMAT(DateCreated,'%Y-%m-%d') AS DateReceived,Quantity,Remarks," _
            & "(SELECT CONCAT(fname,' ',lname) as Staff FROM employees WHERE id = CreatedBy) as Receiver FROM stockinventory WHERE ItemID ='" & id & "' AND ActionType = 1"

        With cmd
            .Connection = MysqlConn
            .CommandText = sql
        End With

        da.SelectCommand = cmd
        da.Fill(publictable)

        DataGridView1.DataSource = publictable
        'DataGridView1.Columns(0).Width = 100
        'DataGridView1.Columns(1).Width = 200
        'DataGridView1.Columns(2).Width = 100
        'DataGridView1.Columns.Item(3).DefaultCellStyle.Format = "####.#0"

    End Sub

    Sub LoadItemsUsed(id As Integer)

        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT DATE_FORMAT(DateCreated,'%Y-%m-%d') AS Date,Quantity,Remarks," _
            & "(SELECT CONCAT(fname,' ',lname) as Staff FROM employees WHERE id = CreatedBy) as IssuedBy FROM stockinventory WHERE ItemID ='" & id & "' AND ActionType = 2"

        With cmd
            .Connection = MysqlConn
            .CommandText = sql
        End With

        da.SelectCommand = cmd
        da.Fill(publictable)

        DataGridView2.DataSource = publictable
        'DataGridView1.Columns(0).Width = 100
        'DataGridView1.Columns(1).Width = 200
        'DataGridView1.Columns(2).Width = 100
        'DataGridView1.Columns.Item(3).DefaultCellStyle.Format = "####.#0"

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Inventory.DataGridView1.CurrentRow.Selected = False
        Me.Close()
    End Sub

End Class