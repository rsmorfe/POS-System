﻿Imports MySql.Data.MySqlClient
Module Module2
    Public MysqlConn As MySqlConnection
    Public cmd As New MySqlCommand
    Public da As New MySqlDataAdapter

    Public LoggedUserID As Integer
    Public LoggedUserLvl As Integer

    'Configurations from INI file
    Public VAT As Double
    Public Vatable As Double

    Public DB_Server As String
    Public DB_User As String
    Public DB_Pass As String
    Public DB_Name As String


    'For current Cashier Reading ID
    Public CashierID As Integer
    Public ReadingID As Integer

    'for detecting EOD
    Public HasPerformedEOD As Boolean

    'MySQL Connection
    Public Sub MysqlConnection()
        MysqlConn = New MySqlConnection()

        'Connection String
        MysqlConn.ConnectionString = "server=" & DB_Server & ";" _
        & "user id=" & DB_User & ";" _
        & "password=" & DB_Pass & ";" _
        & "database=" & DB_Name & ""

        'OPENING THE MysqlConnNECTION
        Try
            MysqlConn.Open()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    'Functions for creating/getting configuration in a INI file
    'START OF CLASS
    Public Class IniFile
        ' API functions
        Private Declare Ansi Function GetPrivateProfileString _
          Lib "kernel32.dll" Alias "GetPrivateProfileStringA" _
          (ByVal lpApplicationName As String, _
          ByVal lpKeyName As String, ByVal lpDefault As String, _
          ByVal lpReturnedString As System.Text.StringBuilder, _
          ByVal nSize As Integer, ByVal lpFileName As String) _
          As Integer
        Private Declare Ansi Function WritePrivateProfileString _
          Lib "kernel32.dll" Alias "WritePrivateProfileStringA" _
          (ByVal lpApplicationName As String, _
          ByVal lpKeyName As String, ByVal lpString As String, _
          ByVal lpFileName As String) As Integer
        Private Declare Ansi Function GetPrivateProfileInt _
          Lib "kernel32.dll" Alias "GetPrivateProfileIntA" _
          (ByVal lpApplicationName As String, _
          ByVal lpKeyName As String, ByVal nDefault As Integer, _
          ByVal lpFileName As String) As Integer
        Private Declare Ansi Function FlushPrivateProfileString _
          Lib "kernel32.dll" Alias "WritePrivateProfileStringA" _
          (ByVal lpApplicationName As Integer, _
          ByVal lpKeyName As Integer, ByVal lpString As Integer, _
          ByVal lpFileName As String) As Integer
        Dim strFilename As String

        ' Constructor, accepting a filename
        Public Sub New(ByVal Filename As String)
            strFilename = Filename
        End Sub

        ' Read-only filename property
        ReadOnly Property FileName() As String
            Get
                Return strFilename
            End Get
        End Property

        Public Function GetString(ByVal Section As String, _
          ByVal Key As String, ByVal [Default] As String) As String
            ' Returns a string from your INI file
            'Dim intCharCount As Integer
            Dim objResult As New System.Text.StringBuilder(256)
            'intCharCount = GetPrivateProfileString(Section, Key, _
            '[Default], objResult, objResult.Capacity, strFilename)
            '    If intCharCount > 0 Then GetString = _
            '       Left(objResult.ToString, intCharCount)
            GetPrivateProfileString(Section, Key, _
            [Default], objResult, objResult.Capacity, strFilename)

            Return objResult.ToString
        End Function

        Public Function GetInteger(ByVal Section As String, _
          ByVal Key As String, ByVal [Default] As Integer) As Integer
            ' Returns an integer from your INI file
            Return GetPrivateProfileInt(Section, Key, _
               [Default], strFilename)
        End Function

        Public Function GetBoolean(ByVal Section As String, _
          ByVal Key As String, ByVal [Default] As Boolean) As Boolean
            ' Returns a boolean from your INI file
            Return (GetPrivateProfileInt(Section, Key, _
               CInt([Default]), strFilename) = 1)
        End Function

        Public Sub WriteString(ByVal Section As String, _
          ByVal Key As String, ByVal Value As String)
            ' Writes a string to your INI file
            WritePrivateProfileString(Section, Key, Value, strFilename)
            Flush()
        End Sub

        Public Sub WriteInteger(ByVal Section As String, _
          ByVal Key As String, ByVal Value As Integer)
            ' Writes an integer to your INI file
            WriteString(Section, Key, CStr(Value))
            Flush()
        End Sub

        Public Sub WriteBoolean(ByVal Section As String, _
          ByVal Key As String, ByVal Value As Boolean)
            ' Writes a boolean to your INI file
            WriteString(Section, Key, CStr(CInt(Value)))
            Flush()
        End Sub

        Private Sub Flush()
            ' Stores all the cached changes to your INI file
            FlushPrivateProfileString(0, 0, 0, strFilename)
        End Sub
    End Class
    'END OF CLASS

    Public Sub LoadConfiguration()
        Try
            Dim config As New IniFile(Application.StartupPath & "\" & "Config.ini")
            'TAX
            VAT = CDbl(config.GetString("BIR", "VAT", "0.00"))
            Vatable = CDbl(config.GetString("BIR", "Vatable", "0.00"))

            'DATABASE
            DB_Server = config.GetString("DATABASE", "Server", "")
            DB_User = config.GetString("DATABASE", "Username", "")
            DB_Pass = config.GetString("DATABASE", "Password", "")
            DB_Name = config.GetString("DATABASE", "Database", "")
            'MsgBox("VAT: " & VAT & " Vatable: " & Vatable)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        
    End Sub

    Public Sub SaveConfiguration(vat As Double, vatable As Double, dbServer As String, dbuser As String, dbPass As String, dbName As String)
        Try
            Dim config As New IniFile(Application.StartupPath & "\" & "Config.ini")
            'TAX
            config.WriteString("BIR", "VAT", FormatNumber(vat, 2))
            config.WriteString("BIR", "Vatable", FormatNumber(vatable, 2))

            'DATABASE
            config.WriteString("DATABASE", "Server", dbServer)
            config.WriteString("DATABASE", "Username", dbuser)
            config.WriteString("DATABASE", "Password", dbPass)
            config.WriteString("DATABASE", "Database", dbName)

            LoadConfiguration() 'Reloads configuration

            MsgBox("Configuration saved successfully", vbInformation + vbOKOnly, "System")

            Application.Restart()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        
    End Sub

    Public Sub CreateCashierReading(userID As Integer, ChangeFund As Double)
        Dim sql As String
        sql = "INSERT INTO reading_cashier(CashierID,ReadingStatus,ChangeFund,TotalSalesAmt,TotalVat,TotalVatable,TotalDiscount,TotalTransactions,TotalSoldItems)VALUES" _
            & "(@cid,@status,@fund,0.00,0.00,0.00,0.00,0,0)"

        Try
            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@cid", userID)
                .Parameters.AddWithValue("@status", "Open")
                .Parameters.AddWithValue("@fund", ChangeFund)
            End With

            cmd.ExecuteNonQuery()

            cmd.Parameters.Clear()

            LoadCashierReading(userID, "Open") 'Loads currently logged cashier and reading id
        Catch ex As Exception
            MsgBox(ex.Message)
            cmd.Parameters.Clear()
        End Try

    End Sub

    Public Sub LoadCashierReading(userID As Integer, status As String)
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT * FROM reading_cashier WHERE CashierID = @cid and Date(DateCreated) = Date(NOW()) and ReadingStatus = @status"

        Try
            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@cid", userID)
                .Parameters.AddWithValue("@status", status)
            End With

            da.SelectCommand = cmd
            da.Fill(table)

            cmd.Parameters.Clear()

            If table.Rows.Count > 0 Then
                'SET CashierID and ReadingID
                CashierID = table.Rows(0).Item("CashierID")
                ReadingID = table.Rows(0).Item("id")
                POS.Text = "POS - [Cashier: " & GetCashierName(CashierID) & " RID:" & ReadingID & "]"
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            cmd.Parameters.Clear()

        End Try
    End Sub

    Public Function GetCashierName(cid)
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT CONCAT(fname,' ',lname) as Cashier FROM employees WHERE id = @cid"

        Try
            With cmd
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@cid", cid)
            End With

            da.SelectCommand = cmd
            da.Fill(table)

        Catch ex As Exception
            MsgBox(ex.Message)
            cmd.Parameters.Clear()

        End Try

        cmd.Parameters.Clear()
        Dim CashierName As String = table.Rows(0).Item("Cashier").ToString
        Return CashierName
    End Function

    Public Function CheckStatus_EOD()
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT * FROM reading_eod WHERE DATE(DateCreated) = DATE(NOW())"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        If table.Rows.Count > 0 Then
            HasPerformedEOD = True
        Else
            HasPerformedEOD = False
        End If
        Return HasPerformedEOD
    End Function
End Module
