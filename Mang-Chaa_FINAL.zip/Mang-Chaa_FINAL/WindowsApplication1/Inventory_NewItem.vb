﻿Public Class Inventory_NewItem
    Public commandstat As Integer
    Public setindex As String
    Public itemID As Integer

    Private Sub Inventory_NewItem_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        txtItemName.Clear()

        cbxCategory.Text = ""
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
    End Sub

    Private Sub Inventory_NewItem_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'CLEAR FIELDS
        If commandstat = 1 Then
            txtItemName.Clear()
            cbxCategory.Text = ""
        End If
        'LOAD CATEGORIES
        LoadCategory()
    End Sub

    Sub LoadCategory()
        Dim sql As String
        Dim table As New DataTable

        sql = "SELECT * FROM inventory_category"

        With cmd
            .CommandText = sql
            .Connection = MysqlConn
        End With

        da.SelectCommand = cmd
        da.Fill(table)

        If table.Rows.Count > 0 Then
            cbxCategory.DataSource = table
            cbxCategory.DisplayMember = "catName"
            cbxCategory.ValueMember = "catID"
        End If

        If commandstat = 2 Then
            cbxCategory.SelectedIndex = cbxCategory.FindString(setindex)
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If Len(Trim(txtItemName.Text)) = 0 Or cbxCategory.Text = "" Or ComboBox1.Text = "" Or ComboBox2.Text = "" Or ComboBox3.Text = "" Then
            MsgBox("Please fill the required fields", vbExclamation + vbOKOnly, "Blank Field")
            txtItemName.Clear()
        Else
            Dim sql As String
            If commandstat = 1 Then
                'SAVE
                sql = "INSERT INTO inventory_items(itemName,itemCategory,UOM,Size,Color,CreatedBy,itemStatus)VALUES(@name,@cat,@uom,@size,@color,@user,@status)"

                With cmd
                    .CommandText = sql
                    .Connection = MysqlConn
                    .Parameters.AddWithValue("@name", txtItemName.Text)
                    .Parameters.AddWithValue("@cat", cbxCategory.SelectedValue)
                    .Parameters.AddWithValue("@uom", ComboBox1.Text)
                    .Parameters.AddWithValue("@size", If(ComboBox2.Text, DBNull.Value))
                    .Parameters.AddWithValue("@color", If(ComboBox3.Text, DBNull.Value))
                    .Parameters.AddWithValue("@user", LoggedUserID)
                    .Parameters.AddWithValue("@status", "1")
                End With

                Try
                    Dim result = cmd.ExecuteNonQuery

                    If result = 0 Then
                        MsgBox("Unable to create new item", vbExclamation + vbOKOnly, "")
                    Else
                        MsgBox("New item created", vbInformation + vbOKOnly, "")
                        Inventory.LoadProducts("")
                        Me.Close()
                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

                cmd.Parameters.Clear()
            Else 'commandstat = 2
                'UPDATE
                sql = "UPDATE inventory_items SET " _
                    & "itemName = @name,itemCategory = @cat," _
                    & "UOM = @uom,Size = @size," _
                    & "Color = @color " _
                    & "WHERE itemID = @itemID"

                With cmd
                    .CommandText = sql
                    .Connection = MysqlConn
                    .Parameters.AddWithValue("@name", txtItemName.Text)
                    .Parameters.AddWithValue("@cat", cbxCategory.SelectedValue)
                    .Parameters.AddWithValue("@uom", ComboBox1.Text)
                    .Parameters.AddWithValue("@size", If(ComboBox2.Text, DBNull.Value))
                    .Parameters.AddWithValue("@color", If(ComboBox3.Text, DBNull.Value))
                    .Parameters.AddWithValue("@itemID", itemID)
                End With

                Try
                    Dim result = cmd.ExecuteNonQuery

                    If result = 0 Then
                        MsgBox("Unable to update item", vbExclamation + vbOKOnly, "")
                    Else
                        MsgBox("Item updated", vbInformation + vbOKOnly, "")
                        Inventory.LoadProducts("")
                        Me.Close()

                        Inventory.DataGridView1.ClearSelection()
                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

                cmd.Parameters.Clear()
            End If
        End If

    End Sub

    Private Sub btnManageCat_Click(sender As Object, e As EventArgs) Handles btnManageCat.Click
        Inventory_Categories.ShowDialog()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
        Inventory.DataGridView1.ClearSelection()
    End Sub
End Class