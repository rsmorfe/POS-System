﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Inventory_ReportMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnStocks = New System.Windows.Forms.Button()
        Me.btnResupply = New System.Windows.Forms.Button()
        Me.btnTopItems = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btnTopSold = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnStocks
        '
        Me.btnStocks.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnStocks.Font = New System.Drawing.Font("Comic Sans MS", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStocks.Location = New System.Drawing.Point(12, 12)
        Me.btnStocks.Name = "btnStocks"
        Me.btnStocks.Size = New System.Drawing.Size(156, 50)
        Me.btnStocks.TabIndex = 4
        Me.btnStocks.Text = "Current Stocks"
        Me.btnStocks.UseVisualStyleBackColor = False
        '
        'btnResupply
        '
        Me.btnResupply.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnResupply.Font = New System.Drawing.Font("Comic Sans MS", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResupply.Location = New System.Drawing.Point(12, 68)
        Me.btnResupply.Name = "btnResupply"
        Me.btnResupply.Size = New System.Drawing.Size(156, 50)
        Me.btnResupply.TabIndex = 5
        Me.btnResupply.Text = "For Urgent Resupply"
        Me.btnResupply.UseVisualStyleBackColor = False
        '
        'btnTopItems
        '
        Me.btnTopItems.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnTopItems.Font = New System.Drawing.Font("Comic Sans MS", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTopItems.Location = New System.Drawing.Point(12, 124)
        Me.btnTopItems.Name = "btnTopItems"
        Me.btnTopItems.Size = New System.Drawing.Size(156, 50)
        Me.btnTopItems.TabIndex = 6
        Me.btnTopItems.Text = "Top Items (Used)"
        Me.btnTopItems.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button3.Font = New System.Drawing.Font("Comic Sans MS", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(12, 236)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(156, 50)
        Me.Button3.TabIndex = 7
        Me.Button3.Text = "CLOSE"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'btnTopSold
        '
        Me.btnTopSold.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnTopSold.Font = New System.Drawing.Font("Comic Sans MS", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTopSold.Location = New System.Drawing.Point(12, 180)
        Me.btnTopSold.Name = "btnTopSold"
        Me.btnTopSold.Size = New System.Drawing.Size(156, 50)
        Me.btnTopSold.TabIndex = 8
        Me.btnTopSold.Text = "Most Sold Products (POS)"
        Me.btnTopSold.UseVisualStyleBackColor = False
        '
        'Inventory_ReportMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(180, 293)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnTopSold)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btnTopItems)
        Me.Controls.Add(Me.btnResupply)
        Me.Controls.Add(Me.btnStocks)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "Inventory_ReportMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Inventory Reports"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnStocks As System.Windows.Forms.Button
    Friend WithEvents btnResupply As System.Windows.Forms.Button
    Friend WithEvents btnTopItems As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents btnTopSold As System.Windows.Forms.Button
End Class
