﻿Public Class Products

    Sub LoadProducts()
        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT ProdID,ProdName,(SELECT category FROM categories WHERE catID = CatType) as Category,price from products"

        With cmd
            .Connection = MysqlConn
            .CommandText = sql
        End With

        da.SelectCommand = cmd
        da.Fill(publictable)

        DataGridView1.DataSource = publictable
        DataGridView1.Columns.Item(0).HeaderText = "ID"
        DataGridView1.Columns.Item(0).Width = 150
        DataGridView1.Columns.Item(1).HeaderText = "Product"
        DataGridView1.Columns.Item(1).Width = 325
        DataGridView1.Columns.Item(2).HeaderText = "Category"
        DataGridView1.Columns.Item(2).Width = 150
        DataGridView1.Columns.Item(3).HeaderText = "Price"
        DataGridView1.Columns.Item(3).Width = 150

        DataGridView1.Columns.Item(3).DefaultCellStyle.Format = "####.#0"

    End Sub

    Sub SearchProduct(txt As String)
        Dim sql As String
        Dim publictable As New DataTable
        sql = "SELECT ProdID,ProdName,(SELECT category FROM categories WHERE catID = CatType) as Category,price FROM products " _
            & "where ProdID='" & txtSearch.Text & "' OR ProdName LIKE '%" & txtSearch.Text & "%'"

        'bind the connection and query
        With cmd
            .Connection = MysqlConn
            .CommandText = sql
        End With

        da.SelectCommand = cmd
        da.Fill(publictable)

        If publictable.Rows.Count > 0 Then
            'MsgBox("Record found!", vbInformation + vbOKOnly, "Search")
            DataGridView1.DataSource = publictable
            DataGridView1.Columns.Item(0).Width = 150
            DataGridView1.Columns.Item(1).Width = 325
            DataGridView1.Columns.Item(2).Width = 150
            DataGridView1.Columns.Item(3).Width = 150

            DataGridView1.Columns.Item(3).DefaultCellStyle.Format = "####.#0"

        Else
            MsgBox("No record/s Found", vbInformation + vbOKOnly, "Search")
            txtSearch.Clear()
            txtSearch.Focus()
            LoadProducts()
        End If

        'MysqlConn.Close()
        da.Dispose()
    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            SearchProduct(txtSearch.Text)
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        'OnlyOwner.Show()
        Me.Close()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        btnUpdate.Enabled = False

        Dim prodDetails As New Product_Details
        With prodDetails
            .commandstat = "ADD"
        End With
        prodDetails.ShowDialog()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim row As DataGridViewRow = DataGridView1.CurrentRow

        If row.Cells(0).Value.ToString() = "" Then
            'do nothing
        Else

            'Dim index As Integer = row.Cells(3).Value
            Dim prodDetails As New Product_Details

            With prodDetails
                .commandstat = "UPDATE"
                .prodid = row.Cells(0).Value
                .txtProdName.Text = row.Cells(1).Value.ToString()
                .txtPrice.Text = FormatNumber((row.Cells(3).Value), 2)
                .setindex = row.Cells(2).Value
            End With

            prodDetails.ShowDialog()
        End If

    End Sub

    Private Sub Products_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadProducts()

        txtSearch.Focus()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        btnUpdate.Enabled = False
    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        btnUpdate.Enabled = True
    End Sub

    Private Sub btnCategories_Click(sender As Object, e As EventArgs) Handles btnCategories.Click
        Dim manageCategory As New ManageCategories
        manageCategory.ShowDialog()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If DataGridView1.Rows.Count = 0 Then
            'nothing
        Else
            If MsgBox("Do you really want to delete this item?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
                Dim sql As String
                sql = "DELETE FROM products WHERE ProdID = @prodid"

                Try
                    With cmd
                        .CommandText = sql
                        .Connection = MysqlConn
                        .Parameters.AddWithValue("@prodid", DataGridView1.CurrentRow.Cells(0).Value)
                        .ExecuteNonQuery()
                    End With

                    cmd.Parameters.Clear()
                    LoadProducts()
                Catch ex As Exception
                    MsgBox(ex.Message)
                    cmd.Parameters.Clear()
                End Try
               
            End If
            
        End If
    End Sub

End Class